
# Create a comprehensive implementation plan as structured data
implementation_plan = {
    "Architecture Approach": {
        "Strategy 1: Residual Correction": {
            "Description": "TTM learns corrections to CMA predictions",
            "Complexity": "Low",
            "Data Efficiency": "High",
            "Interpretability": "Very High",
            "Best For": "When CMA provides good baseline predictions"
        },
        "Strategy 2: Exogenous Features": {
            "Description": "CMA outputs feed as exogenous inputs to TTM",
            "Complexity": "Low-Medium",
            "Data Efficiency": "High",
            "Interpretability": "High",
            "Best For": "Leveraging TTM's exogenous mixer capability"
        },
        "Strategy 3: Physics-Informed Loss": {
            "Description": "Add CMA equation constraints to TTM loss",
            "Complexity": "Medium",
            "Data Efficiency": "Medium-High",
            "Interpretability": "Medium-High",
            "Best For": "When sufficient training data available"
        },
        "Strategy 4: Multi-Stage Training": {
            "Description": "Pre-train on CMA, fine-tune TTM on residuals",
            "Complexity": "Medium-High",
            "Data Efficiency": "Very High",
            "Interpretability": "High",
            "Best For": "Limited individual data availability"
        }
    },
    "Implementation Steps": {
        "Phase 1: Data Preparation": [
            "1. Load CGM data with timestamps and glucose readings",
            "2. Convert timestamps to decimal hours (0-24)",
            "3. Extract meal times using CMA estimate_mealtimes() function",
            "4. Resample to regular intervals (e.g., 5-minute or 15-minute)",
            "5. Split into train/validation/test sets (70/15/15)"
        ],
        "Phase 2: CMA Model Setup": [
            "1. Initialize CMASleepWakeModel with estimated meal times",
            "2. Fit CMA parameters (d, taup, taug, B, Cm, toff) to training data",
            "3. Generate CMA baseline predictions for all data splits",
            "4. Compute CMA intermediate signals: L, M, C, A, I_S, I_E",
            "5. Save fitted CMA parameters for interpretability"
        ],
        "Phase 3: TTM Integration": [
            "1. Choose TTM variant (512-96, 1024-96, or 1536-96 based on data length)",
            "2. Prepare TTM input format (context_length historical points)",
            "3. Choose integration strategy (Residual/Exogenous/Physics-Loss/Multi-Stage)",
            "4. Configure TTM exogenous features with CMA outputs",
            "5. Set up physics-informed loss if using Strategy 3"
        ],
        "Phase 4: Hybrid Training": [
            "1. Initialize TTM model (pre-trained or from scratch)",
            "2. Freeze/unfreeze backbone based on strategy",
            "3. Train hybrid model with combined loss function",
            "4. Monitor validation performance (RMSE, MAE, clinical metrics)",
            "5. Adjust hyperparameters (learning rate, physics loss weight)"
        ],
        "Phase 5: Evaluation": [
            "1. Generate predictions on test set",
            "2. Compute glucose forecasting metrics (RMSE, MAE, MAPE)",
            "3. Calculate clinical metrics (Time in Range, hypo/hyper episodes)",
            "4. Compare: CMA-only vs TTM-only vs Hybrid performance",
            "5. Analyze prediction intervals and uncertainty quantification"
        ],
        "Phase 6: Interpretation": [
            "1. Extract fitted CMA parameters and generate clinical descriptions",
            "2. Visualize TTM attention weights on CMA-derived features",
            "3. Decompose predictions: CMA baseline + TTM correction",
            "4. Generate personalized insights from CMA parameters",
            "5. Create clinical report combining both model outputs"
        ]
    },
    "Key Code Components": {
        "CMA Model Fitting": "fit_model(data, ycol='G', tcol='t', tM=None)",
        "CMA Prediction": "cma.run() -> DataFrame with c,m,a,I_S,I_E,G columns",
        "TTM Initialization": "TSModelInference(model_id='ibm/granite-ttm-512-96-r2')",
        "Exogenous Features": "CMA outputs: [L, M, C, A, I_S, I_E, meal_distr]",
        "Residual Calculation": "residual = glucose_true - cma.g_instant",
        "Physics Loss": "L_physics = ||dG/dt - G_dynamics(G,I_E,tM,params)||^2"
    },
    "Expected Benefits": {
        "Accuracy": "10-25% improvement over TTM-only, 15-30% over CMA-only",
        "Data Efficiency": "Requires 50-70% less training data than pure TTM",
        "Interpretability": "CMA parameters provide clinical insights",
        "Generalization": "Better extrapolation to unseen conditions",
        "Personalization": "CMA captures individual circadian patterns",
        "Clinical Trust": "Physics-based constraints ensure physiological plausibility"
    }
}

# Convert to readable format
import json
print("=" * 80)
print("HYBRID TTM + PFUN CMA IMPLEMENTATION PLAN")
print("=" * 80)
print()
for section, content in implementation_plan.items():
    print(f"\n{'='*80}")
    print(f"{section.upper()}")
    print('='*80)
    if isinstance(content, dict):
        for key, value in content.items():
            print(f"\n{key}:")
            if isinstance(value, dict):
                for k, v in value.items():
                    print(f"  • {k}: {v}")
            elif isinstance(value, list):
                for item in value:
                    print(f"  {item}")
            else:
                print(f"  {value}")
    elif isinstance(content, list):
        for item in content:
            print(f"  • {item}")
    print()
