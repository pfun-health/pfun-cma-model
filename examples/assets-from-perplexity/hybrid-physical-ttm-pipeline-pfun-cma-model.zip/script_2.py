
# Create a summary comparison table of the four strategies
import pandas as pd

strategies_comparison = {
    "Strategy": [
        "1. Residual Correction",
        "2. Exogenous Features", 
        "3. Physics-Informed Loss",
        "4. Multi-Stage Training"
    ],
    "Architecture": [
        "G = CMA_baseline + TTM_correction",
        "G = TTM(glucose_hist, CMA_features)",
        "G = TTM(glucose) with physics constraints",
        "G = TTM_pretrained(CMA) → finetune(data)"
    ],
    "Complexity": [
        "Low",
        "Low-Medium",
        "Medium",
        "Medium-High"
    ],
    "Data Requirement": [
        "500-1000 samples",
        "1000-2000 samples",
        "2000-5000 samples",
        "<500 samples"
    ],
    "Interpretability": [
        "Very High",
        "High",
        "Medium-High",
        "High"
    ],
    "Best For": [
        "Most practical scenarios",
        "Leveraging TTM's exogenous capability",
        "Safety-critical applications",
        "Minimal data availability"
    ],
    "Implementation Effort": [
        "Minimal",
        "Low",
        "Moderate",
        "High"
    ],
    "Expected RMSE Improvement": [
        "15-25% vs baselines",
        "15-30% vs baselines",
        "20-30% vs baselines",
        "10-20% vs baselines"
    ]
}

df_strategies = pd.DataFrame(strategies_comparison)

# Save to CSV
df_strategies.to_csv('hybrid_strategies_comparison.csv', index=False)

print("="*100)
print("HYBRID TTM + PFUN CMA: STRATEGY COMPARISON")
print("="*100)
print()
print(df_strategies.to_string(index=False))
print()
print("\n" + "="*100)
print("RECOMMENDATION: Strategy 1 (Residual Correction)")
print("="*100)
print("""
Rationale:
• Simplest to implement and deploy
• Highest interpretability (explicit physics + data decomposition)
• Best data efficiency for typical CGM datasets
• Maintains clinical trust through physiological grounding
• Easy to debug and validate component contributions
• Suitable for production environments

When to consider alternatives:
• Strategy 2: If you want TTM to learn optimal feature weighting from CMA signals
• Strategy 3: If you have abundant data and need hard physics guarantees
• Strategy 4: If you have <500 patient samples and can afford pre-training time
""")

print("\nFiles generated:")
print("  • hybrid-ttm-cma-impl.md (comprehensive implementation guide)")
print("  • hybrid_strategies_comparison.csv (strategy comparison table)")
