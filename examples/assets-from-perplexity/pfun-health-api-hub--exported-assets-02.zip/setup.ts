/**
 * Test Setup Configuration
 * Configures Vitest with jsdom environment for React component testing
 */

import '@testing-library/jest-dom';
import { beforeAll, afterEach, afterAll } from 'vitest';
import { cleanup } from '@testing-library/react';
import { server } from './mocks/server';

// Start Mock Service Worker before all tests
beforeAll(() => {
  server.listen();
});

// Clean up after each test case (e.g., clearing jsdom)
afterEach(() => {
  cleanup();
  server.resetHandlers();
});

// Clean up after all tests are finished (e.g., closing msw server)
afterAll(() => {
  server.close();
});

// Mock Chrome extension APIs for testing
Object.defineProperty(globalThis, 'chrome', {
  value: {
    runtime: {
      id: 'test-extension-id',
      onInstalled: {
        addListener: vi.fn(),
      },
      onMessage: {
        addListener: vi.fn(),
      },
      sendMessage: vi.fn(),
    },
    identity: {
      launchWebAuthFlow: vi.fn(),
      getRedirectURL: vi.fn(() => 'https://test-extension-id.chromiumapp.org/'),
    },
    storage: {
      local: {
        get: vi.fn(),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
      sync: {
        get: vi.fn(),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
      onChanged: {
        addListener: vi.fn(),
      },
    },
    alarms: {
      create: vi.fn(),
      clear: vi.fn(),
      clearAll: vi.fn(),
      onAlarm: {
        addListener: vi.fn(),
      },
    },
    notifications: {
      create: vi.fn(),
      clear: vi.fn(),
    },
    contextMenus: {
      create: vi.fn(),
      update: vi.fn(),
      remove: vi.fn(),
    },
    permissions: {
      contains: vi.fn(),
      request: vi.fn(),
    },
  },
  writable: true,
});

// Mock environment variables
vi.mock('@/config/environment', () => ({
  IS_EXTENSION: false,
  IS_DEV: true,
  HEALTH_API_CONFIGS: {
    dexcom: {
      provider: 'dexcom',
      name: 'Dexcom CGM',
      description: 'Test Dexcom API',
      apiBaseUrl: 'https://sandbox-api.dexcom.com',
      isAvailable: true,
      oauth: {
        clientId: 'test-dexcom-client-id',
        redirectUri: 'http://localhost:3000/auth/callback/dexcom',
        scopes: ['offline_access'],
        authUrl: 'https://sandbox-api.dexcom.com/v2/oauth2/login',
        tokenUrl: 'https://sandbox-api.dexcom.com/v2/oauth2/token',
      }
    },
    fitbit: {
      provider: 'fitbit',
      name: 'Fitbit',
      description: 'Test Fitbit API',
      apiBaseUrl: 'https://api.fitbit.com',
      isAvailable: true,
      oauth: {
        clientId: 'test-fitbit-client-id',
        redirectUri: 'http://localhost:3000/auth/callback/fitbit',
        scopes: ['activity', 'heartrate', 'sleep', 'profile'],
        authUrl: 'https://www.fitbit.com/oauth2/authorize',
        tokenUrl: 'https://api.fitbit.com/oauth2/token',
      }
    }
  },
  getApiConfig: vi.fn(),
  isProviderConfigured: vi.fn(() => true),
  getConfiguredProviders: vi.fn(() => ['dexcom', 'fitbit']),
}));

// Mock crypto for oauth state generation
Object.defineProperty(globalThis, 'crypto', {
  value: {
    getRandomValues: (array) => {
      for (let i = 0; i < array.length; i++) {
        array[i] = Math.floor(Math.random() * 256);
      }
      return array;
    },
  },
});
