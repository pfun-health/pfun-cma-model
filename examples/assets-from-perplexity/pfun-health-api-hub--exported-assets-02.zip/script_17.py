# Create test setup and sample tests
test_setup = '''/**
 * Test Setup Configuration
 * Configures Vitest with jsdom environment for React component testing
 */

import '@testing-library/jest-dom';
import { beforeAll, afterEach, afterAll } from 'vitest';
import { cleanup } from '@testing-library/react';
import { server } from './mocks/server';

// Start Mock Service Worker before all tests
beforeAll(() => {
  server.listen();
});

// Clean up after each test case (e.g., clearing jsdom)
afterEach(() => {
  cleanup();
  server.resetHandlers();
});

// Clean up after all tests are finished (e.g., closing msw server)
afterAll(() => {
  server.close();
});

// Mock Chrome extension APIs for testing
Object.defineProperty(globalThis, 'chrome', {
  value: {
    runtime: {
      id: 'test-extension-id',
      onInstalled: {
        addListener: vi.fn(),
      },
      onMessage: {
        addListener: vi.fn(),
      },
      sendMessage: vi.fn(),
    },
    identity: {
      launchWebAuthFlow: vi.fn(),
      getRedirectURL: vi.fn(() => 'https://test-extension-id.chromiumapp.org/'),
    },
    storage: {
      local: {
        get: vi.fn(),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
      sync: {
        get: vi.fn(),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
      onChanged: {
        addListener: vi.fn(),
      },
    },
    alarms: {
      create: vi.fn(),
      clear: vi.fn(),
      clearAll: vi.fn(),
      onAlarm: {
        addListener: vi.fn(),
      },
    },
    notifications: {
      create: vi.fn(),
      clear: vi.fn(),
    },
    contextMenus: {
      create: vi.fn(),
      update: vi.fn(),
      remove: vi.fn(),
    },
    permissions: {
      contains: vi.fn(),
      request: vi.fn(),
    },
  },
  writable: true,
});

// Mock environment variables
vi.mock('@/config/environment', () => ({
  IS_EXTENSION: false,
  IS_DEV: true,
  HEALTH_API_CONFIGS: {
    dexcom: {
      provider: 'dexcom',
      name: 'Dexcom CGM',
      description: 'Test Dexcom API',
      apiBaseUrl: 'https://sandbox-api.dexcom.com',
      isAvailable: true,
      oauth: {
        clientId: 'test-dexcom-client-id',
        redirectUri: 'http://localhost:3000/auth/callback/dexcom',
        scopes: ['offline_access'],
        authUrl: 'https://sandbox-api.dexcom.com/v2/oauth2/login',
        tokenUrl: 'https://sandbox-api.dexcom.com/v2/oauth2/token',
      }
    },
    fitbit: {
      provider: 'fitbit',
      name: 'Fitbit',
      description: 'Test Fitbit API',
      apiBaseUrl: 'https://api.fitbit.com',
      isAvailable: true,
      oauth: {
        clientId: 'test-fitbit-client-id',
        redirectUri: 'http://localhost:3000/auth/callback/fitbit',
        scopes: ['activity', 'heartrate', 'sleep', 'profile'],
        authUrl: 'https://www.fitbit.com/oauth2/authorize',
        tokenUrl: 'https://api.fitbit.com/oauth2/token',
      }
    }
  },
  getApiConfig: vi.fn(),
  isProviderConfigured: vi.fn(() => true),
  getConfiguredProviders: vi.fn(() => ['dexcom', 'fitbit']),
}));

// Mock crypto for oauth state generation
Object.defineProperty(globalThis, 'crypto', {
  value: {
    getRandomValues: (array) => {
      for (let i = 0; i < array.length; i++) {
        array[i] = Math.floor(Math.random() * 256);
      }
      return array;
    },
  },
});
'''

with open("tests/setup.ts", "w") as f:
    f.write(test_setup)

# Create MSW server for API mocking
msw_server = '''/**
 * Mock Service Worker Server Setup
 * Provides mock API responses for testing
 */

import { setupServer } from 'msw/node';
import { rest } from 'msw';

// Mock API responses
export const handlers = [
  // Dexcom API mocks
  rest.post('https://sandbox-api.dexcom.com/v2/oauth2/token', (req, res, ctx) => {
    return res(
      ctx.json({
        access_token: 'mock-dexcom-access-token',
        refresh_token: 'mock-dexcom-refresh-token',
        expires_in: 7200,
        token_type: 'Bearer',
      })
    );
  }),

  rest.get('https://sandbox-api.dexcom.com/v2/users/self/egvs', (req, res, ctx) => {
    const startDate = req.url.searchParams.get('startDate');
    const endDate = req.url.searchParams.get('endDate');
    
    return res(
      ctx.json([
        {
          systemTime: '2024-01-15T10:00:00.000Z',
          displayTime: '2024-01-15T10:00:00.000Z',
          value: 120,
          status: 'ok',
          trend: 'flat',
          trendRate: 0.5,
        },
        {
          systemTime: '2024-01-15T10:15:00.000Z',
          displayTime: '2024-01-15T10:15:00.000Z',
          value: 125,
          status: 'ok',
          trend: 'fortyFiveUp',
          trendRate: 1.2,
        },
        {
          systemTime: '2024-01-15T10:30:00.000Z',
          displayTime: '2024-01-15T10:30:00.000Z',
          value: 118,
          status: 'ok',
          trend: 'fortyFiveDown',
          trendRate: -0.8,
        },
      ])
    );
  }),

  // Fitbit API mocks
  rest.post('https://api.fitbit.com/oauth2/token', (req, res, ctx) => {
    return res(
      ctx.json({
        access_token: 'mock-fitbit-access-token',
        refresh_token: 'mock-fitbit-refresh-token',
        expires_in: 28800,
        token_type: 'Bearer',
      })
    );
  }),

  rest.get('https://api.fitbit.com/1/user/-/profile.json', (req, res, ctx) => {
    return res(
      ctx.json({
        user: {
          encodedId: 'TEST123',
          displayName: 'Test User',
          avatar: 'https://static0.fitbit.com/images/profile/defaultProfile_100_male.gif',
          timezone: 'America/New_York',
        }
      })
    );
  }),

  rest.get('https://api.fitbit.com/1/user/-/activities/date/:date.json', (req, res, ctx) => {
    return res(
      ctx.json({
        date: req.params.date,
        summary: {
          steps: 8542,
          distance: 6.2,
          caloriesOut: 2134,
          activeMinutes: 67,
          sedentaryMinutes: 1201,
        },
        goals: {
          steps: 10000,
          distance: 8.0,
          floors: 10,
          caloriesOut: 2200,
          activeMinutes: 60,
        },
      })
    );
  }),

  // Error cases for testing
  rest.get('https://api.fitbit.com/1/user/-/error-test', (req, res, ctx) => {
    return res(
      ctx.status(401),
      ctx.json({
        error: 'invalid_token',
        error_description: 'Access token invalid or expired',
      })
    );
  }),
];

export const server = setupServer(...handlers);
'''

with open("tests/mocks/server.ts", "w") as f:
    f.write(msw_server)

# Create sample component test
oauth_button_test = '''/**
 * OAuth Login Button Component Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { OAuthLoginButton, OAuthPanel } from '@/components/auth/OAuthLoginButton';
import { HealthProvider } from '@/types/health-apis';

// Mock the OAuth manager
vi.mock('@/services/auth/oauth-manager', () => ({
  oauthManager: {
    isAuthenticated: vi.fn(),
    authenticate: vi.fn(),
    revokeTokens: vi.fn(),
  },
}));

describe('OAuthLoginButton', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders login button for unauthenticated user', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connect Dexcom CGM')).toBeInTheDocument();
    });
  });

  it('renders connected state for authenticated user', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(true);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connected to Dexcom CGM')).toBeInTheDocument();
    });
  });

  it('calls authenticate when login button is clicked', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockResolvedValue({ access_token: 'test-token' });
    const mockOnAuthSuccess = vi.fn();

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={mockOnAuthSuccess}
        onAuthError={vi.fn()}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    await waitFor(() => {
      expect(mockAuthenticate).toHaveBeenCalledWith(HealthProvider.DEXCOM);
      expect(mockOnAuthSuccess).toHaveBeenCalledWith(HealthProvider.DEXCOM);
    });
  });

  it('calls onAuthError when authentication fails', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockRejectedValue(new Error('Auth failed'));
    const mockOnAuthError = vi.fn();

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={mockOnAuthError}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    await waitFor(() => {
      expect(mockOnAuthError).toHaveBeenCalledWith(
        HealthProvider.DEXCOM,
        expect.any(Error)
      );
    });
  });

  it('shows loading state during authentication', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockImplementation(() => new Promise(resolve => setTimeout(resolve, 100)));

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    expect(screen.getByText('Connecting...')).toBeInTheDocument();
  });
});

describe('OAuthPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders buttons for configured providers', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connect Dexcom CGM')).toBeInTheDocument();
      expect(screen.getByText('Connect Fitbit')).toBeInTheDocument();
    });
  });

  it('shows connection progress', async () => {
    const mockIsAuthenticated = vi.fn()
      .mockResolvedValueOnce(true)  // Dexcom connected
      .mockResolvedValueOnce(false); // Fitbit not connected

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connected to 1 of 2 health services')).toBeInTheDocument();
    });
  });

  it('shows success message when all providers connected', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(true);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Ready to sync health data!')).toBeInTheDocument();
    });
  });
});
'''

with open("tests/components/auth/OAuthLoginButton.test.tsx", "w") as f:
    f.write(oauth_button_test)

# Create API client test
dexcom_api_test = '''/**
 * Dexcom API Client Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { dexcomApi } from '@/services/apis/dexcom/client';
import { HealthProvider } from '@/types/health-apis';
import { server } from '../../mocks/server';

// Mock the OAuth manager
vi.mock('@/services/auth/oauth-manager', () => ({
  oauthManager: {
    getValidTokens: vi.fn(),
    isAuthenticated: vi.fn(),
    authenticate: vi.fn(),
  },
}));

describe('DexcomApiClient', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('fetches glucose readings successfully', async () => {
    const mockGetValidTokens = vi.fn().mockResolvedValue({
      accessToken: 'mock-access-token',
      tokenType: 'Bearer',
    });

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.getValidTokens = mockGetValidTokens;

    const result = await dexcomApi.getGlucoseReadings({
      startDate: '2024-01-15T09:00:00.000Z',
      endDate: '2024-01-15T11:00:00.000Z',
    });

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(3);
    expect(result.data[0]).toMatchObject({
      systemTime: '2024-01-15T10:00:00.000Z',
      value: 120,
      status: 'ok',
      trend: 'flat',
    });
  });

  it('gets current glucose reading', async () => {
    const mockGetValidTokens = vi.fn().mockResolvedValue({
      accessToken: 'mock-access-token',
      tokenType: 'Bearer',
    });

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.getValidTokens = mockGetValidTokens;

    const result = await dexcomApi.getCurrentGlucose();

    expect(result.success).toBe(true);
    expect(result.data).toBeTruthy();
    expect(result.data?.value).toBe(118); // Latest reading from mock
  });

  it('converts glucose data to health data series', async () => {
    const mockGetValidTokens = vi.fn().mockResolvedValue({
      accessToken: 'mock-access-token',
      tokenType: 'Bearer',
    });

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.getValidTokens = mockGetValidTokens;

    const result = await dexcomApi.getGlucoseDataSeries({
      startDate: '2024-01-15T09:00:00.000Z',
      endDate: '2024-01-15T11:00:00.000Z',
    });

    expect(result.success).toBe(true);
    expect(result.data?.provider).toBe(HealthProvider.DEXCOM);
    expect(result.data?.dataType).toBe('glucose');
    expect(result.data?.points).toHaveLength(3);
    expect(result.data?.unit).toBe('mg/dL');
  });

  it('detects glucose alerts correctly', () => {
    // Test low glucose alert
    const lowGlucose = {
      systemTime: '2024-01-15T10:00:00.000Z',
      displayTime: '2024-01-15T10:00:00.000Z',
      value: 50,
      status: 'low' as const,
      trend: 'singleDown' as const,
    };

    const lowAlert = dexcomApi.isGlucoseAlert(lowGlucose);
    expect(lowAlert.isAlert).toBe(true);
    expect(lowAlert.alertType).toBe('urgent-low');

    // Test high glucose alert
    const highGlucose = {
      systemTime: '2024-01-15T10:00:00.000Z',
      displayTime: '2024-01-15T10:00:00.000Z',
      value: 280,
      status: 'high' as const,
      trend: 'singleUp' as const,
    };

    const highAlert = dexcomApi.isGlucoseAlert(highGlucose);
    expect(highAlert.isAlert).toBe(true);
    expect(highAlert.alertType).toBe('urgent-high');

    // Test normal glucose
    const normalGlucose = {
      systemTime: '2024-01-15T10:00:00.000Z',
      displayTime: '2024-01-15T10:00:00.000Z',
      value: 120,
      status: 'ok' as const,
      trend: 'flat' as const,
    };

    const normalAlert = dexcomApi.isGlucoseAlert(normalGlucose);
    expect(normalAlert.isAlert).toBe(false);
  });

  it('calculates time in range correctly', () => {
    const readings = [
      { value: 45, systemTime: '2024-01-15T08:00:00.000Z', displayTime: '2024-01-15T08:00:00.000Z', status: 'low' as const, trend: 'flat' as const }, // Very low
      { value: 65, systemTime: '2024-01-15T09:00:00.000Z', displayTime: '2024-01-15T09:00:00.000Z', status: 'low' as const, trend: 'flat' as const }, // Low
      { value: 120, systemTime: '2024-01-15T10:00:00.000Z', displayTime: '2024-01-15T10:00:00.000Z', status: 'ok' as const, trend: 'flat' as const }, // Target
      { value: 150, systemTime: '2024-01-15T11:00:00.000Z', displayTime: '2024-01-15T11:00:00.000Z', status: 'ok' as const, trend: 'flat' as const }, // Target
      { value: 220, systemTime: '2024-01-15T12:00:00.000Z', displayTime: '2024-01-15T12:00:00.000Z', status: 'high' as const, trend: 'flat' as const }, // High
      { value: 300, systemTime: '2024-01-15T13:00:00.000Z', displayTime: '2024-01-15T13:00:00.000Z', status: 'high' as const, trend: 'flat' as const }, // Very high
    ];

    const tir = dexcomApi.calculateTimeInRange(readings);

    expect(tir.totalReadings).toBe(6);
    expect(tir.veryLow).toBeCloseTo(16.67, 1); // 1/6 * 100
    expect(tir.low).toBeCloseTo(16.67, 1);     // 1/6 * 100
    expect(tir.target).toBeCloseTo(33.33, 1);  // 2/6 * 100
    expect(tir.high).toBeCloseTo(16.67, 1);    // 1/6 * 100
    expect(tir.veryHigh).toBeCloseTo(16.67, 1); // 1/6 * 100
  });

  it('gets trend description correctly', () => {
    expect(dexcomApi.getTrendDescription('doubleUp')).toBe('Rising quickly (>3 mg/dL/min)');
    expect(dexcomApi.getTrendDescription('flat')).toBe('Stable (<1 mg/dL/min change)');
    expect(dexcomApi.getTrendDescription('doubleDown')).toBe('Falling quickly (>3 mg/dL/min)');
  });
});
'''

with open("tests/services/apis/dexcom-api.test.ts", "w") as f:
    f.write(dexcom_api_test)

print("✅ Created Test Files")
print("Created:")
print("- tests/setup.ts - Vitest configuration with jsdom and MSW")
print("- tests/mocks/server.ts - Mock Service Worker for API responses")
print("- tests/components/auth/OAuthLoginButton.test.tsx - OAuth component tests")
print("- tests/services/apis/dexcom-api.test.ts - Dexcom API client tests")
print()
print("Test Features:")
print("- Chrome extension API mocking")
print("- OAuth flow testing")
print("- API response mocking with MSW")
print("- Component rendering and interaction tests")
print("- Health data processing and calculation tests")
print("- Error handling verification")