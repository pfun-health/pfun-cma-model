/**
 * Health Data Dashboard Component
 * Displays health data from multiple providers in a unified view
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { format, subDays, isToday, isYesterday } from 'date-fns';
import { HealthProvider, HealthDataSeries, HealthDataPoint } from '@/types/health-apis';
import { useHealthData } from '@/hooks/useHealthData';

interface HealthDataDashboardProps {
  providers?: HealthProvider[];
  dateRange?: {
    start: string;
    end: string;
  };
  showRealTime?: boolean;
  refreshInterval?: number;
  className?: string;
}

interface MetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  change?: {
    value: number;
    direction: 'up' | 'down' | 'stable';
  };
  status?: 'normal' | 'warning' | 'danger';
  icon?: React.ReactNode;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  unit,
  change,
  status = 'normal',
  icon,
}) => {
  const statusColors = {
    normal: 'border-green-200 bg-green-50',
    warning: 'border-yellow-200 bg-yellow-50',
    danger: 'border-red-200 bg-red-50',
  };

  const changeColors = {
    up: 'text-green-600',
    down: 'text-red-600',
    stable: 'text-gray-600',
  };

  return (
    <div className={`p-4 rounded-lg border-2 ${statusColors[status]} transition-all duration-200 hover:shadow-md`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {icon && <div className="text-gray-600">{icon}</div>}
          <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        </div>
        {change && (
          <div className={`flex items-center text-sm ${changeColors[change.direction]}`}>
            {change.direction === 'up' && (
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L10 5.414 4.707 10.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            )}
            {change.direction === 'down' && (
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L10 14.586l5.293-5.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
            {Math.abs(change.value)}%
          </div>
        )}
      </div>
      <div className="mt-2">
        <div className="flex items-baseline">
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
          {unit && <p className="ml-1 text-sm text-gray-600">{unit}</p>}
        </div>
      </div>
    </div>
  );
};

export const HealthDataDashboard: React.FC<HealthDataDashboardProps> = ({
  providers = [HealthProvider.DEXCOM, HealthProvider.FITBIT],
  dateRange,
  showRealTime = false,
  refreshInterval = 5 * 60 * 1000, // 5 minutes
  className = '',
}) => {
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['glucose', 'steps', 'heart_rate']);
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d' | 'custom'>('7d');

  // Calculate date range based on selection
  const effectiveDateRange = useMemo(() => {
    if (dateRange) return dateRange;

    const end = new Date();
    let start: Date;

    switch (timeRange) {
      case '24h':
        start = subDays(end, 1);
        break;
      case '7d':
        start = subDays(end, 7);
        break;
      case '30d':
        start = subDays(end, 30);
        break;
      default:
        start = subDays(end, 7);
    }

    return {
      start: start.toISOString(),
      end: end.toISOString(),
    };
  }, [dateRange, timeRange]);

  // Fetch health data using our custom hook
  const {
    data: healthData,
    isLoading,
    error,
    refetch,
  } = useHealthData(providers, effectiveDateRange, {
    refreshInterval: showRealTime ? refreshInterval : 0,
  });

  // Process data for visualization
  const processedData = useMemo(() => {
    if (!healthData) return null;

    // Combine all data series by timestamp
    const timeSeriesMap = new Map<string, any>();

    healthData.forEach((series) => {
      series.points.forEach((point) => {
        const dateKey = format(new Date(point.timestamp), 'yyyy-MM-dd HH:mm');

        if (!timeSeriesMap.has(dateKey)) {
          timeSeriesMap.set(dateKey, {
            timestamp: point.timestamp,
            dateTime: dateKey,
            date: format(new Date(point.timestamp), 'MMM dd'),
          });
        }

        const entry = timeSeriesMap.get(dateKey);
        entry[`${point.type}_${point.provider}`] = point.value;
        entry[point.type] = point.value; // Generic key for easier access
      });
    });

    return Array.from(timeSeriesMap.values()).sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
  }, [healthData]);

  // Calculate summary metrics
  const summaryMetrics = useMemo(() => {
    if (!processedData || processedData.length === 0) return null;

    const latestData = processedData[processedData.length - 1];
    const previousData = processedData[processedData.length - 2];

    const calculateChange = (current: number, previous: number) => {
      if (!previous) return null;
      const change = ((current - previous) / previous) * 100;
      return {
        value: Math.round(Math.abs(change)),
        direction: change > 0 ? 'up' : change < 0 ? 'down' : 'stable',
      };
    };

    return {
      glucose: {
        current: latestData?.glucose,
        change: calculateChange(latestData?.glucose, previousData?.glucose),
        status: latestData?.glucose < 70 || latestData?.glucose > 180 ? 'warning' : 'normal',
      },
      steps: {
        current: latestData?.steps,
        change: calculateChange(latestData?.steps, previousData?.steps),
        status: 'normal',
      },
      heartRate: {
        current: latestData?.heart_rate,
        change: calculateChange(latestData?.heart_rate, previousData?.heart_rate),
        status: 'normal',
      },
      calories: {
        current: latestData?.calories,
        change: calculateChange(latestData?.calories, previousData?.calories),
        status: 'normal',
      },
    };
  }, [processedData]);

  // Get provider colors for charts
  const getProviderColor = (provider: HealthProvider) => {
    const colors = {
      [HealthProvider.DEXCOM]: '#f97316', // orange
      [HealthProvider.FITBIT]: '#14b8a6', // teal
      [HealthProvider.APPLE_HEALTH]: '#374151', // gray
      [HealthProvider.GOOGLE_HEALTH]: '#3b82f6', // blue
    };
    return colors[provider] || '#6b7280';
  };

  const formatTooltipValue = (value: any, name: string) => {
    if (name.includes('glucose')) return [`${value} mg/dL`, 'Glucose'];
    if (name.includes('steps')) return [`${value.toLocaleString()} steps`, 'Steps'];
    if (name.includes('heart_rate')) return [`${value} bpm`, 'Heart Rate'];
    if (name.includes('calories')) return [`${value} kcal`, 'Calories'];
    return [value, name];
  };

  const renderTimeRangeSelector = () => (
    <div className="flex space-x-2">
      {[
        { key: '24h', label: '24h' },
        { key: '7d', label: '7d' },
        { key: '30d', label: '30d' },
      ].map(({ key, label }) => (
        <button
          key={key}
          onClick={() => setTimeRange(key as any)}
          className={`px-3 py-1 text-sm rounded-md transition-colors ${
            timeRange === key
              ? 'bg-blue-100 text-blue-800 border-blue-200'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  );

  if (isLoading) {
    return (
      <div className={`space-y-6 ${className}`}>
        <div className="animate-pulse">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded-lg mt-6"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <div className="text-red-500">
          <svg className="mx-auto h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-medium">Failed to load health data</h3>
          <p className="text-sm text-gray-600 mt-1">{error.message}</p>
          <button
            onClick={() => refetch()}
            className="mt-4 px-4 py-2 bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!processedData || processedData.length === 0) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <div className="text-gray-500">
          <svg className="mx-auto h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h2a2 2 0 01-2-2z" />
          </svg>
          <h3 className="text-lg font-medium">No health data available</h3>
          <p className="text-sm text-gray-600 mt-1">
            Connect your health devices or check your data sync settings.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Health Dashboard</h2>
          <p className="text-sm text-gray-600">
            {format(new Date(effectiveDateRange.start), 'MMM dd')} - {format(new Date(effectiveDateRange.end), 'MMM dd')}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {renderTimeRangeSelector()}
          <button
            onClick={() => refetch()}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
            title="Refresh data"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      {summaryMetrics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {summaryMetrics.glucose?.current && (
            <MetricCard
              title="Current Glucose"
              value={summaryMetrics.glucose.current}
              unit="mg/dL"
              change={summaryMetrics.glucose.change}
              status={summaryMetrics.glucose.status}
              icon={
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />
          )}

          {summaryMetrics.steps?.current && (
            <MetricCard
              title="Steps Today"
              value={summaryMetrics.steps.current.toLocaleString()}
              change={summaryMetrics.steps.change}
              icon={
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 0l-2 2a1 1 0 001.414 1.414L8 10.414l1.293 1.293a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              }
            />
          )}

          {summaryMetrics.heartRate?.current && (
            <MetricCard
              title="Heart Rate"
              value={summaryMetrics.heartRate.current}
              unit="bpm"
              change={summaryMetrics.heartRate.change}
              icon={
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
              }
            />
          )}

          {summaryMetrics.calories?.current && (
            <MetricCard
              title="Calories"
              value={summaryMetrics.calories.current.toLocaleString()}
              unit="kcal"
              change={summaryMetrics.calories.change}
              icon={
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" clipRule="evenodd" />
                </svg>
              }
            />
          )}
        </div>
      )}

      {/* Main Chart */}
      <div className="bg-white p-6 rounded-lg border">
        <h3 className="text-lg font-medium mb-4">Health Trends</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={processedData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 12 }}
            />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip 
              formatter={formatTooltipValue}
              labelFormatter={(label) => `Date: ${label}`}
            />
            <Legend />

            {/* Glucose line */}
            {processedData.some(d => d.glucose) && (
              <Line
                type="monotone"
                dataKey="glucose"
                stroke={getProviderColor(HealthProvider.DEXCOM)}
                strokeWidth={2}
                dot={{ r: 3 }}
                name="Glucose (mg/dL)"
              />
            )}

            {/* Steps line (scaled down for visibility) */}
            {processedData.some(d => d.steps) && (
              <Line
                type="monotone"
                dataKey={(data) => data.steps / 100} // Scale down steps
                stroke={getProviderColor(HealthProvider.FITBIT)}
                strokeWidth={2}
                dot={{ r: 3 }}
                name="Steps (×100)"
              />
            )}

            {/* Heart rate line */}
            {processedData.some(d => d.heart_rate) && (
              <Line
                type="monotone"
                dataKey="heart_rate"
                stroke="#ef4444"
                strokeWidth={2}
                dot={{ r: 3 }}
                name="Heart Rate (bpm)"
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Data Status */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Last updated: {format(new Date(), 'MMM dd, HH:mm')}
            {showRealTime && (
              <span className="ml-2 inline-flex items-center">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="ml-1 text-xs">Live</span>
              </span>
            )}
          </div>
          <div className="text-sm text-gray-600">
            {processedData.length} data points
          </div>
        </div>
      </div>
    </div>
  );
};
