# Create comprehensive README file
readme_content = '''# Health API Integration Frontend Boilerplate

A comprehensive TypeScript React frontend boilerplate for integrating health APIs (Dexcom CGM, Fitbit, Apple/Google Health) that can be easily adapted into a Chrome extension.

## 🌟 Features

### 🔐 Authentication & Security
- **OAuth 2.0 Integration** for all major health providers
- **Dual-mode support** - Web app and Chrome extension
- **Automatic token refresh** with proactive scheduling
- **Secure token storage** with encryption
- **CSRF protection** with state parameter validation

### 📊 Health Data Integration
- **Dexcom CGM** - Real-time glucose monitoring, trends, alerts
- **Fitbit** - Activity tracking, sleep analysis, heart rate monitoring
- **Apple Health** - Via third-party APIs (OneTwentyOne)
- **Google Health** - Cloud Healthcare API integration
- **Generic health data format** for unified processing

### 🎯 User Interface
- **React 18** with TypeScript for type safety
- **Tailwind CSS** for responsive design
- **Interactive charts** with Recharts library
- **Real-time dashboards** with live updates
- **Health alerts** and notifications
- **Multi-provider management** panel

### 🔧 Developer Experience  
- **Vite** for fast development and building
- **Vitest** for comprehensive testing
- **MSW** for API mocking in tests
- **ESLint** + **Prettier** for code quality
- **Path aliases** for clean imports
- **Hot reload** in development

### 🌐 Chrome Extension Ready
- **Manifest V3** compatibility
- **chrome.identity** API for OAuth
- **Background sync** with service workers
- **Storage** API for data persistence
- **Notifications** for health alerts
- **Side panel** and popup support

## 🚀 Quick Start

### Prerequisites
- Node.js >= 18.0.0
- Chrome browser (for extension development)
- Health API credentials (Dexcom, Fitbit, etc.)

### Installation

1. **Clone and setup**
   ```bash
   git clone <repository-url>
   cd health-api-frontend-boilerplate
   npm install
   ```

2. **Environment Configuration**
   Create `.env.local`:
   ```bash
   # Dexcom API
   VITE_DEXCOM_CLIENT_ID=your_dexcom_client_id
   
   # Fitbit API
   VITE_FITBIT_CLIENT_ID=your_fitbit_client_id
   
   # Google Health API
   VITE_GOOGLE_CLIENT_ID=your_google_client_id
   
   # Apple Health (via OneTwentyOne)
   VITE_ONETWENTYONE_CLIENT_ID=your_onetwentyone_client_id
   
   # Backend URL
   VITE_BACKEND_URL=http://localhost:8000
   
   # App Base URL (for OAuth redirects)
   VITE_APP_BASE_URL=http://localhost:3000
   
   # Development flags
   VITE_ENABLE_API_MOCKING=false
   VITE_ENABLE_DEBUG=true
   ```

3. **Development**
   ```bash
   # Run web app
   npm run dev
   
   # Run tests
   npm run test
   
   # Run tests with UI
   npm run test:ui
   
   # Build for production
   npm run build
   
   # Build Chrome extension
   npm run build:extension
   ```

### Chrome Extension Setup

1. **Build extension**
   ```bash
   npm run build:extension
   ```

2. **Load in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked" and select `dist-extension` folder

3. **Configure OAuth**
   - Update `extension/manifest.json` with your OAuth client IDs
   - Ensure redirect URIs match your extension ID

## 📁 Project Structure

```
├── src/
│   ├── components/          # React components
│   │   ├── auth/           # OAuth and authentication
│   │   ├── health-data/    # Health data visualization
│   │   ├── ui/             # Reusable UI components
│   │   └── charts/         # Chart components
│   ├── services/           # API clients and services
│   │   ├── auth/           # OAuth manager
│   │   └── apis/           # Health API clients
│   │       ├── dexcom/     # Dexcom CGM API
│   │       ├── fitbit/     # Fitbit API
│   │       ├── apple-health/ # Apple Health integration
│   │       └── google-health/ # Google Health API
│   ├── hooks/              # Custom React hooks
│   ├── types/              # TypeScript type definitions
│   ├── config/             # Configuration files
│   ├── utils/              # Utility functions
│   └── stores/             # State management
├── extension/              # Chrome extension files
│   ├── manifest.json       # Extension manifest
│   ├── background.js       # Service worker
│   └── icons/              # Extension icons
├── tests/                  # Test files
│   ├── components/         # Component tests
│   ├── services/           # Service tests
│   ├── mocks/              # MSW mock handlers
│   └── setup.ts            # Test configuration
└── docs/                   # Documentation
```

## 🔌 API Integration Guide

### Dexcom CGM API

```typescript
import { dexcomApi } from '@/services/apis/dexcom/client';

// Get current glucose reading
const currentGlucose = await dexcomApi.getCurrentGlucose();

// Get glucose readings for date range
const readings = await dexcomApi.getGlucoseReadings({
  startDate: '2024-01-01T00:00:00.000Z',
  endDate: '2024-01-02T00:00:00.000Z'
});

// Check for glucose alerts
const alert = dexcomApi.isGlucoseAlert(reading);
if (alert.isAlert) {
  console.log(alert.message);
}
```

### Fitbit API

```typescript
import { fitbitApi } from '@/services/apis/fitbit/client';

// Get daily activity summary
const activity = await fitbitApi.getDayActivitySummary();

// Get sleep data
const sleep = await fitbitApi.getSleepData();

// Get comprehensive health summary
const healthSummary = await fitbitApi.getDailyHealthSummary();
```

### Using the Health Data Hook

```typescript
import { useHealthData } from '@/hooks/useHealthData';

const MyComponent = () => {
  const { data, isLoading, error } = useHealthData(
    [HealthProvider.DEXCOM, HealthProvider.FITBIT],
    {
      start: '2024-01-01T00:00:00.000Z',
      end: '2024-01-02T00:00:00.000Z'
    },
    {
      refreshInterval: 60000, // 1 minute
      onError: (error) => console.error(error)
    }
  );

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return <HealthDataDashboard data={data} />;
};
```

## 🧪 Testing

The project includes comprehensive tests using Vitest and React Testing Library:

```bash
# Run all tests
npm run test

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch

# Run tests with UI
npm run test:ui
```

### Test Structure
- **Unit tests** for API clients and utilities
- **Component tests** for React components
- **Integration tests** for OAuth flows
- **Mock Service Worker** for API mocking
- **Chrome extension** API mocking

### Example Test

```typescript
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { OAuthLoginButton } from '@/components/auth/OAuthLoginButton';

it('authenticates user when button clicked', async () => {
  render(
    <OAuthLoginButton 
      provider={HealthProvider.DEXCOM}
      onAuthSuccess={mockOnSuccess}
    />
  );

  const button = screen.getByText('Connect Dexcom CGM');
  fireEvent.click(button);

  await waitFor(() => {
    expect(mockOnSuccess).toHaveBeenCalled();
  });
});
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_DEXCOM_CLIENT_ID` | Dexcom OAuth client ID | Yes |
| `VITE_FITBIT_CLIENT_ID` | Fitbit OAuth client ID | Yes |
| `VITE_GOOGLE_CLIENT_ID` | Google OAuth client ID | Yes |
| `VITE_ONETWENTYONE_CLIENT_ID` | OneTwentyOne client ID | No |
| `VITE_BACKEND_URL` | Backend API URL | Yes |
| `VITE_APP_BASE_URL` | App base URL for OAuth | Yes |
| `VITE_ENABLE_API_MOCKING` | Enable MSW mocking | No |
| `VITE_ENABLE_DEBUG` | Enable debug logging | No |

### OAuth Configuration

Each health provider requires OAuth configuration:

1. **Register your application** with the provider
2. **Configure redirect URIs**:
   - Web app: `{VITE_APP_BASE_URL}/auth/callback/{provider}`
   - Extension: `https://{extension-id}.chromiumapp.org/`
3. **Set appropriate scopes** for data access
4. **Add client ID** to environment variables

### Chrome Extension Configuration

Update `extension/manifest.json`:

```json
{
  "oauth2": {
    "client_id": "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/userinfo.profile",
      "https://www.googleapis.com/auth/userinfo.email"
    ]
  },
  "host_permissions": [
    "https://api.dexcom.com/*",
    "https://api.fitbit.com/*"
  ]
}
```

## 🏗️ Architecture

### OAuth Flow

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant OAuth Provider
    participant API

    User->>Frontend: Click "Connect Provider"
    Frontend->>OAuth Provider: Redirect to auth URL
    OAuth Provider->>User: Show consent screen
    User->>OAuth Provider: Grant permission
    OAuth Provider->>Frontend: Redirect with auth code
    Frontend->>OAuth Provider: Exchange code for tokens
    OAuth Provider->>Frontend: Return access/refresh tokens
    Frontend->>API: Make authenticated requests
```

### Data Flow

```mermaid
graph TD
    A[Health Devices] --> B[Health APIs]
    B --> C[OAuth Manager]
    C --> D[API Clients]
    D --> E[Health Data Hook]
    E --> F[React Components]
    F --> G[Dashboard]
    
    H[Chrome Extension] --> C
    H --> I[Background Sync]
    I --> J[Notifications]
```

## 🔒 Security Considerations

### Token Management
- **Secure storage** in localStorage with encryption
- **Automatic refresh** before expiration
- **Revocation support** for logout
- **HTTPS only** for token transmission

### Chrome Extension
- **Manifest V3** compliance
- **Content Security Policy** restrictions
- **Host permissions** limited to required domains
- **Storage** API for sensitive data

### API Security
- **Rate limiting** handling with exponential backoff
- **Error handling** with appropriate retry logic
- **Request validation** and sanitization
- **CSRF protection** with state parameters

## 🚀 Deployment

### Web Application

```bash
# Build for production
npm run build

# Deploy to your hosting provider
# (Vercel, Netlify, AWS S3, etc.)
```

### Chrome Extension

```bash
# Build extension
npm run build:extension

# Package for Chrome Web Store
cd dist-extension
zip -r health-dashboard-extension.zip .

# Upload to Chrome Web Store Developer Dashboard
```

### Environment-Specific Builds

```bash
# Development build
npm run build -- --mode development

# Staging build  
npm run build -- --mode staging

# Production build
npm run build -- --mode production
```

## 📚 API Documentation

### Dexcom CGM API
- **Base URL**: `https://api.dexcom.com` (prod), `https://sandbox-api.dexcom.com` (dev)
- **OAuth Scopes**: `offline_access`
- **Rate Limits**: 1000 requests/hour
- **Data Types**: Glucose readings, statistics, events

### Fitbit API
- **Base URL**: `https://api.fitbit.com`
- **OAuth Scopes**: `activity`, `heartrate`, `sleep`, `profile`, `nutrition`, `weight`
- **Rate Limits**: 150 requests/hour/user
- **Data Types**: Activity, sleep, heart rate, weight, nutrition

### Apple Health (via OneTwentyOne)
- **Base URL**: `https://api.onetwentyone.ai`
- **OAuth Scopes**: `read:health`
- **Data Types**: HealthKit quantities, workouts, samples

### Google Health API
- **Base URL**: `https://healthcare.googleapis.com`
- **OAuth Scopes**: `https://www.googleapis.com/auth/cloud-healthcare`
- **Data Types**: FHIR resources, medical records

## 🤝 Contributing

1. **Fork the repository**
2. **Create feature branch** (`git checkout -b feature/amazing-feature`)
3. **Write tests** for your changes
4. **Ensure tests pass** (`npm run test`)
5. **Commit changes** (`git commit -m 'Add amazing feature'`)
6. **Push to branch** (`git push origin feature/amazing-feature`)
7. **Open Pull Request**

### Code Style
- **TypeScript strict mode** enabled
- **ESLint + Prettier** for formatting
- **Conventional commits** for commit messages
- **Test coverage** > 80%

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Dexcom](https://developer.dexcom.com/) for CGM API
- [Fitbit](https://dev.fitbit.com/) for activity tracking API
- [Google](https://developers.google.com/health) for Health APIs
- [OneTwentyOne](https://onetwentyone.ai/) for Apple Health integration
- [React](https://reactjs.org/) and [Vite](https://vitejs.dev/) teams
- [Chrome Extensions](https://developer.chrome.com/docs/extensions/) documentation

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-repo/discussions)
- **Documentation**: [Project Wiki](https://github.com/your-repo/wiki)

---

**Built with ❤️ for the health tech community**
'''

with open("README.md", "w") as f:
    f.write(readme_content)

print("✅ Created Comprehensive README.md")
print()
print("📋 Project Summary:")
print("================")
print("✅ Complete TypeScript React boilerplate")
print("✅ OAuth 2.0 integration for 4 health providers")
print("✅ Chrome extension Manifest V3 compatibility")
print("✅ Comprehensive testing with Vitest + MSW")
print("✅ Real-time health data dashboard")
print("✅ Production-ready with security best practices")
print("✅ Detailed documentation and examples")
print()
print("🏗️ Architecture:")
print("- OAuth Manager with token refresh")
print("- Base API client with retry logic")
print("- Provider-specific API clients (Dexcom, Fitbit)")
print("- React components with health visualization")
print("- Custom hooks for data management")
print("- Chrome extension background script")
print("- Comprehensive test coverage")
print()
print("🚀 Ready to use! Just add your API credentials and you're set!")