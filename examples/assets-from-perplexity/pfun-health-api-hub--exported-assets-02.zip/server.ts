/**
 * Mock Service Worker Server Setup
 * Provides mock API responses for testing
 */

import { setupServer } from 'msw/node';
import { rest } from 'msw';

// Mock API responses
export const handlers = [
  // Dexcom API mocks
  rest.post('https://sandbox-api.dexcom.com/v2/oauth2/token', (req, res, ctx) => {
    return res(
      ctx.json({
        access_token: 'mock-dexcom-access-token',
        refresh_token: 'mock-dexcom-refresh-token',
        expires_in: 7200,
        token_type: 'Bearer',
      })
    );
  }),

  rest.get('https://sandbox-api.dexcom.com/v2/users/self/egvs', (req, res, ctx) => {
    const startDate = req.url.searchParams.get('startDate');
    const endDate = req.url.searchParams.get('endDate');

    return res(
      ctx.json([
        {
          systemTime: '2024-01-15T10:00:00.000Z',
          displayTime: '2024-01-15T10:00:00.000Z',
          value: 120,
          status: 'ok',
          trend: 'flat',
          trendRate: 0.5,
        },
        {
          systemTime: '2024-01-15T10:15:00.000Z',
          displayTime: '2024-01-15T10:15:00.000Z',
          value: 125,
          status: 'ok',
          trend: 'fortyFiveUp',
          trendRate: 1.2,
        },
        {
          systemTime: '2024-01-15T10:30:00.000Z',
          displayTime: '2024-01-15T10:30:00.000Z',
          value: 118,
          status: 'ok',
          trend: 'fortyFiveDown',
          trendRate: -0.8,
        },
      ])
    );
  }),

  // Fitbit API mocks
  rest.post('https://api.fitbit.com/oauth2/token', (req, res, ctx) => {
    return res(
      ctx.json({
        access_token: 'mock-fitbit-access-token',
        refresh_token: 'mock-fitbit-refresh-token',
        expires_in: 28800,
        token_type: 'Bearer',
      })
    );
  }),

  rest.get('https://api.fitbit.com/1/user/-/profile.json', (req, res, ctx) => {
    return res(
      ctx.json({
        user: {
          encodedId: 'TEST123',
          displayName: 'Test User',
          avatar: 'https://static0.fitbit.com/images/profile/defaultProfile_100_male.gif',
          timezone: 'America/New_York',
        }
      })
    );
  }),

  rest.get('https://api.fitbit.com/1/user/-/activities/date/:date.json', (req, res, ctx) => {
    return res(
      ctx.json({
        date: req.params.date,
        summary: {
          steps: 8542,
          distance: 6.2,
          caloriesOut: 2134,
          activeMinutes: 67,
          sedentaryMinutes: 1201,
        },
        goals: {
          steps: 10000,
          distance: 8.0,
          floors: 10,
          caloriesOut: 2200,
          activeMinutes: 60,
        },
      })
    );
  }),

  // Error cases for testing
  rest.get('https://api.fitbit.com/1/user/-/error-test', (req, res, ctx) => {
    return res(
      ctx.status(401),
      ctx.json({
        error: 'invalid_token',
        error_description: 'Access token invalid or expired',
      })
    );
  }),
];

export const server = setupServer(...handlers);
