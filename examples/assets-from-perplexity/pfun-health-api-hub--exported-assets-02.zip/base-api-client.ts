/**
 * Base API Client for Health APIs
 * Provides common functionality for all health API integrations
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import { HealthProvider, ApiResponse, HealthApiError, ApiErrorCode, OAuthTokens } from '@/types/health-apis';
import { BACKEND_CONFIG, DEV_CONFIG } from '@/config/environment';
import { oauthManager } from '@/services/auth/oauth-manager';

export interface ApiClientConfig {
  provider: HealthProvider;
  baseURL: string;
  timeout?: number;
  retryAttempts?: number;
  retryDelay?: number;
}

export abstract class BaseApiClient {
  protected provider: HealthProvider;
  protected api: AxiosInstance;
  protected retryAttempts: number;
  protected retryDelay: number;

  constructor(config: ApiClientConfig) {
    this.provider = config.provider;
    this.retryAttempts = config.retryAttempts || BACKEND_CONFIG.retryAttempts;
    this.retryDelay = config.retryDelay || BACKEND_CONFIG.retryDelay;

    // Create axios instance
    this.api = axios.create({
      baseURL: config.baseURL,
      timeout: config.timeout || BACKEND_CONFIG.timeout,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  /**
   * Setup axios interceptors for authentication and error handling
   */
  private setupInterceptors(): void {
    // Request interceptor - add auth tokens
    this.api.interceptors.request.use(
      async (config) => {
        // Add OAuth token if available
        const tokens = await oauthManager.getValidTokens(this.provider);
        if (tokens?.accessToken) {
          config.headers = config.headers || {};
          config.headers.Authorization = `${tokens.tokenType} ${tokens.accessToken}`;
        }

        // Add debug logging in dev mode
        if (DEV_CONFIG.enableDebugLogging) {
          console.log(`[${this.provider}] API Request:`, {
            method: config.method?.toUpperCase(),
            url: config.url,
            headers: config.headers,
            data: config.data,
          });
        }

        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor - handle errors and retry
    this.api.interceptors.response.use(
      (response) => {
        if (DEV_CONFIG.enableDebugLogging) {
          console.log(`[${this.provider}] API Response:`, {
            status: response.status,
            data: response.data,
          });
        }
        return response;
      },
      async (error: AxiosError) => {
        return this.handleApiError(error);
      }
    );
  }

  /**
   * Handle API errors with retry logic
   */
  private async handleApiError(error: AxiosError): Promise<AxiosResponse> {
    const config = error.config as AxiosRequestConfig & { _retryCount?: number };

    // Initialize retry count
    config._retryCount = config._retryCount || 0;

    // Handle authentication errors
    if (error.response?.status === 401) {
      // Try to refresh token
      try {
        await oauthManager.refreshTokens(this.provider);

        // Retry the request with new token
        if (config._retryCount < this.retryAttempts) {
          config._retryCount++;
          return this.api.request(config);
        }
      } catch (refreshError) {
        // Refresh failed, user needs to re-authenticate
        throw this.createHealthApiError(ApiErrorCode.TOKEN_EXPIRED, 'Authentication failed, please login again', error);
      }
    }

    // Handle rate limiting
    if (error.response?.status === 429) {
      const retryAfter = error.response.headers['retry-after'];
      const delay = retryAfter ? parseInt(retryAfter) * 1000 : this.retryDelay;

      if (config._retryCount < this.retryAttempts) {
        config._retryCount++;
        await this.sleep(delay);
        return this.api.request(config);
      }

      throw this.createHealthApiError(ApiErrorCode.RATE_LIMITED, 'Rate limit exceeded', error);
    }

    // Handle server errors with retry
    if (error.response?.status && error.response.status >= 500) {
      if (config._retryCount < this.retryAttempts) {
        config._retryCount++;
        await this.sleep(this.retryDelay * Math.pow(2, config._retryCount)); // Exponential backoff
        return this.api.request(config);
      }
    }

    // Handle network errors
    if (!error.response) {
      if (config._retryCount < this.retryAttempts) {
        config._retryCount++;
        await this.sleep(this.retryDelay);
        return this.api.request(config);
      }

      throw this.createHealthApiError(ApiErrorCode.NETWORK_ERROR, 'Network error occurred', error);
    }

    // Create appropriate error
    const errorCode = this.getErrorCodeFromStatus(error.response.status);
    const errorMessage = this.extractErrorMessage(error);

    throw this.createHealthApiError(errorCode, errorMessage, error);
  }

  /**
   * Create standardized health API error
   */
  private createHealthApiError(code: ApiErrorCode, message: string, originalError: AxiosError): HealthApiError {
    return new HealthApiError({
      code,
      message,
      provider: this.provider,
      timestamp: new Date().toISOString(),
      details: {
        status: originalError.response?.status,
        statusText: originalError.response?.statusText,
        data: originalError.response?.data,
        url: originalError.config?.url,
        method: originalError.config?.method,
      },
    });
  }

  /**
   * Map HTTP status codes to API error codes
   */
  private getErrorCodeFromStatus(status: number): ApiErrorCode {
    switch (status) {
      case 400:
        return ApiErrorCode.INVALID_REQUEST;
      case 401:
      case 403:
        return ApiErrorCode.UNAUTHORIZED;
      case 429:
        return ApiErrorCode.RATE_LIMITED;
      case 500:
      case 502:
      case 503:
      case 504:
        return ApiErrorCode.SERVER_ERROR;
      default:
        return ApiErrorCode.SERVER_ERROR;
    }
  }

  /**
   * Extract error message from response
   */
  private extractErrorMessage(error: AxiosError): string {
    const responseData = error.response?.data as any;

    // Try various common error message fields
    if (responseData?.error_description) return responseData.error_description;
    if (responseData?.message) return responseData.message;
    if (responseData?.error) return responseData.error;
    if (responseData?.details) return responseData.details;

    // Fallback to status text or generic message
    if (error.response?.statusText) return error.response.statusText;

    return 'An API error occurred';
  }

  /**
   * Sleep utility for retry delays
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Make authenticated GET request
   */
  protected async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    try {
      const response = await this.api.get<T>(url, config);
      return {
        data: response.data,
        success: true,
      };
    } catch (error) {
      if (error instanceof HealthApiError) {
        return {
          data: null as any,
          success: false,
          error: error.message,
        };
      }
      throw error;
    }
  }

  /**
   * Make authenticated POST request
   */
  protected async post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    try {
      const response = await this.api.post<T>(url, data, config);
      return {
        data: response.data,
        success: true,
      };
    } catch (error) {
      if (error instanceof HealthApiError) {
        return {
          data: null as any,
          success: false,
          error: error.message,
        };
      }
      throw error;
    }
  }

  /**
   * Make authenticated PUT request
   */
  protected async put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    try {
      const response = await this.api.put<T>(url, data, config);
      return {
        data: response.data,
        success: true,
      };
    } catch (error) {
      if (error instanceof HealthApiError) {
        return {
          data: null as any,
          success: false,
          error: error.message,
        };
      }
      throw error;
    }
  }

  /**
   * Make authenticated DELETE request
   */
  protected async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    try {
      const response = await this.api.delete<T>(url, config);
      return {
        data: response.data,
        success: true,
      };
    } catch (error) {
      if (error instanceof HealthApiError) {
        return {
          data: null as any,
          success: false,
          error: error.message,
        };
      }
      throw error;
    }
  }

  /**
   * Check if user is authenticated with this provider
   */
  async isAuthenticated(): Promise<boolean> {
    return oauthManager.isAuthenticated(this.provider);
  }

  /**
   * Authenticate user with this provider
   */
  async authenticate(): Promise<OAuthTokens> {
    return oauthManager.authenticate(this.provider);
  }

  /**
   * Sign out user from this provider
   */
  async signOut(): Promise<void> {
    await oauthManager.revokeTokens(this.provider);
  }

  /**
   * Get current access tokens
   */
  async getTokens(): Promise<OAuthTokens | null> {
    return oauthManager.getValidTokens(this.provider);
  }

  /**
   * Build query string from parameters
   */
  protected buildQueryString(params: Record<string, any>): string {
    const searchParams = new URLSearchParams();

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          value.forEach(v => searchParams.append(key, String(v)));
        } else {
          searchParams.set(key, String(value));
        }
      }
    });

    return searchParams.toString();
  }

  /**
   * Format date for API requests
   */
  protected formatDate(date: Date | string): string {
    if (typeof date === 'string') {
      date = new Date(date);
    }
    return date.toISOString().split('T')[0]; // YYYY-MM-DD format
  }

  /**
   * Format datetime for API requests
   */
  protected formatDateTime(date: Date | string): string {
    if (typeof date === 'string') {
      date = new Date(date);
    }
    return date.toISOString();
  }

  /**
   * Validate date range
   */
  protected validateDateRange(startDate: string, endDate: string): { start: Date; end: Date } {
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      throw new HealthApiError({
        code: ApiErrorCode.INVALID_REQUEST,
        message: 'Invalid date format',
        provider: this.provider,
        timestamp: new Date().toISOString(),
      });
    }

    if (start > end) {
      throw new HealthApiError({
        code: ApiErrorCode.INVALID_REQUEST,
        message: 'Start date must be before end date',
        provider: this.provider,
        timestamp: new Date().toISOString(),
      });
    }

    return { start, end };
  }
}
