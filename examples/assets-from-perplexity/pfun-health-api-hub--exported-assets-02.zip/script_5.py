# First create all the directories we need
import os

# Create the directory structure
directories = [
    "src",
    "src/types",
    "src/config",
    "src/services",
    "src/services/auth",
    "src/services/apis",
    "src/services/apis/dexcom",
    "src/services/apis/fitbit",
    "src/services/apis/apple-health", 
    "src/services/apis/google-health",
    "src/components",
    "src/components/auth",
    "src/components/health-data",
    "src/components/ui",
    "src/components/charts",
    "src/hooks",
    "src/utils",
    "src/stores",
    "src/pages",
    "tests",
    "tests/components",
    "tests/services",
    "tests/utils",
    "extension"
]

for directory in directories:
    os.makedirs(directory, exist_ok=True)
    print(f"Created directory: {directory}")

print("\n✅ All directories created successfully!")