/**
 * Chrome Extension Background Script
 * Handles OAuth flows, data syncing, and background tasks
 */

// Background script for Health API Dashboard Chrome Extension
const ALARM_NAME = 'healthDataSync';
const SYNC_INTERVAL = 15; // minutes
const NOTIFICATION_SETTINGS_KEY = 'notificationSettings';

// Health API endpoints
const API_ENDPOINTS = {
  dexcom: {
    prod: 'https://api.dexcom.com',
    sandbox: 'https://sandbox-api.dexcom.com'
  },
  fitbit: 'https://api.fitbit.com',
  google: 'https://healthcare.googleapis.com'
};

class BackgroundHealthManager {
  constructor() {
    this.setupEventListeners();
    this.initializeAlarms();
  }

  setupEventListeners() {
    // Handle extension installation
    chrome.runtime.onInstalled.addListener((details) => {
      console.log('Health API Dashboard installed:', details.reason);
      this.handleInstallation(details);
    });

    // Handle alarm events (for periodic syncing)
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === ALARM_NAME) {
        this.syncHealthData();
      }
    });

    // Handle OAuth redirect from identity API
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
      return true; // Keep message channel open for async response
    });

    // Handle storage changes
    chrome.storage.onChanged.addListener((changes, namespace) => {
      this.handleStorageChanges(changes, namespace);
    });
  }

  async handleInstallation(details) {
    // Set default settings
    const defaultSettings = {
      syncInterval: SYNC_INTERVAL,
      notifications: {
        glucoseAlerts: true,
        activityReminders: true,
        syncErrors: true
      },
      providers: {
        dexcom: { enabled: false, lastSync: null },
        fitbit: { enabled: false, lastSync: null },
        appleHealth: { enabled: false, lastSync: null },
        googleHealth: { enabled: false, lastSync: null }
      }
    };

    await chrome.storage.sync.set({ settings: defaultSettings });

    // Create context menu items
    chrome.contextMenus.create({
      id: 'openDashboard',
      title: 'Open Health Dashboard',
      contexts: ['all']
    });

    // Set up initial alarm
    this.initializeAlarms();
  }

  async initializeAlarms() {
    // Clear existing alarms
    await chrome.alarms.clearAll();

    // Get sync interval from settings
    const { settings } = await chrome.storage.sync.get('settings');
    const interval = settings?.syncInterval || SYNC_INTERVAL;

    // Create periodic sync alarm
    chrome.alarms.create(ALARM_NAME, {
      delayInMinutes: interval,
      periodInMinutes: interval
    });
  }

  async handleMessage(message, sender, sendResponse) {
    try {
      switch (message.type) {
        case 'GET_AUTH_TOKEN':
          const token = await this.getAuthToken(message.provider);
          sendResponse({ success: true, token });
          break;

        case 'REVOKE_TOKEN':
          await this.revokeToken(message.provider);
          sendResponse({ success: true });
          break;

        case 'SYNC_HEALTH_DATA':
          const syncResult = await this.syncHealthData(message.providers);
          sendResponse({ success: true, result: syncResult });
          break;

        case 'GET_HEALTH_DATA':
          const data = await this.getStoredHealthData(message.provider, message.dateRange);
          sendResponse({ success: true, data });
          break;

        case 'UPDATE_SETTINGS':
          await this.updateSettings(message.settings);
          sendResponse({ success: true });
          break;

        default:
          sendResponse({ success: false, error: 'Unknown message type' });
      }
    } catch (error) {
      console.error('Background script error:', error);
      sendResponse({ 
        success: false, 
        error: error.message || 'Background script error' 
      });
    }
  }

  async getAuthToken(provider) {
    const config = this.getProviderConfig(provider);

    if (!config) {
      throw new Error(`Provider ${provider} not supported`);
    }

    // Check if we have a valid stored token
    const storedTokens = await chrome.storage.local.get(`tokens_${provider}`);
    const tokenData = storedTokens[`tokens_${provider}`];

    if (tokenData && this.isTokenValid(tokenData)) {
      return tokenData.access_token;
    }

    // If we have a refresh token, try to refresh
    if (tokenData?.refresh_token) {
      try {
        const newTokens = await this.refreshToken(provider, tokenData.refresh_token);
        await this.storeTokens(provider, newTokens);
        return newTokens.access_token;
      } catch (error) {
        console.warn(`Token refresh failed for ${provider}:`, error);
        // Fall through to new OAuth flow
      }
    }

    // Start new OAuth flow
    return this.startOAuthFlow(provider);
  }

  async startOAuthFlow(provider) {
    const config = this.getProviderConfig(provider);

    const authUrl = new URL(config.authUrl);
    authUrl.searchParams.set('client_id', config.clientId);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('redirect_uri', chrome.identity.getRedirectURL());
    authUrl.searchParams.set('scope', config.scopes.join(' '));
    authUrl.searchParams.set('state', this.generateState());

    return new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow({
        url: authUrl.toString(),
        interactive: true
      }, async (redirectUrl) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!redirectUrl) {
          reject(new Error('No redirect URL returned'));
          return;
        }

        try {
          const tokens = await this.exchangeCodeForTokens(provider, redirectUrl);
          await this.storeTokens(provider, tokens);
          resolve(tokens.access_token);
        } catch (error) {
          reject(error);
        }
      });
    });
  }

  async exchangeCodeForTokens(provider, redirectUrl) {
    const url = new URL(redirectUrl);
    const code = url.searchParams.get('code');

    if (!code) {
      throw new Error('No authorization code received');
    }

    const config = this.getProviderConfig(provider);

    const response = await fetch(config.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        client_id: config.clientId,
        redirect_uri: chrome.identity.getRedirectURL(),
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error_description || 'Token exchange failed');
    }

    return response.json();
  }

  async refreshToken(provider, refreshToken) {
    const config = this.getProviderConfig(provider);

    const response = await fetch(config.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: config.clientId,
      })
    });

    if (!response.ok) {
      throw new Error('Token refresh failed');
    }

    return response.json();
  }

  async storeTokens(provider, tokens) {
    const tokenData = {
      ...tokens,
      stored_at: Date.now(),
      expires_at: Date.now() + (tokens.expires_in * 1000),
    };

    await chrome.storage.local.set({
      [`tokens_${provider}`]: tokenData
    });

    // Update provider status
    const { settings } = await chrome.storage.sync.get('settings');
    if (settings) {
      settings.providers[provider].enabled = true;
      settings.providers[provider].lastSync = new Date().toISOString();
      await chrome.storage.sync.set({ settings });
    }
  }

  async revokeToken(provider) {
    // Remove stored tokens
    await chrome.storage.local.remove(`tokens_${provider}`);

    // Update settings
    const { settings } = await chrome.storage.sync.get('settings');
    if (settings) {
      settings.providers[provider].enabled = false;
      settings.providers[provider].lastSync = null;
      await chrome.storage.sync.set({ settings });
    }
  }

  isTokenValid(tokenData) {
    if (!tokenData || !tokenData.access_token) {
      return false;
    }

    const now = Date.now();
    const expiresAt = tokenData.expires_at || (tokenData.stored_at + (tokenData.expires_in * 1000));

    // Consider token expired if it expires within the next 5 minutes
    return now < (expiresAt - 5 * 60 * 1000);
  }

  async syncHealthData(providers = null) {
    console.log('Starting health data sync...');

    const { settings } = await chrome.storage.sync.get('settings');
    if (!settings) return;

    const enabledProviders = providers || Object.keys(settings.providers).filter(
      provider => settings.providers[provider].enabled
    );

    const syncResults = {};

    for (const provider of enabledProviders) {
      try {
        const data = await this.fetchProviderData(provider);
        await this.storeHealthData(provider, data);
        syncResults[provider] = { success: true, recordCount: data.length };

        // Update last sync time
        settings.providers[provider].lastSync = new Date().toISOString();
      } catch (error) {
        console.error(`Sync failed for ${provider}:`, error);
        syncResults[provider] = { success: false, error: error.message };

        // Show error notification if enabled
        if (settings.notifications.syncErrors) {
          this.showNotification({
            type: 'basic',
            iconUrl: 'icons/icon-48.png',
            title: 'Health Sync Error',
            message: `Failed to sync ${provider} data: ${error.message}`
          });
        }
      }
    }

    // Update settings with new sync times
    await chrome.storage.sync.set({ settings });

    return syncResults;
  }

  async fetchProviderData(provider) {
    const token = await this.getAuthToken(provider);
    const config = this.getProviderConfig(provider);

    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const endDate = new Date().toISOString();
    const startDate = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(); // Last 24 hours

    let data = [];

    switch (provider) {
      case 'dexcom':
        const glucoseResponse = await fetch(
          `${config.baseUrl}/v2/users/self/egvs?startDate=${startDate}&endDate=${endDate}`,
          { headers }
        );
        if (glucoseResponse.ok) {
          data = await glucoseResponse.json();
        }
        break;

      case 'fitbit':
        const today = new Date().toISOString().split('T')[0];
        const activityResponse = await fetch(
          `${config.baseUrl}/1/user/-/activities/date/${today}.json`,
          { headers }
        );
        if (activityResponse.ok) {
          const activityData = await activityResponse.json();
          data = [activityData];
        }
        break;

      default:
        console.warn(`Data fetching not implemented for ${provider}`);
    }

    return data;
  }

  async storeHealthData(provider, data) {
    const storageKey = `healthData_${provider}`;
    const timestamp = Date.now();

    // Get existing data
    const existing = await chrome.storage.local.get(storageKey);
    const existingData = existing[storageKey] || [];

    // Add new data with timestamp
    const newData = data.map(item => ({
      ...item,
      _timestamp: timestamp,
      _provider: provider
    }));

    // Merge and keep only last 7 days of data
    const sevenDaysAgo = timestamp - (7 * 24 * 60 * 60 * 1000);
    const mergedData = [...existingData, ...newData].filter(
      item => item._timestamp > sevenDaysAgo
    );

    await chrome.storage.local.set({
      [storageKey]: mergedData
    });
  }

  async getStoredHealthData(provider, dateRange) {
    const storageKey = `healthData_${provider}`;
    const stored = await chrome.storage.local.get(storageKey);

    let data = stored[storageKey] || [];

    // Filter by date range if provided
    if (dateRange) {
      const startTime = new Date(dateRange.start).getTime();
      const endTime = new Date(dateRange.end).getTime();

      data = data.filter(item => {
        const itemTime = item._timestamp || new Date(item.systemTime || item.dateTime || item.date).getTime();
        return itemTime >= startTime && itemTime <= endTime;
      });
    }

    return data;
  }

  async updateSettings(newSettings) {
    const { settings } = await chrome.storage.sync.get('settings');
    const updatedSettings = { ...settings, ...newSettings };

    await chrome.storage.sync.set({ settings: updatedSettings });

    // Update alarm if sync interval changed
    if (newSettings.syncInterval !== settings?.syncInterval) {
      await this.initializeAlarms();
    }
  }

  handleStorageChanges(changes, namespace) {
    // Handle real-time notifications for health alerts
    if (namespace === 'local' && changes.healthData_dexcom) {
      this.checkGlucoseAlerts(changes.healthData_dexcom.newValue);
    }
  }

  async checkGlucoseAlerts(glucoseData) {
    if (!glucoseData || glucoseData.length === 0) return;

    const { settings } = await chrome.storage.sync.get('settings');
    if (!settings?.notifications.glucoseAlerts) return;

    const latestReading = glucoseData[glucoseData.length - 1];
    const value = latestReading.value;

    let alertMessage = null;

    if (value < 54) {
      alertMessage = `🚨 Urgent Low Glucose: ${value} mg/dL`;
    } else if (value < 70) {
      alertMessage = `⚠️ Low Glucose: ${value} mg/dL`;
    } else if (value > 250) {
      alertMessage = `🚨 Urgent High Glucose: ${value} mg/dL`;
    } else if (value > 180) {
      alertMessage = `⚠️ High Glucose: ${value} mg/dL`;
    }

    if (alertMessage) {
      this.showNotification({
        type: 'basic',
        iconUrl: 'icons/icon-48.png',
        title: 'Glucose Alert',
        message: alertMessage,
        priority: value < 54 || value > 250 ? 2 : 1
      });
    }
  }

  async showNotification(options) {
    // Check if notifications permission is granted
    const permission = await chrome.permissions.contains({ permissions: ['notifications'] });
    if (!permission) return;

    chrome.notifications.create(options);
  }

  getProviderConfig(provider) {
    // This would typically come from environment variables or extension storage
    const configs = {
      dexcom: {
        clientId: 'your-dexcom-client-id',
        authUrl: 'https://api.dexcom.com/v2/oauth2/login',
        tokenUrl: 'https://api.dexcom.com/v2/oauth2/token',
        baseUrl: 'https://api.dexcom.com',
        scopes: ['offline_access']
      },
      fitbit: {
        clientId: 'your-fitbit-client-id',
        authUrl: 'https://www.fitbit.com/oauth2/authorize',
        tokenUrl: 'https://api.fitbit.com/oauth2/token',
        baseUrl: 'https://api.fitbit.com',
        scopes: ['activity', 'heartrate', 'sleep', 'profile']
      }
    };

    return configs[provider];
  }

  generateState() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }
}

// Initialize background manager
const healthManager = new BackgroundHealthManager();

console.log('Health API Dashboard background script loaded');
