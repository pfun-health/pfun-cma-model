# Create custom hook for health data management
use_health_data_hook = '''/**
 * useHealthData Hook
 * Custom React hook for managing health data from multiple providers
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useQuery, UseQueryResult } from 'react-query';
import { HealthProvider, HealthDataSeries, HealthApiError } from '@/types/health-apis';
import { dexcomApi } from '@/services/apis/dexcom/client';
import { fitbitApi } from '@/services/apis/fitbit/client';
import { oauthManager } from '@/services/auth/oauth-manager';

interface HealthDataOptions {
  refreshInterval?: number;
  staleTime?: number;
  enabled?: boolean;
  onError?: (error: HealthApiError) => void;
  onSuccess?: (data: HealthDataSeries[]) => void;
}

interface UseHealthDataReturn {
  data: HealthDataSeries[] | null;
  isLoading: boolean;
  error: HealthApiError | null;
  refetch: () => Promise<void>;
  isRefetching: boolean;
  lastUpdated: Date | null;
  connectedProviders: HealthProvider[];
}

/**
 * Hook for fetching and managing health data from multiple providers
 */
export const useHealthData = (
  providers: HealthProvider[],
  dateRange: { start: string; end: string },
  options: HealthDataOptions = {}
): UseHealthDataReturn => {
  const {
    refreshInterval = 0,
    staleTime = 5 * 60 * 1000, // 5 minutes
    enabled = true,
    onError,
    onSuccess,
  } = options;

  const [connectedProviders, setConnectedProviders] = useState<HealthProvider[]>([]);
  const lastUpdatedRef = useRef<Date | null>(null);

  // Check which providers are connected
  useEffect(() => {
    const checkConnections = async () => {
      const connected = await Promise.all(
        providers.map(async (provider) => {
          const isConnected = await oauthManager.isAuthenticated(provider);
          return isConnected ? provider : null;
        })
      );
      
      setConnectedProviders(connected.filter(Boolean) as HealthProvider[]);
    };

    checkConnections();
  }, [providers]);

  // Fetch data for a specific provider
  const fetchProviderData = async (provider: HealthProvider): Promise<HealthDataSeries[]> => {
    const isConnected = await oauthManager.isAuthenticated(provider);
    if (!isConnected) {
      throw new HealthApiError({
        code: 'UNAUTHORIZED',
        message: `Not authenticated with ${provider}`,
        provider,
        timestamp: new Date().toISOString(),
      });
    }

    const dataSeries: HealthDataSeries[] = [];

    try {
      switch (provider) {
        case HealthProvider.DEXCOM:
          const dexcomResponse = await dexcomApi.getGlucoseDataSeries({
            startDate: dateRange.start,
            endDate: dateRange.end,
          });
          
          if (dexcomResponse.success && dexcomResponse.data) {
            dataSeries.push(dexcomResponse.data);
          }
          break;

        case HealthProvider.FITBIT:
          const fitbitResponse = await fitbitApi.getActivityDataSeries(
            dateRange.start,
            dateRange.end
          );
          
          if (fitbitResponse.success && fitbitResponse.data) {
            dataSeries.push(...fitbitResponse.data);
          }

          // Also fetch sleep data
          const sleepResponse = await fitbitApi.getSleepDataSeries(
            dateRange.start,
            dateRange.end
          );
          
          if (sleepResponse.success && sleepResponse.data) {
            dataSeries.push(...sleepResponse.data);
          }
          break;

        case HealthProvider.APPLE_HEALTH:
          // Apple Health integration would go here
          // For now, we'll skip since it requires third-party services
          break;

        case HealthProvider.GOOGLE_HEALTH:
          // Google Health integration would go here
          // For now, we'll skip since it's more complex to implement
          break;

        default:
          console.warn(`Provider ${provider} not implemented yet`);
      }
    } catch (error) {
      console.error(`Failed to fetch data for ${provider}:`, error);
      throw error;
    }

    return dataSeries;
  };

  // Main data fetching function
  const fetchAllHealthData = async (): Promise<HealthDataSeries[]> => {
    if (connectedProviders.length === 0) {
      return [];
    }

    const allDataPromises = connectedProviders.map(async (provider) => {
      try {
        return await fetchProviderData(provider);
      } catch (error) {
        console.error(`Error fetching data for ${provider}:`, error);
        if (onError && error instanceof HealthApiError) {
          onError(error);
        }
        return [];
      }
    });

    const allDataArrays = await Promise.all(allDataPromises);
    const allData = allDataArrays.flat();
    
    lastUpdatedRef.current = new Date();
    
    if (onSuccess && allData.length > 0) {
      onSuccess(allData);
    }

    return allData;
  };

  // Use React Query for data fetching with caching
  const queryKey = [
    'healthData',
    providers.sort().join(','),
    dateRange.start,
    dateRange.end,
    connectedProviders.sort().join(','),
  ];

  const query: UseQueryResult<HealthDataSeries[], HealthApiError> = useQuery(
    queryKey,
    fetchAllHealthData,
    {
      enabled: enabled && connectedProviders.length > 0,
      staleTime,
      refetchInterval: refreshInterval > 0 ? refreshInterval : false,
      refetchIntervalInBackground: true,
      retry: (failureCount, error) => {
        // Don't retry auth errors
        if (error instanceof HealthApiError && error.code === 'UNAUTHORIZED') {
          return false;
        }
        return failureCount < 3;
      },
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    }
  );

  // Manual refetch function
  const refetch = useCallback(async () => {
    await query.refetch();
  }, [query]);

  return {
    data: query.data || null,
    isLoading: query.isLoading,
    error: query.error || null,
    refetch,
    isRefetching: query.isFetching && !query.isLoading,
    lastUpdated: lastUpdatedRef.current,
    connectedProviders,
  };
};

/**
 * Hook for real-time health data (current values)
 */
export const useRealTimeHealthData = (
  providers: HealthProvider[],
  refreshInterval: number = 30000 // 30 seconds
) => {
  const [realTimeData, setRealTimeData] = useState<{
    [key: string]: any;
  }>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<HealthApiError | null>(null);

  const fetchRealTimeData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    const data: { [key: string]: any } = {};

    try {
      await Promise.all(
        providers.map(async (provider) => {
          const isConnected = await oauthManager.isAuthenticated(provider);
          if (!isConnected) return;

          try {
            switch (provider) {
              case HealthProvider.DEXCOM:
                const glucoseResponse = await dexcomApi.getCurrentGlucose();
                if (glucoseResponse.success && glucoseResponse.data) {
                  data.currentGlucose = glucoseResponse.data;
                }
                break;

              case HealthProvider.FITBIT:
                const todaySummary = await fitbitApi.getDailyHealthSummary();
                if (todaySummary.success && todaySummary.data) {
                  data.todayActivity = todaySummary.data.activity;
                  data.todayHeartRate = todaySummary.data.heartRate;
                }
                break;

              default:
                break;
            }
          } catch (providerError) {
            console.error(`Real-time data error for ${provider}:`, providerError);
          }
        })
      );

      setRealTimeData(data);
    } catch (error) {
      console.error('Real-time data fetch error:', error);
      if (error instanceof HealthApiError) {
        setError(error);
      }
    } finally {
      setIsLoading(false);
    }
  }, [providers]);

  // Set up interval for real-time updates
  useEffect(() => {
    fetchRealTimeData(); // Initial fetch

    if (refreshInterval > 0) {
      const interval = setInterval(fetchRealTimeData, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchRealTimeData, refreshInterval]);

  return {
    data: realTimeData,
    isLoading,
    error,
    refresh: fetchRealTimeData,
  };
};

/**
 * Hook for managing health data alerts
 */
export const useHealthAlerts = (providers: HealthProvider[]) => {
  const [alerts, setAlerts] = useState<Array<{
    id: string;
    provider: HealthProvider;
    type: 'info' | 'warning' | 'danger';
    title: string;
    message: string;
    timestamp: Date;
    acknowledged: boolean;
  }>>([]);

  const { data: realTimeData } = useRealTimeHealthData(providers, 60000); // Check every minute

  // Check for alert conditions
  useEffect(() => {
    if (!realTimeData) return;

    const newAlerts: typeof alerts = [];

    // Check glucose alerts
    if (realTimeData.currentGlucose) {
      const glucose = realTimeData.currentGlucose;
      const alertInfo = dexcomApi.isGlucoseAlert(glucose);
      
      if (alertInfo.isAlert) {
        newAlerts.push({
          id: `glucose-${Date.now()}`,
          provider: HealthProvider.DEXCOM,
          type: alertInfo.alertType?.includes('urgent') ? 'danger' : 'warning',
          title: 'Glucose Alert',
          message: alertInfo.message || 'Glucose level needs attention',
          timestamp: new Date(),
          acknowledged: false,
        });
      }
    }

    // Check activity alerts (example: very low step count)
    if (realTimeData.todayActivity) {
      const activity = realTimeData.todayActivity.summary;
      const currentHour = new Date().getHours();
      
      // If it's past noon and steps are very low, create alert
      if (currentHour > 12 && activity.steps < 1000) {
        newAlerts.push({
          id: `steps-${Date.now()}`,
          provider: HealthProvider.FITBIT,
          type: 'info',
          title: 'Low Activity',
          message: 'Consider taking a walk - you have fewer than 1,000 steps today',
          timestamp: new Date(),
          acknowledged: false,
        });
      }
    }

    // Only add new alerts that don't already exist
    const existingAlertMessages = alerts.map(a => a.message);
    const uniqueNewAlerts = newAlerts.filter(
      alert => !existingAlertMessages.includes(alert.message)
    );

    if (uniqueNewAlerts.length > 0) {
      setAlerts(prev => [...prev, ...uniqueNewAlerts]);
    }
  }, [realTimeData, alerts]);

  const acknowledgeAlert = useCallback((alertId: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId 
          ? { ...alert, acknowledged: true }
          : alert
      )
    );
  }, []);

  const dismissAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  }, []);

  const clearAllAlerts = useCallback(() => {
    setAlerts([]);
  }, []);

  return {
    alerts: alerts.filter(alert => !alert.acknowledged),
    acknowledgedAlerts: alerts.filter(alert => alert.acknowledged),
    acknowledgeAlert,
    dismissAlert,
    clearAllAlerts,
    hasUnacknowledgedAlerts: alerts.some(alert => !alert.acknowledged),
  };
};

/**
 * Hook for provider connection management
 */
export const useProviderConnections = (providers: HealthProvider[]) => {
  const [connections, setConnections] = useState<Record<HealthProvider, boolean>>({} as any);
  const [isChecking, setIsChecking] = useState(false);

  const checkConnections = useCallback(async () => {
    setIsChecking(true);
    
    const connectionPromises = providers.map(async (provider) => {
      const isConnected = await oauthManager.isAuthenticated(provider);
      return { provider, isConnected };
    });

    const results = await Promise.all(connectionPromises);
    
    const newConnections: Record<HealthProvider, boolean> = {} as any;
    results.forEach(({ provider, isConnected }) => {
      newConnections[provider] = isConnected;
    });

    setConnections(newConnections);
    setIsChecking(false);
  }, [providers]);

  useEffect(() => {
    checkConnections();
  }, [checkConnections]);

  const connectProvider = useCallback(async (provider: HealthProvider) => {
    try {
      await oauthManager.authenticate(provider);
      await checkConnections(); // Refresh status
    } catch (error) {
      console.error(`Failed to connect ${provider}:`, error);
      throw error;
    }
  }, [checkConnections]);

  const disconnectProvider = useCallback(async (provider: HealthProvider) => {
    try {
      await oauthManager.revokeTokens(provider);
      await checkConnections(); // Refresh status
    } catch (error) {
      console.error(`Failed to disconnect ${provider}:`, error);
      throw error;
    }
  }, [checkConnections]);

  return {
    connections,
    connectedProviders: Object.entries(connections)
      .filter(([_, connected]) => connected)
      .map(([provider]) => provider as HealthProvider),
    isChecking,
    checkConnections,
    connectProvider,
    disconnectProvider,
  };
};
'''

with open("src/hooks/useHealthData.ts", "w") as f:
    f.write(use_health_data_hook)

print("✅ Created useHealthData Hook (src/hooks/useHealthData.ts)")
print("Features:")
print("- Multi-provider health data fetching with React Query")
print("- Real-time data updates with configurable intervals")
print("- Health alerts system (glucose, activity)")
print("- Provider connection management")
print("- Automatic retry logic with exponential backoff")
print("- Error handling and loading states")
print("- Data caching and staleness management")
print("- Authentication status checking")
print("- Alert acknowledgment and dismissal")