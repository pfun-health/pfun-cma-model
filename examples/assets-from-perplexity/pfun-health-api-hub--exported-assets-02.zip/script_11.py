# Create Fitbit API client
fitbit_api = '''/**
 * Fitbit API Client
 * Handles activity, sleep, and health data from Fitbit devices
 */

import { BaseApiClient } from '../base-api-client';
import { 
  HealthProvider, 
  ApiResponse, 
  FitbitProfile,
  FitbitActivitySummary,
  FitbitHeartRateZone,
  FitbitSleepSummary,
  HealthDataSeries,
  HealthDataPoint
} from '@/types/health-apis';
import { HEALTH_API_CONFIGS } from '@/config/environment';
import { format, subDays } from 'date-fns';

export interface FitbitDeviceInfo {
  id: string;
  deviceVersion: string;
  type: string;
  battery: 'High' | 'Medium' | 'Low' | 'Empty';
  batteryLevel: number;
  lastSyncTime: string;
  mac: string;
}

export interface FitbitActivityGoals {
  steps: number;
  distance: number;
  floors: number;
  caloriesOut: number;
  activeMinutes: number;
}

export interface FitbitHeartRateData {
  dateTime: string;
  value: {
    customHeartRateZones: FitbitHeartRateZone[];
    heartRateZones: FitbitHeartRateZone[];
    restingHeartRate?: number;
  };
}

export interface FitbitDetailedActivity {
  date: string;
  summary: FitbitActivitySummary;
  goals: FitbitActivityGoals;
  distances: Array<{
    activity: string;
    distance: number;
  }>;
}

export interface FitbitWeightLog {
  date: string;
  logId: number;
  time: string;
  weight: number;
  bmi: number;
  source: string;
}

export interface FitbitFoodLog {
  date: string;
  summary: {
    calories: number;
    water: number; // ml
  };
  foods: Array<{
    logId: number;
    loggedFood: {
      name: string;
      amount: number;
      unit: string;
      calories: number;
    };
    nutritionalValues: {
      carbs: number;
      fat: number;
      protein: number;
      sodium: number;
      fiber: number;
    };
  }>;
}

export interface FitbitSleepDetail extends FitbitSleepSummary {
  levels: {
    summary: {
      deep: { count: number; minutes: number };
      light: { count: number; minutes: number };
      rem: { count: number; minutes: number };
      wake: { count: number; minutes: number };
    };
    data: Array<{
      dateTime: string;
      level: 'deep' | 'light' | 'rem' | 'wake' | 'restless' | 'awake' | 'asleep';
      seconds: number;
    }>;
  };
  startTime: string;
  endTime: string;
  minutesToFallAsleep: number;
  minutesAwake: number;
  minutesAfterWakeup: number;
  timeInBed: number;
}

export interface FitbitIntradayData {
  activities: Array<{
    dateTime: string;
    value: string;
  }>;
  activitiesHeart: Array<{
    dateTime: string;
    value: {
      customHeartRateZones: FitbitHeartRateZone[];
      heartRateZones: FitbitHeartRateZone[];
      restingHeartRate?: number;
    };
  }>;
}

export class FitbitApiClient extends BaseApiClient {
  constructor() {
    super({
      provider: HealthProvider.FITBIT,
      baseURL: HEALTH_API_CONFIGS[HealthProvider.FITBIT].apiBaseUrl,
    });
  }

  /**
   * Get user profile information
   */
  async getProfile(): Promise<ApiResponse<FitbitProfile>> {
    return this.get<FitbitProfile>('/1/user/-/profile.json');
  }

  /**
   * Get user devices
   */
  async getDevices(): Promise<ApiResponse<FitbitDeviceInfo[]>> {
    return this.get<FitbitDeviceInfo[]>('/1/user/-/devices.json');
  }

  /**
   * Get activity summary for a specific date
   */
  async getDayActivitySummary(date?: string): Promise<ApiResponse<FitbitDetailedActivity>> {
    const targetDate = date || this.formatDate(new Date());
    return this.get<FitbitDetailedActivity>(`/1/user/-/activities/date/${targetDate}.json`);
  }

  /**
   * Get activity summary for date range
   */
  async getActivitySummaries(startDate: string, endDate: string): Promise<ApiResponse<FitbitActivitySummary[]>> {
    this.validateDateRange(startDate, endDate);
    
    const start = this.formatDate(startDate);
    const end = this.formatDate(endDate);
    
    const response = await this.get(`/1/user/-/activities/date/${start}/${end}.json`);
    
    if (!response.success) return response;

    // Transform the response to match our interface
    const activities: FitbitActivitySummary[] = response.data.activities || [];
    
    return {
      data: activities,
      success: true,
    };
  }

  /**
   * Get heart rate data for a specific date
   */
  async getHeartRateData(date?: string): Promise<ApiResponse<FitbitHeartRateData>> {
    const targetDate = date || this.formatDate(new Date());
    return this.get<FitbitHeartRateData>(`/1/user/-/activities/heart/date/${targetDate}/1d.json`);
  }

  /**
   * Get heart rate time series data
   */
  async getHeartRateTimeSeries(startDate: string, endDate: string): Promise<ApiResponse<FitbitHeartRateData[]>> {
    this.validateDateRange(startDate, endDate);
    
    const start = this.formatDate(startDate);
    const end = this.formatDate(endDate);
    
    return this.get<FitbitHeartRateData[]>(`/1/user/-/activities/heart/date/${start}/${end}.json`);
  }

  /**
   * Get sleep data for a specific date
   */
  async getSleepData(date?: string): Promise<ApiResponse<FitbitSleepDetail[]>> {
    const targetDate = date || this.formatDate(new Date());
    return this.get<FitbitSleepDetail[]>(`/1.2/user/-/sleep/date/${targetDate}.json`);
  }

  /**
   * Get sleep log for date range
   */
  async getSleepLog(startDate: string, endDate: string): Promise<ApiResponse<FitbitSleepDetail[]>> {
    this.validateDateRange(startDate, endDate);
    
    const start = this.formatDate(startDate);
    const end = this.formatDate(endDate);
    
    const response = await this.get(`/1.2/user/-/sleep/date/${start}/${end}.json`);
    
    if (!response.success) return response;

    const sleepLogs: FitbitSleepDetail[] = response.data.sleep || [];
    
    return {
      data: sleepLogs,
      success: true,
    };
  }

  /**
   * Get weight log entries
   */
  async getWeightLog(startDate: string, endDate: string): Promise<ApiResponse<FitbitWeightLog[]>> {
    this.validateDateRange(startDate, endDate);
    
    const start = this.formatDate(startDate);
    const end = this.formatDate(endDate);
    
    return this.get<FitbitWeightLog[]>(`/1/user/-/body/log/weight/date/${start}/${end}.json`);
  }

  /**
   * Get food log for a specific date
   */
  async getFoodLog(date?: string): Promise<ApiResponse<FitbitFoodLog>> {
    const targetDate = date || this.formatDate(new Date());
    return this.get<FitbitFoodLog>(`/1/user/-/foods/log/date/${targetDate}.json`);
  }

  /**
   * Get intraday steps data with minute-level detail
   */
  async getIntradaySteps(date?: string): Promise<ApiResponse<{ dateTime: string; value: number }[]>> {
    const targetDate = date || this.formatDate(new Date());
    
    const response = await this.get(`/1/user/-/activities/steps/date/${targetDate}/1d/1min.json`);
    
    if (!response.success) return response;

    const intradayData = response.data['activities-steps-intraday']?.dataset || [];
    
    return {
      data: intradayData.map((item: any) => ({
        dateTime: `${targetDate}T${item.time}:00.000Z`,
        value: parseInt(item.value),
      })),
      success: true,
    };
  }

  /**
   * Get intraday heart rate data with minute-level detail
   */
  async getIntradayHeartRate(date?: string): Promise<ApiResponse<{ dateTime: string; value: number }[]>> {
    const targetDate = date || this.formatDate(new Date());
    
    const response = await this.get(`/1/user/-/activities/heart/date/${targetDate}/1d/1min.json`);
    
    if (!response.success) return response;

    const intradayData = response.data['activities-heart-intraday']?.dataset || [];
    
    return {
      data: intradayData.map((item: any) => ({
        dateTime: `${targetDate}T${item.time}:00.000Z`,
        value: parseInt(item.value),
      })),
      success: true,
    };
  }

  /**
   * Convert Fitbit activity data to generic health data series
   */
  async getActivityDataSeries(startDate: string, endDate: string): Promise<ApiResponse<HealthDataSeries[]>> {
    const response = await this.getActivitySummaries(startDate, endDate);
    
    if (!response.success) {
      return response as ApiResponse<HealthDataSeries[]>;
    }

    const series: HealthDataSeries[] = [
      {
        provider: HealthProvider.FITBIT,
        dataType: 'steps',
        startDate,
        endDate,
        unit: 'steps',
        points: response.data.map((activity) => ({
          timestamp: new Date(activity.date).toISOString(),
          value: activity.steps,
          unit: 'steps',
          type: 'steps',
          provider: HealthProvider.FITBIT,
        })),
      },
      {
        provider: HealthProvider.FITBIT,
        dataType: 'distance',
        startDate,
        endDate,
        unit: 'km',
        points: response.data.map((activity) => ({
          timestamp: new Date(activity.date).toISOString(),
          value: activity.distance,
          unit: 'km',
          type: 'distance',
          provider: HealthProvider.FITBIT,
        })),
      },
      {
        provider: HealthProvider.FITBIT,
        dataType: 'calories',
        startDate,
        endDate,
        unit: 'kcal',
        points: response.data.map((activity) => ({
          timestamp: new Date(activity.date).toISOString(),
          value: activity.caloriesOut,
          unit: 'kcal',
          type: 'calories',
          provider: HealthProvider.FITBIT,
        })),
      },
    ];

    return {
      data: series,
      success: true,
    };
  }

  /**
   * Convert Fitbit sleep data to generic health data series
   */
  async getSleepDataSeries(startDate: string, endDate: string): Promise<ApiResponse<HealthDataSeries[]>> {
    const response = await this.getSleepLog(startDate, endDate);
    
    if (!response.success) {
      return response as ApiResponse<HealthDataSeries[]>;
    }

    // Aggregate sleep data by date
    const sleepByDate = new Map<string, FitbitSleepDetail[]>();
    response.data.forEach(sleep => {
      const date = sleep.date;
      if (!sleepByDate.has(date)) {
        sleepByDate.set(date, []);
      }
      sleepByDate.get(date)!.push(sleep);
    });

    const series: HealthDataSeries[] = [
      {
        provider: HealthProvider.FITBIT,
        dataType: 'sleep_duration',
        startDate,
        endDate,
        unit: 'minutes',
        points: Array.from(sleepByDate.entries()).map(([date, sleeps]) => ({
          timestamp: new Date(date).toISOString(),
          value: sleeps.reduce((total, sleep) => total + sleep.totalMinutesAsleep, 0),
          unit: 'minutes',
          type: 'sleep_duration',
          provider: HealthProvider.FITBIT,
          metadata: {
            efficiency: sleeps.reduce((avg, sleep, i) => (avg * i + sleep.efficiency) / (i + 1), 0),
            sleepSessions: sleeps.length,
          },
        })),
      },
      {
        provider: HealthProvider.FITBIT,
        dataType: 'sleep_efficiency',
        startDate,
        endDate,
        unit: '%',
        points: Array.from(sleepByDate.entries()).map(([date, sleeps]) => ({
          timestamp: new Date(date).toISOString(),
          value: sleeps.reduce((avg, sleep, i) => (avg * i + sleep.efficiency) / (i + 1), 0),
          unit: '%',
          type: 'sleep_efficiency',
          provider: HealthProvider.FITBIT,
        })),
      },
    ];

    return {
      data: series,
      success: true,
    };
  }

  /**
   * Get comprehensive health summary for a date
   */
  async getDailyHealthSummary(date?: string): Promise<ApiResponse<{
    date: string;
    activity: FitbitDetailedActivity;
    heartRate?: FitbitHeartRateData;
    sleep?: FitbitSleepDetail[];
    weight?: FitbitWeightLog[];
    food?: FitbitFoodLog;
  }>> {
    const targetDate = date || this.formatDate(new Date());

    const [activityRes, heartRateRes, sleepRes, weightRes, foodRes] = await Promise.allSettled([
      this.getDayActivitySummary(targetDate),
      this.getHeartRateData(targetDate),
      this.getSleepData(targetDate),
      this.getWeightLog(targetDate, targetDate),
      this.getFoodLog(targetDate),
    ]);

    const summary: any = { date: targetDate };

    if (activityRes.status === 'fulfilled' && activityRes.value.success) {
      summary.activity = activityRes.value.data;
    }

    if (heartRateRes.status === 'fulfilled' && heartRateRes.value.success) {
      summary.heartRate = heartRateRes.value.data;
    }

    if (sleepRes.status === 'fulfilled' && sleepRes.value.success) {
      summary.sleep = sleepRes.value.data;
    }

    if (weightRes.status === 'fulfilled' && weightRes.value.success) {
      summary.weight = weightRes.value.data;
    }

    if (foodRes.status === 'fulfilled' && foodRes.value.success) {
      summary.food = foodRes.value.data;
    }

    return {
      data: summary,
      success: true,
    };
  }

  /**
   * Calculate activity goals achievement percentage
   */
  calculateGoalsAchievement(activity: FitbitDetailedActivity): {
    steps: number;
    distance: number;
    floors: number;
    calories: number;
    activeMinutes: number;
    overall: number;
  } {
    const achievements = {
      steps: activity.goals.steps > 0 ? (activity.summary.steps / activity.goals.steps) * 100 : 0,
      distance: activity.goals.distance > 0 ? (activity.summary.distance / activity.goals.distance) * 100 : 0,
      floors: activity.goals.floors > 0 ? (activity.summary.steps / activity.goals.floors) * 100 : 0, // Assuming steps for floors
      calories: activity.goals.caloriesOut > 0 ? (activity.summary.caloriesOut / activity.goals.caloriesOut) * 100 : 0,
      activeMinutes: activity.goals.activeMinutes > 0 ? (activity.summary.activeMinutes / activity.goals.activeMinutes) * 100 : 0,
    };

    // Calculate overall achievement as average
    const validAchievements = Object.values(achievements).filter(val => val > 0);
    achievements.overall = validAchievements.length > 0 
      ? validAchievements.reduce((sum, val) => sum + val, 0) / validAchievements.length 
      : 0;

    return achievements;
  }

  /**
   * Analyze sleep quality
   */
  analyzeSleepQuality(sleep: FitbitSleepDetail): {
    quality: 'excellent' | 'good' | 'fair' | 'poor';
    score: number;
    insights: string[];
  } {
    const insights: string[] = [];
    let score = 0;

    // Duration analysis (7-9 hours is optimal)
    const hoursSlept = sleep.totalMinutesAsleep / 60;
    if (hoursSlept >= 7 && hoursSlept <= 9) {
      score += 25;
    } else if (hoursSlept >= 6 && hoursSlept <= 10) {
      score += 15;
      insights.push(hoursSlept < 7 ? 'Consider getting more sleep' : 'You might be oversleeping');
    } else {
      score += 5;
      insights.push('Sleep duration is not optimal');
    }

    // Efficiency analysis (85%+ is good)
    if (sleep.efficiency >= 85) {
      score += 25;
    } else if (sleep.efficiency >= 75) {
      score += 15;
      insights.push('Sleep efficiency could be improved');
    } else {
      score += 5;
      insights.push('Poor sleep efficiency - consider sleep hygiene improvements');
    }

    // Deep sleep analysis (13-23% is normal)
    const deepSleepPercent = (sleep.stages?.deep || 0) / sleep.totalMinutesAsleep * 100;
    if (deepSleepPercent >= 13 && deepSleepPercent <= 23) {
      score += 25;
    } else {
      score += 10;
      insights.push('Deep sleep percentage is outside normal range');
    }

    // REM sleep analysis (20-25% is normal)
    const remSleepPercent = (sleep.stages?.rem || 0) / sleep.totalMinutesAsleep * 100;
    if (remSleepPercent >= 20 && remSleepPercent <= 25) {
      score += 25;
    } else {
      score += 10;
      insights.push('REM sleep percentage could be improved');
    }

    // Determine quality based on score
    let quality: 'excellent' | 'good' | 'fair' | 'poor';
    if (score >= 80) quality = 'excellent';
    else if (score >= 65) quality = 'good';
    else if (score >= 50) quality = 'fair';
    else quality = 'poor';

    return { quality, score, insights };
  }

  /**
   * Get activity trends over time
   */
  async getActivityTrends(days: number = 30): Promise<ApiResponse<{
    stepsTrend: { direction: 'up' | 'down' | 'stable'; change: number };
    caloriesTrend: { direction: 'up' | 'down' | 'stable'; change: number };
    activeMinutesTrend: { direction: 'up' | 'down' | 'stable'; change: number };
  }>> {
    const endDate = new Date();
    const startDate = subDays(endDate, days);

    const response = await this.getActivitySummaries(
      startDate.toISOString(),
      endDate.toISOString()
    );

    if (!response.success) {
      return response as any;
    }

    const activities = response.data;
    if (activities.length < 7) {
      return {
        success: false,
        error: 'Not enough data for trend analysis',
        data: null as any,
      };
    }

    // Split data into first and second half
    const midPoint = Math.floor(activities.length / 2);
    const firstHalf = activities.slice(0, midPoint);
    const secondHalf = activities.slice(midPoint);

    const firstHalfAvg = {
      steps: firstHalf.reduce((sum, a) => sum + a.steps, 0) / firstHalf.length,
      calories: firstHalf.reduce((sum, a) => sum + a.caloriesOut, 0) / firstHalf.length,
      activeMinutes: firstHalf.reduce((sum, a) => sum + a.activeMinutes, 0) / firstHalf.length,
    };

    const secondHalfAvg = {
      steps: secondHalf.reduce((sum, a) => sum + a.steps, 0) / secondHalf.length,
      calories: secondHalf.reduce((sum, a) => sum + a.caloriesOut, 0) / secondHalf.length,
      activeMinutes: secondHalf.reduce((sum, a) => sum + a.activeMinutes, 0) / secondHalf.length,
    };

    const getTrend = (oldVal: number, newVal: number) => {
      const change = ((newVal - oldVal) / oldVal) * 100;
      const direction = Math.abs(change) < 5 ? 'stable' : change > 0 ? 'up' : 'down';
      return { direction, change: Math.round(change) };
    };

    return {
      data: {
        stepsTrend: getTrend(firstHalfAvg.steps, secondHalfAvg.steps),
        caloriesTrend: getTrend(firstHalfAvg.calories, secondHalfAvg.calories),
        activeMinutesTrend: getTrend(firstHalfAvg.activeMinutes, secondHalfAvg.activeMinutes),
      },
      success: true,
    };
  }
}

// Export singleton instance
export const fitbitApi = new FitbitApiClient();
'''

with open("src/services/apis/fitbit/client.ts", "w") as f:
    f.write(fitbit_api)

print("✅ Created Fitbit API Client (src/services/apis/fitbit/client.ts)")
print("Features:")
print("- Complete Fitbit API integration")
print("- Activity tracking (steps, distance, calories)")
print("- Heart rate monitoring with zones")
print("- Sleep analysis with quality scoring")
print("- Weight and nutrition logging")
print("- Intraday minute-level data")
print("- Goal achievement tracking")
print("- Activity trend analysis")
print("- Comprehensive daily health summaries")
print("- Sleep quality insights and recommendations")