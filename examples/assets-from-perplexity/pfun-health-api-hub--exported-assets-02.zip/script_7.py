# Create environment configuration
env_config = '''/**
 * Environment configuration for health API integrations
 */

import { HealthProvider, HealthApiConfig } from '@/types/health-apis';

// Runtime environment detection
export const IS_EXTENSION = typeof window !== 'undefined' && !!window.chrome?.extension;
export const IS_DEV = import.meta.env.DEV;

// OAuth redirect URIs - different for extension vs web app
const getRedirectUri = (provider: string): string => {
  if (IS_EXTENSION) {
    // Chrome extension OAuth redirect
    return `https://${chrome.runtime.id}.chromiumapp.org/`;
  }
  
  // Web app OAuth redirect  
  const baseUrl = IS_DEV 
    ? 'http://localhost:3000'
    : import.meta.env.VITE_APP_BASE_URL || window.location.origin;
    
  return `${baseUrl}/auth/callback/${provider}`;
};

// Health API Configurations
export const HEALTH_API_CONFIGS: Record<HealthProvider, HealthApiConfig> = {
  [HealthProvider.DEXCOM]: {
    provider: HealthProvider.DEXCOM,
    name: 'Dexcom CGM',
    description: 'Continuous Glucose Monitoring data from Dexcom devices',
    apiBaseUrl: IS_DEV 
      ? 'https://sandbox-api.dexcom.com'
      : 'https://api.dexcom.com',
    isAvailable: true,
    oauth: {
      clientId: import.meta.env.VITE_DEXCOM_CLIENT_ID || '',
      redirectUri: getRedirectUri('dexcom'),
      scopes: ['offline_access'],
      authUrl: IS_DEV 
        ? 'https://sandbox-api.dexcom.com/v2/oauth2/login'
        : 'https://api.dexcom.com/v2/oauth2/login',
      tokenUrl: IS_DEV
        ? 'https://sandbox-api.dexcom.com/v2/oauth2/token'
        : 'https://api.dexcom.com/v2/oauth2/token',
    }
  },
  
  [HealthProvider.FITBIT]: {
    provider: HealthProvider.FITBIT,
    name: 'Fitbit',
    description: 'Activity, sleep, and health data from Fitbit devices',
    apiBaseUrl: 'https://api.fitbit.com',
    isAvailable: true,
    oauth: {
      clientId: import.meta.env.VITE_FITBIT_CLIENT_ID || '',
      redirectUri: getRedirectUri('fitbit'),
      scopes: [
        'activity',
        'heartrate', 
        'sleep',
        'profile',
        'nutrition',
        'weight'
      ],
      authUrl: 'https://www.fitbit.com/oauth2/authorize',
      tokenUrl: 'https://api.fitbit.com/oauth2/token',
    }
  },
  
  [HealthProvider.APPLE_HEALTH]: {
    provider: HealthProvider.APPLE_HEALTH,
    name: 'Apple Health',
    description: 'Health and fitness data from Apple Health via OneTwentyOne API',
    apiBaseUrl: 'https://api.onetwentyone.ai',
    isAvailable: true, // Note: Requires OneTwentyOne or similar third-party service
    oauth: {
      clientId: import.meta.env.VITE_ONETWENTYONE_CLIENT_ID || '',
      redirectUri: getRedirectUri('apple-health'),
      scopes: ['read:health'],
      authUrl: 'https://api.onetwentyone.ai/oauth/authorize',
      tokenUrl: 'https://api.onetwentyone.ai/oauth/token',
    }
  },
  
  [HealthProvider.GOOGLE_HEALTH]: {
    provider: HealthProvider.GOOGLE_HEALTH,
    name: 'Google Health',
    description: 'Health data via Google Cloud Healthcare API',
    apiBaseUrl: 'https://healthcare.googleapis.com',
    isAvailable: true,
    oauth: {
      clientId: import.meta.env.VITE_GOOGLE_CLIENT_ID || '',
      redirectUri: getRedirectUri('google-health'),
      scopes: [
        'https://www.googleapis.com/auth/cloud-healthcare',
        'https://www.googleapis.com/auth/userinfo.profile',
        'https://www.googleapis.com/auth/userinfo.email'
      ],
      authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
      tokenUrl: 'https://oauth2.googleapis.com/token',
    }
  }
};

// Backend API Configuration
export const BACKEND_CONFIG = {
  baseUrl: import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000',
  apiVersion: 'v1',
  timeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000,
};

// OAuth Configuration
export const OAUTH_CONFIG = {
  stateLength: 32,
  tokenStorageKey: 'health_api_tokens',
  refreshThresholdMinutes: 5, // Refresh tokens when they expire in 5 minutes
  maxRefreshAttempts: 3,
};

// Chrome Extension Configuration
export const EXTENSION_CONFIG = {
  popupWidth: 400,
  popupHeight: 600,
  optionsWidth: 800,
  optionsHeight: 600,
  backgroundSyncInterval: 5 * 60 * 1000, // 5 minutes
  dataRetentionDays: 30,
};

// Development & Testing Configuration
export const DEV_CONFIG = {
  enableApiMocking: IS_DEV && import.meta.env.VITE_ENABLE_API_MOCKING === 'true',
  enableDebugLogging: IS_DEV || import.meta.env.VITE_ENABLE_DEBUG === 'true',
  mockDataRefreshInterval: 10000, // 10 seconds for mock data updates
  skipOAuthValidation: IS_DEV && import.meta.env.VITE_SKIP_OAUTH === 'true',
};

// Utility functions
export const getApiConfig = (provider: HealthProvider): HealthApiConfig => {
  const config = HEALTH_API_CONFIGS[provider];
  if (!config) {
    throw new Error(`No configuration found for provider: ${provider}`);
  }
  return config;
};

export const getAllAvailableProviders = (): HealthProvider[] => {
  return Object.values(HealthProvider).filter(
    provider => HEALTH_API_CONFIGS[provider].isAvailable
  );
};

export const isProviderConfigured = (provider: HealthProvider): boolean => {
  const config = HEALTH_API_CONFIGS[provider];
  return !!(config?.oauth.clientId && config.isAvailable);
};

export const getConfiguredProviders = (): HealthProvider[] => {
  return getAllAvailableProviders().filter(isProviderConfigured);
};

// Environment validation
export const validateEnvironment = (): { valid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  // Check if at least one provider is configured
  const configuredProviders = getConfiguredProviders();
  if (configuredProviders.length === 0) {
    errors.push('No health API providers are configured. Please set client IDs in environment variables.');
  }
  
  // Validate backend URL
  if (!BACKEND_CONFIG.baseUrl) {
    errors.push('Backend URL is not configured. Set VITE_BACKEND_URL environment variable.');
  }
  
  // Chrome extension specific validation
  if (IS_EXTENSION && typeof chrome === 'undefined') {
    errors.push('Chrome extension APIs are not available.');
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
};

// Export environment info for debugging
export const ENV_INFO = {
  isExtension: IS_EXTENSION,
  isDev: IS_DEV,
  configuredProviders: getConfiguredProviders(),
  backendUrl: BACKEND_CONFIG.baseUrl,
  enableMocking: DEV_CONFIG.enableApiMocking,
} as const;
'''

with open("src/config/environment.ts", "w") as f:
    f.write(env_config)

print("✅ Created environment configuration (src/config/environment.ts)")
print("Features:")
print("- Runtime environment detection (extension vs web app)")
print("- OAuth configuration for all health providers")
print("- Different redirect URIs for extension vs web app")
print("- Backend API configuration")
print("- Development and testing settings")
print("- Configuration validation utilities")