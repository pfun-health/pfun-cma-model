import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig(({ command, mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  const isExtension = mode === 'extension'

  return {
    plugins: [react()],
    resolve: {
      alias: {
        '@': resolve(__dirname, 'src'),
        '@/components': resolve(__dirname, 'src/components'),
        '@/services': resolve(__dirname, 'src/services'),
        '@/hooks': resolve(__dirname, 'src/hooks'),
        '@/types': resolve(__dirname, 'src/types'),
        '@/utils': resolve(__dirname, 'src/utils'),
        '@/config': resolve(__dirname, 'src/config'),
        '@/stores': resolve(__dirname, 'src/stores'),
      }
    },
    define: {
      __IS_EXTENSION__: JSON.stringify(isExtension),
      __DEV__: JSON.stringify(command === 'serve')
    },
    build: isExtension ? {
      outDir: 'dist-extension',
      rollupOptions: {
        input: {
          popup: resolve(__dirname, 'src/popup.html'),
          options: resolve(__dirname, 'src/options.html'),
          background: resolve(__dirname, 'src/background.ts'),
          'content-script': resolve(__dirname, 'src/content-script.ts'),
        },
        output: {
          entryFileNames: '[name].js',
          chunkFileNames: '[name].js',
          assetFileNames: '[name].[ext]'
        }
      }
    } : {
      outDir: 'dist'
    },
    server: {
      port: 3000,
      open: !isExtension
    },
    test: {
      globals: true,
      environment: 'jsdom',
      setupFiles: ['./tests/setup.ts'],
      css: true
    }
  }
})
