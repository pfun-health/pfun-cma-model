# Create Chrome extension manifest
manifest_json = {
  "manifest_version": 3,
  "name": "Health API Dashboard",
  "version": "1.0.0",
  "description": "Unified dashboard for health data from Dexcom, Fitbit, Apple Health, and Google Health APIs",
  "permissions": [
    "identity",
    "storage",
    "alarms",
    "activeTab"
  ],
  "optional_permissions": [
    "notifications"
  ],
  "host_permissions": [
    "https://api.dexcom.com/*",
    "https://sandbox-api.dexcom.com/*",
    "https://api.fitbit.com/*",
    "https://www.fitbit.com/*",
    "https://api.onetwentyone.ai/*",
    "https://healthcare.googleapis.com/*",
    "https://accounts.google.com/*",
    "https://oauth2.googleapis.com/*"
  ],
  "background": {
    "service_worker": "background.js",
    "type": "module"
  },
  "action": {
    "default_popup": "popup.html",
    "default_title": "Health API Dashboard",
    "default_icon": {
      "16": "icons/icon-16.png",
      "32": "icons/icon-32.png",
      "48": "icons/icon-48.png",
      "128": "icons/icon-128.png"
    }
  },
  "options_page": "options.html",
  "side_panel": {
    "default_path": "sidepanel.html"
  },
  "oauth2": {
    "client_id": "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/userinfo.profile",
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/cloud-healthcare"
    ]
  },
  "icons": {
    "16": "icons/icon-16.png",
    "32": "icons/icon-32.png",
    "48": "icons/icon-48.png",
    "128": "icons/icon-128.png"
  },
  "content_security_policy": {
    "extension_pages": "script-src 'self' 'wasm-unsafe-eval'; object-src 'self';"
  },
  "web_accessible_resources": [
    {
      "resources": [
        "*.js",
        "*.css",
        "*.html",
        "icons/*"
      ],
      "matches": [
        "<all_urls>"
      ]
    }
  ]
}

import json
with open("extension/manifest.json", "w") as f:
    json.dump(manifest_json, f, indent=2)

print("✅ Created Chrome Extension Manifest (extension/manifest.json)")
print("Features:")
print("- Manifest V3 compatibility")
print("- OAuth identity permissions")
print("- Host permissions for all health APIs")
print("- Service worker background script")
print("- Popup, options, and side panel support")
print("- Storage and alarms permissions")
print("- Optional notifications")