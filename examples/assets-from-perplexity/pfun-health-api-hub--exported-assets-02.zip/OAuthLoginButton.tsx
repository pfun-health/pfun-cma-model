/**
 * OAuth Login Button Component
 * Handles authentication for health API providers
 */

import React, { useState, useCallback } from 'react';
import { HealthProvider } from '@/types/health-apis';
import { oauthManager } from '@/services/auth/oauth-manager';
import { HEALTH_API_CONFIGS, isProviderConfigured } from '@/config/environment';

interface OAuthLoginButtonProps {
  provider: HealthProvider;
  onAuthSuccess?: (provider: HealthProvider) => void;
  onAuthError?: (provider: HealthProvider, error: Error) => void;
  disabled?: boolean;
  className?: string;
  children?: React.ReactNode;
}

export const OAuthLoginButton: React.FC<OAuthLoginButtonProps> = ({
  provider,
  onAuthSuccess,
  onAuthError,
  disabled = false,
  className = '',
  children,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const config = HEALTH_API_CONFIGS[provider];
  const isConfigured = isProviderConfigured(provider);

  // Check authentication status on mount
  React.useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const authenticated = await oauthManager.isAuthenticated(provider);
        setIsAuthenticated(authenticated);
      } catch (error) {
        console.warn(`Failed to check auth status for ${provider}:`, error);
      }
    };

    checkAuthStatus();
  }, [provider]);

  const handleLogin = useCallback(async () => {
    if (!isConfigured) {
      const error = new Error(`${config.name} is not configured. Please check your environment variables.`);
      onAuthError?.(provider, error);
      return;
    }

    setIsLoading(true);

    try {
      await oauthManager.authenticate(provider);
      setIsAuthenticated(true);
      onAuthSuccess?.(provider);
    } catch (error) {
      console.error(`OAuth login failed for ${provider}:`, error);
      onAuthError?.(provider, error as Error);
    } finally {
      setIsLoading(false);
    }
  }, [provider, isConfigured, config.name, onAuthSuccess, onAuthError]);

  const handleLogout = useCallback(async () => {
    setIsLoading(true);

    try {
      await oauthManager.revokeTokens(provider);
      setIsAuthenticated(false);
    } catch (error) {
      console.error(`OAuth logout failed for ${provider}:`, error);
      // Still consider it logged out locally
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  }, [provider]);

  const getProviderColors = (provider: HealthProvider): { bg: string; hover: string; text: string } => {
    const colors = {
      [HealthProvider.DEXCOM]: {
        bg: 'bg-orange-500',
        hover: 'hover:bg-orange-600',
        text: 'text-white'
      },
      [HealthProvider.FITBIT]: {
        bg: 'bg-teal-500',
        hover: 'hover:bg-teal-600',
        text: 'text-white'
      },
      [HealthProvider.APPLE_HEALTH]: {
        bg: 'bg-gray-800',
        hover: 'hover:bg-gray-900',
        text: 'text-white'
      },
      [HealthProvider.GOOGLE_HEALTH]: {
        bg: 'bg-blue-500',
        hover: 'hover:bg-blue-600',
        text: 'text-white'
      }
    };
    return colors[provider] || colors[HealthProvider.DEXCOM];
  };

  const providerColors = getProviderColors(provider);

  const baseClasses = `
    inline-flex items-center justify-center px-4 py-2 border border-transparent 
    text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 
    transition-colors duration-200 ${providerColors.bg} ${providerColors.hover} ${providerColors.text}
    ${disabled || isLoading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
    ${className}
  `.trim();

  const renderButtonContent = () => {
    if (children) {
      return children;
    }

    if (isLoading) {
      return (
        <>
          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          {isAuthenticated ? 'Signing out...' : 'Connecting...'}
        </>
      );
    }

    if (isAuthenticated) {
      return (
        <>
          <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          Connected to {config.name}
        </>
      );
    }

    return `Connect ${config.name}`;
  };

  if (!isConfigured) {
    return (
      <div className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed">
        <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
        </svg>
        {config.name} not configured
      </div>
    );
  }

  return (
    <button
      type="button"
      className={baseClasses}
      onClick={isAuthenticated ? handleLogout : handleLogin}
      disabled={disabled || isLoading}
      title={isAuthenticated ? `Disconnect from ${config.name}` : `Connect to ${config.name}`}
    >
      {renderButtonContent()}
    </button>
  );
};

/**
 * Multi-Provider OAuth Panel
 * Shows login buttons for all configured providers
 */
interface OAuthPanelProps {
  providers?: HealthProvider[];
  onAuthSuccess?: (provider: HealthProvider) => void;
  onAuthError?: (provider: HealthProvider, error: Error) => void;
  className?: string;
}

export const OAuthPanel: React.FC<OAuthPanelProps> = ({
  providers,
  onAuthSuccess,
  onAuthError,
  className = '',
}) => {
  const [authStates, setAuthStates] = useState<Record<HealthProvider, boolean>>({} as any);

  // Get configured providers if none specified
  const configuredProviders = React.useMemo(() => {
    if (providers) return providers;

    return Object.values(HealthProvider).filter(provider => 
      isProviderConfigured(provider)
    );
  }, [providers]);

  // Check authentication status for all providers
  React.useEffect(() => {
    const checkAllAuthStates = async () => {
      const states: Record<HealthProvider, boolean> = {} as any;

      await Promise.all(
        configuredProviders.map(async (provider) => {
          try {
            states[provider] = await oauthManager.isAuthenticated(provider);
          } catch (error) {
            states[provider] = false;
          }
        })
      );

      setAuthStates(states);
    };

    checkAllAuthStates();
  }, [configuredProviders]);

  const handleAuthSuccess = useCallback((provider: HealthProvider) => {
    setAuthStates(prev => ({ ...prev, [provider]: true }));
    onAuthSuccess?.(provider);
  }, [onAuthSuccess]);

  const handleAuthError = useCallback((provider: HealthProvider, error: Error) => {
    onAuthError?.(provider, error);
  }, [onAuthError]);

  const connectedCount = Object.values(authStates).filter(Boolean).length;
  const totalCount = configuredProviders.length;

  if (configuredProviders.length === 0) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <div className="text-gray-500">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 15.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No Health APIs Configured</h3>
          <p className="mt-1 text-sm text-gray-500">
            Please configure at least one health API provider in your environment variables.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {totalCount > 0 && (
        <div className="text-center">
          <p className="text-sm text-gray-600">
            Connected to {connectedCount} of {totalCount} health services
          </p>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(connectedCount / totalCount) * 100}%` }}
            />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {configuredProviders.map((provider) => (
          <div key={provider} className="flex flex-col">
            <OAuthLoginButton
              provider={provider}
              onAuthSuccess={handleAuthSuccess}
              onAuthError={handleAuthError}
              className="w-full justify-center"
            />
            <p className="text-xs text-gray-500 mt-1 text-center">
              {HEALTH_API_CONFIGS[provider].description}
            </p>
          </div>
        ))}
      </div>

      {connectedCount > 0 && (
        <div className="text-center text-sm text-green-600">
          <svg className="inline w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          Ready to sync health data!
        </div>
      )}
    </div>
  );
};
