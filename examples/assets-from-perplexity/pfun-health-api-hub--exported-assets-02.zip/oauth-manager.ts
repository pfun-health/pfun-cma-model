/**
 * OAuth Manager for Health API Integrations
 * Handles OAuth flows for web app and Chrome extension
 */

import { HealthProvider, OAuthTokens, OAuthState, ApiErrorCode, HealthApiError } from '@/types/health-apis';
import { HEALTH_API_CONFIGS, OAUTH_CONFIG, IS_EXTENSION } from '@/config/environment';
import CryptoJS from 'crypto-js';

interface TokenStorage {
  [provider: string]: {
    tokens: OAuthTokens;
    expiresAt: number;
    refreshAt: number;
  };
}

export class OAuthManager {
  private static instance: OAuthManager;
  private tokenStorage: TokenStorage = {};
  private pendingAuthRequests = new Map<string, { resolve: Function; reject: Function }>();

  private constructor() {
    this.loadStoredTokens();
    this.startTokenRefreshScheduler();
  }

  static getInstance(): OAuthManager {
    if (!OAuthManager.instance) {
      OAuthManager.instance = new OAuthManager();
    }
    return OAuthManager.instance;
  }

  /**
   * Initiate OAuth flow for a provider
   */
  async authenticate(provider: HealthProvider): Promise<OAuthTokens> {
    const config = HEALTH_API_CONFIGS[provider];
    if (!config?.oauth.clientId) {
      throw new HealthApiError({
        code: ApiErrorCode.UNSUPPORTED_PROVIDER,
        message: `Provider ${provider} is not configured`,
        provider,
        timestamp: new Date().toISOString()
      });
    }

    // Check if already authenticated and token is valid
    const existingTokens = await this.getValidTokens(provider);
    if (existingTokens) {
      return existingTokens;
    }

    // Start OAuth flow
    if (IS_EXTENSION) {
      return this.authenticateExtension(provider);
    } else {
      return this.authenticateWebApp(provider);
    }
  }

  /**
   * OAuth flow for Chrome extension using chrome.identity API
   */
  private async authenticateExtension(provider: HealthProvider): Promise<OAuthTokens> {
    if (!chrome?.identity) {
      throw new HealthApiError({
        code: ApiErrorCode.UNSUPPORTED_PROVIDER,
        message: 'Chrome extension identity API not available',
        provider,
        timestamp: new Date().toISOString()
      });
    }

    const config = HEALTH_API_CONFIGS[provider];
    const state = this.generateState(provider);

    const authUrl = this.buildAuthUrl(provider, state);

    return new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow({
        url: authUrl,
        interactive: true
      }, (redirectUrl) => {
        if (chrome.runtime.lastError) {
          reject(new HealthApiError({
            code: ApiErrorCode.UNAUTHORIZED,
            message: chrome.runtime.lastError.message || 'OAuth flow failed',
            provider,
            timestamp: new Date().toISOString()
          }));
          return;
        }

        if (!redirectUrl) {
          reject(new HealthApiError({
            code: ApiErrorCode.UNAUTHORIZED,
            message: 'No redirect URL returned from OAuth flow',
            provider,
            timestamp: new Date().toISOString()
          }));
          return;
        }

        this.handleAuthCallback(redirectUrl, state)
          .then(resolve)
          .catch(reject);
      });
    });
  }

  /**
   * OAuth flow for web application using window redirect
   */
  private async authenticateWebApp(provider: HealthProvider): Promise<OAuthTokens> {
    const state = this.generateState(provider);
    const authUrl = this.buildAuthUrl(provider, state);

    // Store promise resolver for callback handling
    return new Promise((resolve, reject) => {
      this.pendingAuthRequests.set(state, { resolve, reject });

      // Set a timeout for the auth request
      setTimeout(() => {
        if (this.pendingAuthRequests.has(state)) {
          this.pendingAuthRequests.delete(state);
          reject(new HealthApiError({
            code: ApiErrorCode.UNAUTHORIZED,
            message: 'OAuth flow timed out',
            provider,
            timestamp: new Date().toISOString()
          }));
        }
      }, 5 * 60 * 1000); // 5 minute timeout

      // Redirect to OAuth provider
      window.location.href = authUrl;
    });
  }

  /**
   * Handle OAuth callback
   */
  async handleCallback(callbackUrl: string): Promise<void> {
    const url = new URL(callbackUrl);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');
    const error = url.searchParams.get('error');

    if (error) {
      const errorDescription = url.searchParams.get('error_description') || error;
      throw new HealthApiError({
        code: ApiErrorCode.UNAUTHORIZED,
        message: errorDescription,
        provider: HealthProvider.DEXCOM, // Will be determined from state
        timestamp: new Date().toISOString()
      });
    }

    if (!code || !state) {
      throw new HealthApiError({
        code: ApiErrorCode.INVALID_REQUEST,
        message: 'Missing authorization code or state parameter',
        provider: HealthProvider.DEXCOM,
        timestamp: new Date().toISOString()
      });
    }

    await this.handleAuthCallback(callbackUrl, state);
  }

  /**
   * Exchange authorization code for tokens
   */
  private async handleAuthCallback(redirectUrl: string, expectedState: string): Promise<OAuthTokens> {
    const url = new URL(redirectUrl);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');

    if (state !== expectedState) {
      throw new HealthApiError({
        code: ApiErrorCode.INVALID_REQUEST,
        message: 'Invalid state parameter',
        provider: HealthProvider.DEXCOM,
        timestamp: new Date().toISOString()
      });
    }

    const storedState = this.getStoredState(state);
    if (!storedState) {
      throw new HealthApiError({
        code: ApiErrorCode.INVALID_REQUEST,
        message: 'State not found or expired',
        provider: HealthProvider.DEXCOM,
        timestamp: new Date().toISOString()
      });
    }

    const tokens = await this.exchangeCodeForTokens(storedState.provider, code!);
    await this.storeTokens(storedState.provider, tokens);

    // Resolve pending web app request
    const pendingRequest = this.pendingAuthRequests.get(state);
    if (pendingRequest) {
      this.pendingAuthRequests.delete(state);
      pendingRequest.resolve(tokens);
    }

    return tokens;
  }

  /**
   * Exchange authorization code for access tokens
   */
  private async exchangeCodeForTokens(provider: HealthProvider, code: string): Promise<OAuthTokens> {
    const config = HEALTH_API_CONFIGS[provider];

    const tokenData = {
      grant_type: 'authorization_code',
      code,
      redirect_uri: config.oauth.redirectUri,
      client_id: config.oauth.clientId,
    };

    const response = await fetch(config.oauth.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: new URLSearchParams(tokenData).toString(),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new HealthApiError({
        code: ApiErrorCode.SERVER_ERROR,
        message: errorData.error_description || 'Token exchange failed',
        provider,
        timestamp: new Date().toISOString(),
        details: errorData
      });
    }

    const tokenResponse = await response.json();

    return {
      accessToken: tokenResponse.access_token,
      refreshToken: tokenResponse.refresh_token,
      expiresIn: tokenResponse.expires_in || 3600,
      tokenType: tokenResponse.token_type || 'Bearer',
      scope: tokenResponse.scope,
    };
  }

  /**
   * Get valid access tokens for a provider
   */
  async getValidTokens(provider: HealthProvider): Promise<OAuthTokens | null> {
    const stored = this.tokenStorage[provider];
    if (!stored) return null;

    const now = Date.now();

    // Check if token has expired
    if (now >= stored.expiresAt) {
      if (stored.tokens.refreshToken) {
        try {
          const newTokens = await this.refreshTokens(provider);
          return newTokens;
        } catch (error) {
          // Refresh failed, remove stored tokens
          delete this.tokenStorage[provider];
          this.saveTokensToStorage();
          return null;
        }
      }
      return null;
    }

    // Check if we should proactively refresh
    if (now >= stored.refreshAt && stored.tokens.refreshToken) {
      this.refreshTokens(provider).catch(() => {
        // Silently handle refresh failures for proactive refresh
      });
    }

    return stored.tokens;
  }

  /**
   * Refresh access tokens using refresh token
   */
  async refreshTokens(provider: HealthProvider): Promise<OAuthTokens> {
    const stored = this.tokenStorage[provider];
    if (!stored?.tokens.refreshToken) {
      throw new HealthApiError({
        code: ApiErrorCode.TOKEN_EXPIRED,
        message: 'No refresh token available',
        provider,
        timestamp: new Date().toISOString()
      });
    }

    const config = HEALTH_API_CONFIGS[provider];

    const tokenData = {
      grant_type: 'refresh_token',
      refresh_token: stored.tokens.refreshToken,
      client_id: config.oauth.clientId,
    };

    const response = await fetch(config.oauth.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: new URLSearchParams(tokenData).toString(),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new HealthApiError({
        code: ApiErrorCode.TOKEN_EXPIRED,
        message: errorData.error_description || 'Token refresh failed',
        provider,
        timestamp: new Date().toISOString(),
        details: errorData
      });
    }

    const tokenResponse = await response.json();

    const newTokens: OAuthTokens = {
      accessToken: tokenResponse.access_token,
      refreshToken: tokenResponse.refresh_token || stored.tokens.refreshToken,
      expiresIn: tokenResponse.expires_in || 3600,
      tokenType: tokenResponse.token_type || 'Bearer',
      scope: tokenResponse.scope || stored.tokens.scope,
    };

    await this.storeTokens(provider, newTokens);
    return newTokens;
  }

  /**
   * Revoke tokens for a provider
   */
  async revokeTokens(provider: HealthProvider): Promise<void> {
    const stored = this.tokenStorage[provider];
    if (!stored) return;

    // Try to revoke tokens on the server
    try {
      const config = HEALTH_API_CONFIGS[provider];

      // Some providers have revocation endpoints
      const revokeUrls: Record<string, string> = {
        [HealthProvider.GOOGLE_HEALTH]: 'https://oauth2.googleapis.com/revoke',
        [HealthProvider.FITBIT]: 'https://api.fitbit.com/oauth2/revoke',
      };

      const revokeUrl = revokeUrls[provider];
      if (revokeUrl) {
        await fetch(revokeUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            token: stored.tokens.accessToken,
          }).toString(),
        });
      }
    } catch (error) {
      console.warn(`Failed to revoke tokens for ${provider}:`, error);
    }

    // Always remove from local storage
    delete this.tokenStorage[provider];
    this.saveTokensToStorage();
  }

  /**
   * Check if user is authenticated with a provider
   */
  async isAuthenticated(provider: HealthProvider): Promise<boolean> {
    const tokens = await this.getValidTokens(provider);
    return !!tokens;
  }

  /**
   * Build OAuth authorization URL
   */
  private buildAuthUrl(provider: HealthProvider, state: string): string {
    const config = HEALTH_API_CONFIGS[provider];
    const params = new URLSearchParams({
      client_id: config.oauth.clientId,
      redirect_uri: config.oauth.redirectUri,
      scope: config.oauth.scopes.join(' '),
      response_type: 'code',
      state,
      access_type: 'offline', // Request refresh token
    });

    // Provider-specific parameters
    if (provider === HealthProvider.GOOGLE_HEALTH) {
      params.set('include_granted_scopes', 'true');
      params.set('prompt', 'consent');
    } else if (provider === HealthProvider.DEXCOM) {
      // Dexcom uses offline_access scope for refresh token
    }

    return `${config.oauth.authUrl}?${params.toString()}`;
  }

  /**
   * Generate secure random state parameter
   */
  private generateState(provider: HealthProvider): string {
    const randomBytes = CryptoJS.lib.WordArray.random(OAUTH_CONFIG.stateLength);
    const state = CryptoJS.enc.Base64url.stringify(randomBytes);

    const stateData: OAuthState = {
      state,
      provider,
      timestamp: Date.now(),
    };

    // Store state temporarily
    const stateKey = `oauth_state_${state}`;
    if (IS_EXTENSION) {
      chrome.storage.local.set({ [stateKey]: stateData });
    } else {
      sessionStorage.setItem(stateKey, JSON.stringify(stateData));
    }

    return state;
  }

  /**
   * Retrieve stored state data
   */
  private getStoredState(state: string): OAuthState | null {
    const stateKey = `oauth_state_${state}`;

    try {
      let stateData: OAuthState;

      if (IS_EXTENSION) {
        // For extension, this would need to be async, but we'll simplify for now
        const stored = sessionStorage.getItem(stateKey);
        if (!stored) return null;
        stateData = JSON.parse(stored);
      } else {
        const stored = sessionStorage.getItem(stateKey);
        if (!stored) return null;
        stateData = JSON.parse(stored);
      }

      // Clean up stored state
      if (IS_EXTENSION) {
        chrome.storage.local.remove(stateKey);
      } else {
        sessionStorage.removeItem(stateKey);
      }

      // Check if state is expired (1 hour)
      if (Date.now() - stateData.timestamp > 60 * 60 * 1000) {
        return null;
      }

      return stateData;
    } catch {
      return null;
    }
  }

  /**
   * Store tokens securely
   */
  private async storeTokens(provider: HealthProvider, tokens: OAuthTokens): Promise<void> {
    const now = Date.now();
    const expiresAt = now + (tokens.expiresIn * 1000);
    const refreshAt = expiresAt - (OAUTH_CONFIG.refreshThresholdMinutes * 60 * 1000);

    this.tokenStorage[provider] = {
      tokens,
      expiresAt,
      refreshAt,
    };

    this.saveTokensToStorage();
  }

  /**
   * Load tokens from storage
   */
  private loadStoredTokens(): void {
    try {
      const stored = localStorage.getItem(OAUTH_CONFIG.tokenStorageKey);
      if (stored) {
        this.tokenStorage = JSON.parse(stored);
      }
    } catch (error) {
      console.warn('Failed to load stored tokens:', error);
      this.tokenStorage = {};
    }
  }

  /**
   * Save tokens to storage
   */
  private saveTokensToStorage(): void {
    try {
      localStorage.setItem(OAUTH_CONFIG.tokenStorageKey, JSON.stringify(this.tokenStorage));
    } catch (error) {
      console.warn('Failed to save tokens to storage:', error);
    }
  }

  /**
   * Start background token refresh scheduler
   */
  private startTokenRefreshScheduler(): void {
    // Check for tokens that need refresh every 5 minutes
    setInterval(() => {
      Object.keys(this.tokenStorage).forEach(async (providerKey) => {
        const provider = providerKey as HealthProvider;
        const stored = this.tokenStorage[provider];

        if (stored && stored.tokens.refreshToken && Date.now() >= stored.refreshAt) {
          try {
            await this.refreshTokens(provider);
          } catch (error) {
            console.warn(`Background token refresh failed for ${provider}:`, error);
          }
        }
      });
    }, 5 * 60 * 1000);
  }
}

// Export singleton instance
export const oauthManager = OAuthManager.getInstance();
