# Create Dexcom API client
dexcom_api = '''/**
 * Dexcom CGM API Client
 * Handles continuous glucose monitoring data from Dexcom devices
 */

import { BaseApiClient } from '../base-api-client';
import { 
  HealthProvider, 
  ApiResponse, 
  DexcomGlucoseReading, 
  DexcomDataRange,
  HealthDataSeries,
  HealthDataPoint
} from '@/types/health-apis';
import { HEALTH_API_CONFIGS } from '@/config/environment';
import { format, subDays } from 'date-fns';

export interface DexcomDeviceInfo {
  alertScheduleList: Array<{
    alertScheduleName: string;
    isEnabled: boolean;
    isDefaultSchedule: boolean;
  }>;
  unitDisplayMode: 'mg/dL' | 'mmol/L';
  systemTimeOffset: number;
  displayTimeOffset: number;
}

export interface DexcomGlucoseQuery {
  startDate?: string; // YYYY-MM-DDTHH:MM:SS format
  endDate?: string;
}

export interface DexcomEventsQuery extends DexcomGlucoseQuery {
  eventType?: 'carbs' | 'insulin' | 'exercise';
}

export interface DexcomCarbsEvent {
  systemTime: string;
  displayTime: string;
  eventType: 'carbs';
  value: number;
  unit: 'grams';
  eventId: string;
}

export interface DexcomInsulinEvent {
  systemTime: string;
  displayTime: string;
  eventType: 'insulin';
  value: number;
  unit: 'units';
  eventId: string;
  insulinType?: 'rapid' | 'long';
}

export interface DexcomExerciseEvent {
  systemTime: string;
  displayTime: string;
  eventType: 'exercise';
  value: number; // minutes
  unit: 'minutes';
  eventId: string;
  exerciseType?: string;
  intensity?: 'low' | 'medium' | 'high';
}

export type DexcomEvent = DexcomCarbsEvent | DexcomInsulinEvent | DexcomExerciseEvent;

export interface DexcomStatistics {
  hypoglycemiaRisk: 'veryHigh' | 'high' | 'moderate' | 'low';
  min: number;
  max: number;
  mean: number;
  median: number;
  variance: number;
  percentInRange: {
    veryLow: number;  // < 54 mg/dL
    low: number;      // 54-69 mg/dL
    target: number;   // 70-180 mg/dL
    high: number;     // 181-250 mg/dL
    veryHigh: number; // > 250 mg/dL
  };
  coefficientOfVariation: number;
  glucoseManagementIndicator: number; // GMI
}

export class DexcomApiClient extends BaseApiClient {
  constructor() {
    super({
      provider: HealthProvider.DEXCOM,
      baseURL: HEALTH_API_CONFIGS[HealthProvider.DEXCOM].apiBaseUrl,
    });
  }

  /**
   * Get user device information
   */
  async getDeviceInfo(): Promise<ApiResponse<DexcomDeviceInfo>> {
    return this.get<DexcomDeviceInfo>('/v2/users/self/devices');
  }

  /**
   * Get glucose readings within date range
   */
  async getGlucoseReadings(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<DexcomGlucoseReading[]>> {
    // Default to last 24 hours if no dates provided
    const endDate = query.endDate || new Date().toISOString();
    const startDate = query.startDate || subDays(new Date(endDate), 1).toISOString();

    this.validateDateRange(startDate, endDate);

    const params = this.buildQueryString({
      startDate: this.formatDateTime(startDate),
      endDate: this.formatDateTime(endDate),
    });

    return this.get<DexcomGlucoseReading[]>(`/v2/users/self/egvs?${params}`);
  }

  /**
   * Get the most recent glucose reading
   */
  async getCurrentGlucose(): Promise<ApiResponse<DexcomGlucoseReading | null>> {
    const response = await this.getGlucoseReadings({
      startDate: subDays(new Date(), 1).toISOString(),
      endDate: new Date().toISOString(),
    });

    if (!response.success || !response.data || response.data.length === 0) {
      return {
        data: null,
        success: response.success,
        error: response.error || 'No recent glucose data available',
      };
    }

    // Return the most recent reading
    const sortedReadings = response.data.sort(
      (a, b) => new Date(b.systemTime).getTime() - new Date(a.systemTime).getTime()
    );

    return {
      data: sortedReadings[0],
      success: true,
    };
  }

  /**
   * Get glucose statistics for a date range
   */
  async getGlucoseStatistics(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<DexcomStatistics>> {
    const endDate = query.endDate || new Date().toISOString();
    const startDate = query.startDate || subDays(new Date(endDate), 14).toISOString(); // Default 14 days

    this.validateDateRange(startDate, endDate);

    const params = this.buildQueryString({
      startDate: this.formatDateTime(startDate),
      endDate: this.formatDateTime(endDate),
    });

    return this.get<DexcomStatistics>(`/v2/users/self/statistics?${params}`);
  }

  /**
   * Get diabetes events (carbs, insulin, exercise)
   */
  async getEvents(query: DexcomEventsQuery = {}): Promise<ApiResponse<DexcomEvent[]>> {
    const endDate = query.endDate || new Date().toISOString();
    const startDate = query.startDate || subDays(new Date(endDate), 7).toISOString();

    this.validateDateRange(startDate, endDate);

    const params = this.buildQueryString({
      startDate: this.formatDateTime(startDate),
      endDate: this.formatDateTime(endDate),
      eventType: query.eventType,
    });

    return this.get<DexcomEvent[]>(`/v2/users/self/events?${params}`);
  }

  /**
   * Get carbohydrate intake events
   */
  async getCarbsEvents(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<DexcomCarbsEvent[]>> {
    const response = await this.getEvents({ ...query, eventType: 'carbs' });
    return {
      ...response,
      data: response.data as DexcomCarbsEvent[] || [],
    };
  }

  /**
   * Get insulin administration events
   */
  async getInsulinEvents(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<DexcomInsulinEvent[]>> {
    const response = await this.getEvents({ ...query, eventType: 'insulin' });
    return {
      ...response,
      data: response.data as DexcomInsulinEvent[] || [],
    };
  }

  /**
   * Get exercise events
   */
  async getExerciseEvents(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<DexcomExerciseEvent[]>> {
    const response = await this.getEvents({ ...query, eventType: 'exercise' });
    return {
      ...response,
      data: response.data as DexcomExerciseEvent[] || [],
    };
  }

  /**
   * Convert Dexcom glucose readings to generic health data series
   */
  async getGlucoseDataSeries(query: DexcomGlucoseQuery = {}): Promise<ApiResponse<HealthDataSeries>> {
    const response = await this.getGlucoseReadings(query);
    
    if (!response.success) {
      return response as ApiResponse<HealthDataSeries>;
    }

    const points: HealthDataPoint[] = response.data.map((reading) => ({
      timestamp: reading.systemTime,
      value: reading.value,
      unit: 'mg/dL',
      type: 'glucose',
      provider: HealthProvider.DEXCOM,
      metadata: {
        trend: reading.trend,
        trendRate: reading.trendRate,
        status: reading.status,
        displayTime: reading.displayTime,
      },
    }));

    const dataSeries: HealthDataSeries = {
      provider: HealthProvider.DEXCOM,
      dataType: 'glucose',
      startDate: query.startDate || subDays(new Date(), 1).toISOString(),
      endDate: query.endDate || new Date().toISOString(),
      points,
      unit: 'mg/dL',
    };

    return {
      data: dataSeries,
      success: true,
    };
  }

  /**
   * Check if glucose reading indicates an alert condition
   */
  isGlucoseAlert(reading: DexcomGlucoseReading): {
    isAlert: boolean;
    alertType?: 'low' | 'high' | 'urgent-low' | 'urgent-high';
    message?: string;
  } {
    const { value, status } = reading;

    if (status === 'low' || value < 54) {
      return {
        isAlert: true,
        alertType: value < 54 ? 'urgent-low' : 'low',
        message: `Low glucose: ${value} mg/dL`,
      };
    }

    if (status === 'high' || value > 250) {
      return {
        isAlert: true,
        alertType: value > 250 ? 'urgent-high' : 'high', 
        message: `High glucose: ${value} mg/dL`,
      };
    }

    return { isAlert: false };
  }

  /**
   * Get trend arrow description
   */
  getTrendDescription(trend: DexcomGlucoseReading['trend']): string {
    const descriptions: Record<DexcomGlucoseReading['trend'], string> = {
      'doubleUp': 'Rising quickly (>3 mg/dL/min)',
      'singleUp': 'Rising (2-3 mg/dL/min)',
      'fortyFiveUp': 'Rising slowly (1-2 mg/dL/min)',
      'flat': 'Stable (<1 mg/dL/min change)',
      'fortyFiveDown': 'Falling slowly (1-2 mg/dL/min)',
      'singleDown': 'Falling (2-3 mg/dL/min)',
      'doubleDown': 'Falling quickly (>3 mg/dL/min)',
      'none': 'No trend available',
      'notComputable': 'Trend not computable',
      'rateOutOfRange': 'Rate out of range',
    };

    return descriptions[trend] || 'Unknown trend';
  }

  /**
   * Calculate Time in Range (TIR) from glucose readings
   */
  calculateTimeInRange(readings: DexcomGlucoseReading[]): {
    veryLow: number;
    low: number; 
    target: number;
    high: number;
    veryHigh: number;
    totalReadings: number;
  } {
    const counts = {
      veryLow: 0,   // < 54 mg/dL
      low: 0,       // 54-69 mg/dL
      target: 0,    // 70-180 mg/dL
      high: 0,      // 181-250 mg/dL
      veryHigh: 0,  // > 250 mg/dL
    };

    readings.forEach(reading => {
      const value = reading.value;
      if (value < 54) counts.veryLow++;
      else if (value <= 69) counts.low++;
      else if (value <= 180) counts.target++;
      else if (value <= 250) counts.high++;
      else counts.veryHigh++;
    });

    const total = readings.length;

    return {
      veryLow: total > 0 ? (counts.veryLow / total) * 100 : 0,
      low: total > 0 ? (counts.low / total) * 100 : 0,
      target: total > 0 ? (counts.target / total) * 100 : 0,
      high: total > 0 ? (counts.high / total) * 100 : 0,
      veryHigh: total > 0 ? (counts.veryHigh / total) * 100 : 0,
      totalReadings: total,
    };
  }

  /**
   * Get glucose pattern analysis
   */
  async getGlucosePatterns(days: number = 14): Promise<ApiResponse<{
    dailyAverages: Array<{ date: string; average: number; count: number }>;
    hourlyPatterns: Array<{ hour: number; average: number; count: number }>;
    timeInRange: ReturnType<DexcomApiClient['calculateTimeInRange']>;
  }>> {
    const endDate = new Date();
    const startDate = subDays(endDate, days);

    const response = await this.getGlucoseReadings({
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
    });

    if (!response.success) {
      return response as any;
    }

    const readings = response.data;
    
    // Calculate daily averages
    const dailyMap = new Map<string, { total: number; count: number }>();
    const hourlyMap = new Map<number, { total: number; count: number }>();

    readings.forEach(reading => {
      const date = new Date(reading.systemTime);
      const dayKey = format(date, 'yyyy-MM-dd');
      const hour = date.getHours();

      // Daily averages
      if (!dailyMap.has(dayKey)) {
        dailyMap.set(dayKey, { total: 0, count: 0 });
      }
      const daily = dailyMap.get(dayKey)!;
      daily.total += reading.value;
      daily.count += 1;

      // Hourly patterns
      if (!hourlyMap.has(hour)) {
        hourlyMap.set(hour, { total: 0, count: 0 });
      }
      const hourly = hourlyMap.get(hour)!;
      hourly.total += reading.value;
      hourly.count += 1;
    });

    const dailyAverages = Array.from(dailyMap.entries()).map(([date, data]) => ({
      date,
      average: Math.round(data.total / data.count),
      count: data.count,
    }));

    const hourlyPatterns = Array.from(hourlyMap.entries()).map(([hour, data]) => ({
      hour,
      average: Math.round(data.total / data.count),
      count: data.count,
    }));

    const timeInRange = this.calculateTimeInRange(readings);

    return {
      data: {
        dailyAverages,
        hourlyPatterns,
        timeInRange,
      },
      success: true,
    };
  }
}

// Export singleton instance
export const dexcomApi = new DexcomApiClient();
'''

with open("src/services/apis/dexcom/client.ts", "w") as f:
    f.write(dexcom_api)

print("✅ Created Dexcom API Client (src/services/apis/dexcom/client.ts)")
print("Features:")
print("- Complete Dexcom CGM API integration")
print("- Glucose readings with trend analysis") 
print("- Diabetes events (carbs, insulin, exercise)")
print("- Statistics and Time in Range calculations")
print("- Alert detection for high/low glucose")
print("- Pattern analysis (daily/hourly averages)")
print("- Conversion to generic health data format")
print("- Real-time current glucose monitoring")