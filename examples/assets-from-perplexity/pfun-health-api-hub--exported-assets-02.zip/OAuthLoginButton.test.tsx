/**
 * OAuth Login Button Component Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { OAuthLoginButton, OAuthPanel } from '@/components/auth/OAuthLoginButton';
import { HealthProvider } from '@/types/health-apis';

// Mock the OAuth manager
vi.mock('@/services/auth/oauth-manager', () => ({
  oauthManager: {
    isAuthenticated: vi.fn(),
    authenticate: vi.fn(),
    revokeTokens: vi.fn(),
  },
}));

describe('OAuthLoginButton', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders login button for unauthenticated user', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connect Dexcom CGM')).toBeInTheDocument();
    });
  });

  it('renders connected state for authenticated user', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(true);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connected to Dexcom CGM')).toBeInTheDocument();
    });
  });

  it('calls authenticate when login button is clicked', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockResolvedValue({ access_token: 'test-token' });
    const mockOnAuthSuccess = vi.fn();

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={mockOnAuthSuccess}
        onAuthError={vi.fn()}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    await waitFor(() => {
      expect(mockAuthenticate).toHaveBeenCalledWith(HealthProvider.DEXCOM);
      expect(mockOnAuthSuccess).toHaveBeenCalledWith(HealthProvider.DEXCOM);
    });
  });

  it('calls onAuthError when authentication fails', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockRejectedValue(new Error('Auth failed'));
    const mockOnAuthError = vi.fn();

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={mockOnAuthError}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    await waitFor(() => {
      expect(mockOnAuthError).toHaveBeenCalledWith(
        HealthProvider.DEXCOM,
        expect.any(Error)
      );
    });
  });

  it('shows loading state during authentication', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const mockAuthenticate = vi.fn().mockImplementation(() => new Promise(resolve => setTimeout(resolve, 100)));

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;
    oauthManager.authenticate = mockAuthenticate;

    render(
      <OAuthLoginButton 
        provider={HealthProvider.DEXCOM}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    const button = await screen.findByText('Connect Dexcom CGM');
    fireEvent.click(button);

    expect(screen.getByText('Connecting...')).toBeInTheDocument();
  });
});

describe('OAuthPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders buttons for configured providers', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(false);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connect Dexcom CGM')).toBeInTheDocument();
      expect(screen.getByText('Connect Fitbit')).toBeInTheDocument();
    });
  });

  it('shows connection progress', async () => {
    const mockIsAuthenticated = vi.fn()
      .mockResolvedValueOnce(true)  // Dexcom connected
      .mockResolvedValueOnce(false); // Fitbit not connected

    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Connected to 1 of 2 health services')).toBeInTheDocument();
    });
  });

  it('shows success message when all providers connected', async () => {
    const mockIsAuthenticated = vi.fn().mockResolvedValue(true);
    const { oauthManager } = await import('@/services/auth/oauth-manager');
    oauthManager.isAuthenticated = mockIsAuthenticated;

    render(
      <OAuthPanel
        providers={[HealthProvider.DEXCOM, HealthProvider.FITBIT]}
        onAuthSuccess={vi.fn()}
        onAuthError={vi.fn()}
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Ready to sync health data!')).toBeInTheDocument();
    });
  });
});
