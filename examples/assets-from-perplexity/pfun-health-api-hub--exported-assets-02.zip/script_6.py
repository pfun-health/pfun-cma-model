# Create health API types
health_api_types = '''/**
 * Common health API types and interfaces
 */

export interface OAuthConfig {
  clientId: string;
  clientSecret?: string; // Not used in frontend for security
  redirectUri: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export interface OAuthTokens {
  accessToken: string;
  refreshToken?: string;
  expiresIn: number;
  tokenType: string;
  scope?: string;
}

export interface OAuthState {
  state: string;
  provider: HealthProvider;
  timestamp: number;
}

export enum HealthProvider {
  DEXCOM = 'dexcom',
  FITBIT = 'fitbit',
  APPLE_HEALTH = 'apple-health',
  GOOGLE_HEALTH = 'google-health'
}

export interface HealthApiConfig {
  provider: HealthProvider;
  name: string;
  description: string;
  oauth: OAuthConfig;
  apiBaseUrl: string;
  isAvailable: boolean;
}

// Dexcom CGM Types
export interface DexcomGlucoseReading {
  systemTime: string;
  displayTime: string;
  value: number;
  status: 'high' | 'low' | 'ok' | null;
  trend: 'doubleUp' | 'singleUp' | 'fortyFiveUp' | 'flat' | 'fortyFiveDown' | 'singleDown' | 'doubleDown' | 'none' | 'notComputable' | 'rateOutOfRange';
  trendRate?: number;
}

export interface DexcomDataRange {
  startDate: string;
  endDate: string;
}

// Fitbit Types
export interface FitbitProfile {
  user: {
    encodedId: string;
    displayName: string;
    avatar: string;
    timezone: string;
  };
}

export interface FitbitActivitySummary {
  date: string;
  steps: number;
  distance: number;
  caloriesOut: number;
  activeMinutes: number;
  sedentaryMinutes: number;
}

export interface FitbitHeartRateZone {
  name: string;
  min: number;
  max: number;
  minutes: number;
  caloriesOut: number;
}

export interface FitbitSleepSummary {
  date: string;
  totalTimeInBed: number;
  totalMinutesAsleep: number;
  efficiency: number;
  stages?: {
    deep: number;
    light: number;
    rem: number;
    wake: number;
  };
}

// Apple Health Types (via third-party APIs like OneTwentyOne)
export interface AppleHealthQuantity {
  type: string;
  value: number;
  unit: string;
  startDate: string;
  endDate: string;
  sourceBundle?: string;
}

export interface AppleHealthWorkout {
  type: string;
  startDate: string;
  endDate: string;
  duration: number;
  totalEnergyBurned?: number;
  totalDistance?: number;
  sourceName: string;
}

// Google Health Types
export interface GoogleHealthDataPoint {
  dataTypeName: string;
  startTimeNanos: string;
  endTimeNanos: string;
  value: Array<{
    intVal?: number;
    fpVal?: number;
    stringVal?: string;
    mapVal?: Array<{
      key: string;
      value: {
        intVal?: number;
        fpVal?: number;
        stringVal?: string;
      };
    }>;
  }>;
  originDataSourceId?: string;
}

// Generic Health Data Types
export interface HealthDataPoint {
  timestamp: string;
  value: number | string;
  unit?: string;
  type: string;
  provider: HealthProvider;
  metadata?: Record<string, any>;
}

export interface HealthDataSeries {
  provider: HealthProvider;
  dataType: string;
  startDate: string;
  endDate: string;
  points: HealthDataPoint[];
  unit?: string;
}

// API Response Types
export interface ApiResponse<T = any> {
  data: T;
  success: boolean;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

// Error Types
export interface HealthApiError {
  code: string;
  message: string;
  provider: HealthProvider;
  timestamp: string;
  details?: Record<string, any>;
}

export enum ApiErrorCode {
  UNAUTHORIZED = 'UNAUTHORIZED',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',
  RATE_LIMITED = 'RATE_LIMITED',
  INVALID_REQUEST = 'INVALID_REQUEST',
  SERVER_ERROR = 'SERVER_ERROR',
  NETWORK_ERROR = 'NETWORK_ERROR',
  UNSUPPORTED_PROVIDER = 'UNSUPPORTED_PROVIDER'
}

// Dashboard Types
export interface HealthDashboardConfig {
  selectedProviders: HealthProvider[];
  dateRange: {
    start: string;
    end: string;
  };
  refreshInterval?: number;
  showRealTime: boolean;
  chartTypes: string[];
}

export interface DashboardWidget {
  id: string;
  type: 'chart' | 'metric' | 'table' | 'alert';
  provider: HealthProvider;
  dataType: string;
  config: Record<string, any>;
  position: { x: number; y: number; width: number; height: number };
}
'''

with open("src/types/health-apis.ts", "w") as f:
    f.write(health_api_types)

print("✅ Created health API types (src/types/health-apis.ts)")