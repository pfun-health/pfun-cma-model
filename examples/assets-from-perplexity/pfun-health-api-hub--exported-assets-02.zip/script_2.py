# Create TypeScript configuration
tsconfig = {
    "compilerOptions": {
        "target": "ES2020",
        "lib": ["ES2020", "DOM", "DOM.Iterable"],
        "module": "ESNext",
        "skipLibCheck": True,
        "moduleResolution": "bundler",
        "allowImportingTsExtensions": True,
        "resolveJsonModule": True,
        "isolatedModules": True,
        "noEmit": True,
        "jsx": "react-jsx",
        "strict": True,
        "noUnusedLocals": True,
        "noUnusedParameters": True,
        "noFallthroughCasesInSwitch": True,
        "baseUrl": ".",
        "paths": {
            "@/*": ["src/*"],
            "@/components/*": ["src/components/*"],
            "@/services/*": ["src/services/*"],
            "@/hooks/*": ["src/hooks/*"],
            "@/types/*": ["src/types/*"],
            "@/utils/*": ["src/utils/*"],
            "@/config/*": ["src/config/*"],
            "@/stores/*": ["src/stores/*"]
        },
        "types": ["chrome", "vite/client", "vitest/globals", "@testing-library/jest-dom"]
    },
    "include": ["src/**/*", "tests/**/*", "extension/**/*"],
    "exclude": ["node_modules", "dist", "build"],
    "references": [{"path": "./tsconfig.node.json"}]
}

with open("tsconfig.json", "w") as f:
    json.dump(tsconfig, f, indent=2)

# Create Node.js TypeScript config
tsconfig_node = {
    "compilerOptions": {
        "composite": True,
        "skipLibCheck": True,
        "module": "ESNext",
        "moduleResolution": "bundler",
        "allowSyntheticDefaultImports": True
    },
    "include": ["vite.config.ts"]
}

with open("tsconfig.node.json", "w") as f:
    json.dump(tsconfig_node, f, indent=2)

print("✅ Created TypeScript configurations")
print("Features configured:")
print("- Path aliases (@/* for src/*)")
print("- Chrome extension types")
print("- Vitest globals")
print("- Strict TypeScript settings")
print("- React JSX transform")