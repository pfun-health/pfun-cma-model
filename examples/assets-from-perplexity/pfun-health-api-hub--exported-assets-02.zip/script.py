# Create the project structure and main files for the health APIs frontend boilerplate
import os
import json

# Define the project structure
project_structure = {
    "src": [
        "components",
        "hooks", 
        "services",
        "types",
        "utils",
        "config",
        "stores",
        "pages"
    ],
    "src/components": [
        "auth",
        "health-data", 
        "ui",
        "charts"
    ],
    "src/services": [
        "apis",
        "auth"
    ],
    "src/services/apis": [
        "dexcom",
        "fitbit", 
        "apple-health",
        "google-health"
    ],
    "tests": [
        "components",
        "services",
        "utils"
    ],
    "extension": []
}

# Create directory structure
def create_directories(base_path, structure, current_path=""):
    for folder, subfolders in structure.items():
        folder_path = os.path.join(current_path, folder)
        print(f"Creating directory: {folder_path}")
        if isinstance(subfolders, list):
            for subfolder in subfolders:
                subfolder_path = os.path.join(folder_path, subfolder)
                print(f"  - {subfolder_path}")

# Print the structure
print("=== HEALTH API INTEGRATION FRONTEND PROJECT STRUCTURE ===")
print()
create_directories("./", project_structure)
print()
print("=== Key Files to be Created ===")

key_files = [
    "package.json",
    "tsconfig.json", 
    "vite.config.ts",
    "src/main.tsx",
    "src/App.tsx",
    "src/config/environment.ts",
    "src/types/health-apis.ts",
    "src/services/auth/oauth-manager.ts",
    "src/services/apis/base-api-client.ts",
    "src/components/auth/OAuthLoginButton.tsx",
    "src/components/health-data/HealthDataDashboard.tsx",
    "src/hooks/useHealthData.ts",
    "extension/manifest.json",
    "extension/background.js",
    "tests/setup.ts"
]

for file in key_files:
    print(f"  - {file}")