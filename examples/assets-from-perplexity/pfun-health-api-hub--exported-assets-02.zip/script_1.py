# Create package.json for the project
package_json = {
    "name": "health-api-frontend-boilerplate",
    "version": "1.0.0",
    "description": "TypeScript React frontend boilerplate for health API integrations (Dexcom, Fitbit, Apple/Google Health) - adaptable to Chromium extension",
    "type": "module",
    "scripts": {
        "dev": "vite",
        "build": "tsc && vite build",
        "build:extension": "tsc && vite build --mode extension",
        "preview": "vite preview",
        "test": "vitest",
        "test:ui": "vitest --ui",
        "test:coverage": "vitest --coverage",
        "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
        "lint:fix": "eslint . --ext ts,tsx --fix",
        "type-check": "tsc --noEmit"
    },
    "dependencies": {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "react-router-dom": "^6.15.0",
        "axios": "^1.5.0",
        "date-fns": "^2.30.0",
        "recharts": "^2.8.0",
        "zustand": "^4.4.1",
        "react-query": "^3.39.3",
        "js-cookie": "^3.0.5",
        "crypto-js": "^4.1.1",
        "uuid": "^9.0.0"
    },
    "devDependencies": {
        "@types/react": "^18.2.15",
        "@types/react-dom": "^18.2.7",
        "@types/js-cookie": "^3.0.3",
        "@types/crypto-js": "^4.1.1",
        "@types/uuid": "^9.0.2",
        "@types/chrome": "^0.0.245",
        "@typescript-eslint/eslint-plugin": "^6.0.0",
        "@typescript-eslint/parser": "^6.0.0",
        "@vitejs/plugin-react": "^4.0.3",
        "eslint": "^8.45.0",
        "eslint-plugin-react-hooks": "^4.6.0",
        "eslint-plugin-react-refresh": "^0.4.3",
        "typescript": "^5.0.2",
        "vite": "^4.4.5",
        "vitest": "^0.34.0",
        "@vitest/ui": "^0.34.0",
        "c8": "^8.0.1",
        "jsdom": "^22.1.0",
        "@testing-library/react": "^13.4.0",
        "@testing-library/jest-dom": "^5.17.0",
        "msw": "^1.2.3"
    },
    "engines": {
        "node": ">=18.0.0"
    }
}

with open("package.json", "w") as f:
    json.dump(package_json, f, indent=2)

print("✅ Created package.json")
print("Key dependencies included:")
print("- React 18 + TypeScript")
print("- Vite for fast building") 
print("- Vitest for testing")
print("- React Query for data fetching")
print("- Zustand for state management")
print("- Recharts for data visualization")
print("- Chrome types for extension development")
print("- MSW for API mocking in tests")