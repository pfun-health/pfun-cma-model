import plotly.graph_objects as go
import plotly.express as px
import json
import numpy as np

# Data from the provided JSON
data = {
    "components": {
        "frontend": [
            "Landing Page", "Authentication Component", "Dashboard Component",
            "Settings Component", "API Status Panel"
        ],
        "state_management": [
            "React Context", "Auth State", "API Connection State", "Health Data Cache"
        ],
        "api_clients": [
            "Base API Client", "Fitbit Client", "Google Fit Client", 
            "Dexcom Client", "Apple Health Bridge"
        ],
        "chrome_extension": [
            "Manifest V3", "Background Service Worker", "Content Scripts",
            "Popup Interface", "Options Page"
        ],
        "security": [
            "OAuth 2.0 Flow", "Token Storage", "CSP Policies",
            "CORS Configuration", "Privacy Compliance"
        ],
        "external_apis": [
            "Fitbit API", "Google Fit API", "Dexcom API", "Apple HealthKit"
        ]
    }
}

# Define colors for each category
colors = {
    "frontend": "#1FB8CD",      # Strong cyan
    "state_management": "#DB4545", # Bright red  
    "api_clients": "#2E8B57",   # Sea green
    "chrome_extension": "#5D878F", # Cyan
    "security": "#D2BA4C",      # Moderate yellow
    "external_apis": "#B4413C"  # Moderate red
}

# Create more compact positions for components in a layered architecture
fig = go.Figure()

# More compact positioning with clear layers
center_positions = {
    "frontend": (0, 2.5),
    "state_management": (-2, 1.5),
    "chrome_extension": (2, 1.5),
    "api_clients": (-2, 0.5), 
    "security": (2, 0.5),
    "external_apis": (0, -0.5)
}

all_components = []
all_x = []
all_y = []
all_colors = []
all_labels = []
all_categories = []

# Add background rectangles for each category with proper opacity
for category, (center_x, center_y) in center_positions.items():
    fig.add_shape(
        type="rect",
        x0=center_x-1.3, y0=center_y-0.7,
        x1=center_x+1.3, y1=center_y+0.7,
        fillcolor=colors[category],
        opacity=0.1,
        line=dict(color=colors[category], width=2),
        layer="below"
    )

# Add components for each category with tighter spacing
for category, components in data["components"].items():
    center_x, center_y = center_positions[category]
    n_components = len(components)
    
    # Arrange components in a compact grid
    if n_components <= 3:
        for i, component in enumerate(components):
            x = center_x + (i - (n_components-1)/2) * 0.8
            y = center_y
            
            # Abbreviate long component names to fit 15 char limit
            short_name = component
            if len(component) > 15:
                words = component.split()
                if len(words) > 1:
                    short_name = ' '.join([w[:4] for w in words[:2]])
                else:
                    short_name = component[:12] + "..."
            
            all_components.append(component)
            all_x.append(x)
            all_y.append(y)
            all_colors.append(colors[category])
            all_labels.append(short_name)
            all_categories.append(category.replace('_', ' ').title())
    else:
        # For more components, use a 2-row grid
        cols = min(3, n_components)
        rows = int(np.ceil(n_components / cols))
        
        for i, component in enumerate(components):
            col = i % cols
            row = i // cols
            x = center_x + (col - (cols-1)/2) * 0.8
            y = center_y + (row - (rows-1)/2) * 0.4
            
            # Abbreviate long component names
            short_name = component
            if len(component) > 15:
                words = component.split()
                if len(words) > 1:
                    short_name = ' '.join([w[:4] for w in words[:2]])
                else:
                    short_name = component[:12] + "..."
            
            all_components.append(component)
            all_x.append(x)
            all_y.append(y)
            all_colors.append(colors[category])
            all_labels.append(short_name)
            all_categories.append(category.replace('_', ' ').title())

# Add directional connection arrows between related components
connections = [
    # Frontend to State Management (bidirectional)
    ("Authentication Component", "Auth State"),
    ("Dashboard Component", "Health Data Cache"),
    ("API Status Panel", "API Connection State"),
    
    # State Management to API Clients  
    ("API Connection State", "Base API Client"),
    ("Auth State", "OAuth 2.0 Flow"),
    
    # API Clients to External APIs
    ("Fitbit Client", "Fitbit API"),
    ("Google Fit Client", "Google Fit API"),
    ("Dexcom Client", "Dexcom API"),
    ("Apple Health Bridge", "Apple HealthKit"),
    
    # Chrome Extension connections
    ("Background Service Worker", "Base API Client"),
    ("Popup Interface", "Dashboard Component"),
    ("Content Scripts", "Landing Page"),
    
    # Security connections
    ("OAuth 2.0 Flow", "Token Storage"),
    ("CSP Policies", "Content Scripts"),
    ("CORS Configuration", "Base API Client")
]

# Add connection lines with thicker, darker arrows
for start_comp, end_comp in connections:
    if start_comp in all_components and end_comp in all_components:
        start_idx = all_components.index(start_comp)
        end_idx = all_components.index(end_comp)
        
        # Add thicker line
        fig.add_trace(go.Scatter(
            x=[all_x[start_idx], all_x[end_idx]],
            y=[all_y[start_idx], all_y[end_idx]],
            mode='lines',
            line=dict(color='rgba(50,50,50,0.8)', width=3),
            showlegend=False,
            hoverinfo='skip'
        ))
        
        # Add arrowhead annotation
        fig.add_annotation(
            x=all_x[end_idx], y=all_y[end_idx],
            ax=all_x[start_idx], ay=all_y[start_idx],
            xref='x', yref='y',
            axref='x', ayref='y',
            arrowhead=2,
            arrowsize=1.5,
            arrowwidth=3,
            arrowcolor='rgba(50,50,50,0.9)',
            showarrow=True
        )

# Add component nodes with better contrast and readability
for category in colors.keys():
    cat_indices = [i for i, cat in enumerate(all_categories) if cat.lower().replace(' ', '_') == category]
    
    if cat_indices:
        fig.add_trace(go.Scatter(
            x=[all_x[i] for i in cat_indices],
            y=[all_y[i] for i in cat_indices],
            mode='markers+text',
            marker=dict(
                size=30,
                color=colors[category],
                line=dict(width=3, color='white')
            ),
            text=[all_labels[i] for i in cat_indices],
            textposition='middle center',
            textfont=dict(size=10, color='black', family='Arial Black'),
            name=category.replace('_', ' ').title(),
            hovertemplate='<b>%{text}</b><br>Category: ' + category.replace('_', ' ').title() + '<extra></extra>'
        ))

# Add category labels with better positioning
category_labels = [
    (0, 3.3, "Frontend Layer", "#1FB8CD"),
    (-2, 2.3, "State Mgmt", "#DB4545"),
    (2, 2.3, "Chrome Ext", "#5D878F"),
    (-2, 1.3, "API Clients", "#2E8B57"),
    (2, 1.3, "Security", "#D2BA4C"),
    (0, 0.3, "External APIs", "#B4413C")
]

annotations = []
for x, y, text, color in category_labels:
    annotations.append(dict(
        x=x, y=y,
        text=text,
        showarrow=False,
        font=dict(size=14, color=color, family="Arial Black"),
        bgcolor="rgba(255,255,255,0.8)",
        bordercolor=color,
        borderwidth=1
    ))

# Update layout with better spacing and styling
fig.update_layout(
    title="Health API Architecture",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='center', x=0.5),
    xaxis=dict(showgrid=False, showticklabels=False, zeroline=False, range=[-4, 4]),
    yaxis=dict(showgrid=False, showticklabels=False, zeroline=False, range=[-1.5, 4]),
    plot_bgcolor='rgba(250,250,250,1)',
    annotations=annotations
)

fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image("health_api_architecture.png")