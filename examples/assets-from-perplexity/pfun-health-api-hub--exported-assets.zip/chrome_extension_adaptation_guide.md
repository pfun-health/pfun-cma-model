
# Chrome Extension Adaptation Guide

## Overview
This guide explains how to adapt the Health API Integration Frontend into a Chrome Extension with Manifest V3 compatibility.

## Architecture Transformation

### 1. File Structure Conversion

```
health-api-extension/
├── manifest.json                 # Extension configuration
├── background.js                 # Service worker for API handling
├── popup/
│   ├── popup.html               # Main interface (400x600px)
│   ├── popup.js                 # Popup logic
│   └── popup.css                # Popup styling
├── content/
│   ├── content.js               # Content script for web page interaction
│   └── content.css              # Injected styles
├── options/
│   ├── options.html             # Settings page
│   ├── options.js               # Settings logic
│   └── options.css              # Settings styling
├── lib/
│   ├── api-clients.js           # Health API client libraries
│   ├── auth-manager.js          # OAuth flow management
│   └── storage-manager.js       # Chrome storage wrapper
└── assets/
    └── icons/                   # Extension icons (16, 48, 128px)
```

### 2. Manifest V3 Configuration

```json
{
  "manifest_version": 3,
  "name": "Health API Integration Hub",
  "version": "1.0.0",
  "description": "Integrate multiple health APIs with secure authentication",

  "permissions": [
    "storage",
    "identity",
    "activeTab"
  ],

  "host_permissions": [
    "https://api.fitbit.com/*",
    "https://www.googleapis.com/*",
    "https://api.dexcom.com/*",
    "https://sandbox-api.dexcom.com/*"
  ],

  "background": {
    "service_worker": "background.js"
  },

  "content_scripts": [{
    "matches": ["<all_urls>"],
    "js": ["content/content.js"],
    "css": ["content/content.css"],
    "run_at": "document_end"
  }],

  "action": {
    "default_popup": "popup/popup.html",
    "default_title": "Health API Hub",
    "default_icon": {
      "16": "assets/icons/icon-16.png",
      "32": "assets/icons/icon-32.png",
      "48": "assets/icons/icon-48.png",
      "128": "assets/icons/icon-128.png"
    }
  },

  "options_page": "options/options.html",

  "content_security_policy": {
    "extension_pages": "script-src 'self'; object-src 'self'"
  },

  "oauth2": {
    "client_id": "YOUR_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com",
    "scopes": ["https://www.googleapis.com/auth/fitness.activity.read"]
  }
}
```

### 3. Authentication Patterns

#### OAuth 2.0 with chrome.identity
```javascript
// background.js - OAuth flow management
class ExtensionAuthManager {
  constructor() {
    this.tokenCache = new Map();
  }

  async authenticateFitbit() {
    const authUrl = new URL('https://www.fitbit.com/oauth2/authorize');
    authUrl.searchParams.set('client_id', 'YOUR_FITBIT_CLIENT_ID');
    authUrl.searchParams.set('redirect_uri', chrome.identity.getRedirectURL());
    authUrl.searchParams.set('scope', 'activity heartrate sleep profile');
    authUrl.searchParams.set('response_type', 'code');

    try {
      const redirectUrl = await chrome.identity.launchWebAuthFlow({
        url: authUrl.href,
        interactive: true
      });

      const urlParams = new URL(redirectUrl).searchParams;
      const authCode = urlParams.get('code');

      if (authCode) {
        const tokenData = await this.exchangeCodeForToken('fitbit', authCode);
        await this.storeTokens('fitbit', tokenData);
        return tokenData;
      }
    } catch (error) {
      console.error('Fitbit OAuth error:', error);
      throw error;
    }
  }

  async exchangeCodeForToken(provider, authCode) {
    const tokenEndpoints = {
      fitbit: 'https://api.fitbit.com/oauth2/token',
      dexcom: 'https://api.dexcom.com/v2/oauth2/token'
    };

    const response = await fetch(tokenEndpoints[provider], {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${btoa(`${CLIENT_ID}:${CLIENT_SECRET}`)}`
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: authCode,
        redirect_uri: chrome.identity.getRedirectURL()
      })
    });

    return await response.json();
  }

  async storeTokens(provider, tokenData) {
    await chrome.storage.local.set({
      [`${provider}_tokens`]: {
        access_token: tokenData.access_token,
        refresh_token: tokenData.refresh_token,
        expires_at: Date.now() + (tokenData.expires_in * 1000),
        provider: provider
      }
    });
  }

  async getValidToken(provider) {
    const stored = await chrome.storage.local.get(`${provider}_tokens`);
    const tokens = stored[`${provider}_tokens`];

    if (!tokens) {
      throw new Error(`No tokens found for ${provider}`);
    }

    // Check if token is expired and refresh if needed
    if (tokens.expires_at < Date.now() + 300000) { // 5 min buffer
      return await this.refreshToken(provider, tokens.refresh_token);
    }

    return tokens.access_token;
  }
}
```

#### Content Security Policy Compliant Code
```javascript
// popup.js - CSP compliant implementation
class PopupManager {
  constructor() {
    this.authManager = new ExtensionAuthManager();
    this.init();
  }

  init() {
    // Use addEventListener instead of inline handlers
    document.addEventListener('DOMContentLoaded', () => {
      this.setupEventListeners();
      this.loadConnectionStatus();
    });
  }

  setupEventListeners() {
    // No inline event handlers - all via addEventListener
    const connectButtons = document.querySelectorAll('.connect-btn');
    connectButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const provider = e.target.dataset.provider;
        this.initiateConnection(provider);
      });
    });

    const refreshButtons = document.querySelectorAll('.refresh-btn');
    refreshButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const provider = e.target.dataset.provider;
        this.refreshData(provider);
      });
    });
  }

  async initiateConnection(provider) {
    try {
      // Send message to background script for OAuth
      const response = await chrome.runtime.sendMessage({
        action: 'authenticate',
        provider: provider
      });

      if (response.success) {
        this.updateConnectionStatus(provider, true);
        await this.loadHealthData(provider);
      }
    } catch (error) {
      this.showError(`Failed to connect to ${provider}: ${error.message}`);
    }
  }
}
```

### 4. API Client Architecture

```javascript
// lib/api-clients.js - Health API client implementations
class BaseHealthAPIClient {
  constructor(provider) {
    this.provider = provider;
    this.baseURL = this.getBaseURL();
  }

  getBaseURL() {
    const urls = {
      fitbit: 'https://api.fitbit.com',
      dexcom: 'https://api.dexcom.com',
      googlefit: 'https://www.googleapis.com'
    };
    return urls[this.provider];
  }

  async makeRequest(endpoint, options = {}) {
    // Get valid token from background script
    const tokenResponse = await chrome.runtime.sendMessage({
      action: 'getToken',
      provider: this.provider
    });

    if (!tokenResponse.success) {
      throw new Error(`Authentication required for ${this.provider}`);
    }

    const response = await fetch(`${this.baseURL}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${tokenResponse.token}`,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        // Token expired, try refresh
        await chrome.runtime.sendMessage({
          action: 'refreshToken',
          provider: this.provider
        });
        // Retry request
        return this.makeRequest(endpoint, options);
      }
      throw new Error(`API request failed: ${response.statusText}`);
    }

    return await response.json();
  }
}

class FitbitAPIClient extends BaseHealthAPIClient {
  constructor() {
    super('fitbit');
  }

  async getProfile() {
    return await this.makeRequest('/1/user/-/profile.json');
  }

  async getActivities(date = 'today') {
    return await this.makeRequest(`/1/user/-/activities/date/${date}.json`);
  }

  async getHeartRate(date = 'today') {
    return await this.makeRequest(`/1/user/-/activities/heart/date/${date}/1d.json`);
  }

  async getSleep(date = 'today') {
    return await this.makeRequest(`/1.2/user/-/sleep/date/${date}.json`);
  }
}

class DexcomAPIClient extends BaseHealthAPIClient {
  constructor() {
    super('dexcom');
  }

  async getDevices() {
    return await this.makeRequest('/v3/users/self/devices');
  }

  async getGlucoseReadings(startDate, endDate) {
    const params = new URLSearchParams({
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString()
    });
    return await this.makeRequest(`/v3/users/self/egvs?${params}`);
  }

  async getEvents(startDate, endDate) {
    const params = new URLSearchParams({
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString()
    });
    return await this.makeRequest(`/v3/users/self/events?${params}`);
  }
}
```

### 5. Storage Management

```javascript
// lib/storage-manager.js - Chrome storage wrapper
class StorageManager {
  constructor() {
    this.storage = chrome.storage.local;
  }

  async setHealthData(provider, dataType, data) {
    const key = `health_data_${provider}_${dataType}`;
    await this.storage.set({
      [key]: {
        data: data,
        timestamp: Date.now(),
        provider: provider,
        dataType: dataType
      }
    });
  }

  async getHealthData(provider, dataType) {
    const key = `health_data_${provider}_${dataType}`;
    const result = await this.storage.get(key);
    return result[key] || null;
  }

  async setConnectionStatus(provider, status) {
    const connections = await this.getConnections();
    connections[provider] = {
      connected: status.connected,
      lastSync: status.lastSync || Date.now(),
      error: status.error || null
    };

    await this.storage.set({ health_connections: connections });
  }

  async getConnections() {
    const result = await this.storage.get('health_connections');
    return result.health_connections || {};
  }

  async clearProviderData(provider) {
    const allData = await this.storage.get(null);
    const keysToRemove = Object.keys(allData).filter(key => 
      key.startsWith(`health_data_${provider}_`) || 
      key === `${provider}_tokens`
    );

    await this.storage.remove(keysToRemove);
  }
}
```

### 6. Background Service Worker

```javascript
// background.js - Service worker implementation
class HealthAPIBackgroundService {
  constructor() {
    this.authManager = new ExtensionAuthManager();
    this.storageManager = new StorageManager();
    this.syncInterval = null;

    this.setupMessageHandlers();
    this.setupAlarms();
  }

  setupMessageHandlers() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender).then(sendResponse);
      return true; // Keep message channel open for async response
    });
  }

  async handleMessage(request, sender) {
    try {
      switch (request.action) {
        case 'authenticate':
          return await this.handleAuthentication(request.provider);

        case 'getToken':
          const token = await this.authManager.getValidToken(request.provider);
          return { success: true, token };

        case 'refreshToken':
          await this.authManager.refreshToken(request.provider);
          return { success: true };

        case 'syncData':
          return await this.syncHealthData(request.provider);

        case 'getHealthData':
          const data = await this.storageManager.getHealthData(
            request.provider, 
            request.dataType
          );
          return { success: true, data };

        default:
          return { success: false, error: 'Unknown action' };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  setupAlarms() {
    // Sync health data every 30 minutes
    chrome.alarms.create('syncHealthData', { periodInMinutes: 30 });

    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'syncHealthData') {
        this.syncAllConnectedProviders();
      }
    });
  }

  async syncAllConnectedProviders() {
    const connections = await this.storageManager.getConnections();

    for (const [provider, status] of Object.entries(connections)) {
      if (status.connected) {
        try {
          await this.syncHealthData(provider);
        } catch (error) {
          console.error(`Failed to sync ${provider}:`, error);
        }
      }
    }
  }
}

// Initialize background service
new HealthAPIBackgroundService();
```

### 7. Content Script Integration

```javascript
// content/content.js - Web page interaction
class HealthDataContentScript {
  constructor() {
    this.init();
  }

  init() {
    this.detectHealthSites();
    this.setupPageDataCapture();
  }

  detectHealthSites() {
    const hostname = window.location.hostname;

    const healthSites = {
      'www.fitbit.com': this.enhanceFitbitSite,
      'myfitnesspal.com': this.enhanceMyFitnessPal,
      'connect.garmin.com': this.enhanceGarmin
    };

    if (healthSites[hostname]) {
      healthSites[hostname].call(this);
    }
  }

  enhanceFitbitSite() {
    // Add extension integration button to Fitbit dashboard
    const dashboard = document.querySelector('.dashboard');
    if (dashboard) {
      const integrationButton = this.createIntegrationButton('fitbit');
      dashboard.appendChild(integrationButton);
    }
  }

  createIntegrationButton(provider) {
    const button = document.createElement('button');
    button.textContent = `Sync with Health API Hub`;
    button.className = 'health-hub-integration-btn';
    button.addEventListener('click', () => {
      this.triggerDataSync(provider);
    });
    return button;
  }

  async triggerDataSync(provider) {
    const response = await chrome.runtime.sendMessage({
      action: 'syncData',
      provider: provider,
      source: 'content_script'
    });

    if (response.success) {
      this.showSuccessNotification(`${provider} data synced successfully`);
    } else {
      this.showErrorNotification(`Failed to sync ${provider} data`);
    }
  }
}

// Initialize content script
new HealthDataContentScript();
```

### 8. Data Visualization in Extension Context

```javascript
// popup/chart-manager.js - Lightweight charts for popup
class ExtensionChartManager {
  constructor() {
    this.charts = new Map();
  }

  createMiniChart(canvasId, data, type = 'line') {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');

    // Simple chart implementation for small popup space
    const chart = new Chart(ctx, {
      type: type,
      data: data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            display: false
          },
          y: {
            display: false
          }
        }
      }
    });

    this.charts.set(canvasId, chart);
    return chart;
  }

  updateChart(canvasId, newData) {
    const chart = this.charts.get(canvasId);
    if (chart) {
      chart.data = newData;
      chart.update('none'); // No animation for better performance
    }
  }

  destroyChart(canvasId) {
    const chart = this.charts.get(canvasId);
    if (chart) {
      chart.destroy();
      this.charts.delete(canvasId);
    }
  }
}
```

## Key Adaptation Considerations

### Security
- All API calls must go through background script
- Use chrome.storage.local for secure token storage
- Implement CSP-compliant code (no eval, inline scripts)
- Validate all external data before processing

### Performance
- Minimize popup loading time (< 1 second)
- Use efficient chart libraries (Chart.js with minimal config)
- Implement data caching to reduce API calls
- Use chrome.alarms for background sync scheduling

### User Experience
- Design for 400x600px popup constraint
- Provide clear connection status indicators
- Handle offline scenarios gracefully
- Implement proper error messaging

### Privacy Compliance
- Request minimal necessary permissions
- Implement data retention policies
- Provide clear privacy controls in settings
- Allow users to disconnect and delete data easily

## Development Workflow

1. **Setup Development Environment**
   ```bash
   git clone <repository>
   cd health-api-extension
   npm install
   npm run build:extension
   ```

2. **Load Extension in Chrome**
   - Open chrome://extensions/
   - Enable Developer Mode
   - Click "Load unpacked"
   - Select the dist/ folder

3. **Testing OAuth Flows**
   - Use sandbox environments for all health APIs
   - Test token refresh scenarios
   - Verify CSP compliance
   - Test offline behavior

4. **Publishing Preparation**
   - Complete Chrome Web Store Developer Program requirements
   - Prepare privacy policy and OAuth verification
   - Create store listing assets
   - Submit for review

This comprehensive guide provides the foundation for adapting the web application into a fully functional Chrome extension while maintaining security, performance, and user experience standards.
