# Create a comprehensive analysis of health API authentication patterns and requirements
health_api_analysis = """
# Health API Authentication & Integration Analysis

## API Overview and Authentication Patterns

### 1. Fitbit API
**Authentication Type**: OAuth 2.0
**Base URL**: https://api.fitbit.com
**Documentation**: https://dev.fitbit.com/build/reference/web-api/

**Key Features:**
- Personal and Client Credentials flows supported
- Intraday data access requires "Personal" application type
- Rate limits: 150 requests/hour for personal apps
- Data available: activities, heart rate, sleep, nutrition, weight

**OAuth Configuration:**
```javascript
const fitbitConfig = {
  authorizationURL: 'https://www.fitbit.com/oauth2/authorize',
  tokenURL: 'https://api.fitbit.com/oauth2/token',
  scopes: [
    'activity',    // Steps, distance, calories, active minutes
    'heartrate',   // Heart rate data
    'location',    // GPS and location data
    'nutrition',   // Food logging and nutrition data  
    'profile',     // User profile information
    'settings',    // User preferences and settings
    'sleep',       // Sleep stages and duration
    'social',      // Friends and social features
    'weight'       // Weight and body measurements
  ],
  redirectURI: 'https://your-app.com/callback'
};
```

**Data Endpoints:**
- Activities: `/1/user/-/activities/date/{date}.json`
- Heart Rate: `/1/user/-/activities/heart/date/{date}/1d.json`
- Sleep: `/1.2/user/-/sleep/date/{date}.json`
- Profile: `/1/user/-/profile.json`

### 2. Google Fit API
**Authentication Type**: OAuth 2.0
**Base URL**: https://www.googleapis.com/fitness/v1
**Documentation**: https://developers.google.com/fit/rest

**Key Features:**
- Requires Google Cloud Console project setup
- Supports web, Android, and iOS applications
- Data aggregation and real-time sync capabilities
- Extensive data types and sources

**Important Note**: Google Fit APIs will be deprecated in 2026. New applications cannot sign up as of May 2024.

**OAuth Configuration:**
```javascript
const googleFitConfig = {
  authorizationURL: 'https://accounts.google.com/o/oauth2/auth',
  tokenURL: 'https://oauth2.googleapis.com/token',
  scopes: [
    'https://www.googleapis.com/auth/fitness.activity.read',
    'https://www.googleapis.com/auth/fitness.body.read',
    'https://www.googleapis.com/auth/fitness.heart.read',
    'https://www.googleapis.com/auth/fitness.location.read',
    'https://www.googleapis.com/auth/fitness.nutrition.read',
    'https://www.googleapis.com/auth/fitness.sleep.read'
  ],
  clientId: 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com'
};
```

**Data Sources:**
- Step count, calories burned, distance
- Heart rate and blood pressure
- Weight, height, body fat percentage
- Sleep duration and stages
- Workout sessions and activities

### 3. Dexcom API
**Authentication Type**: OAuth 2.0
**Base URL**: https://api.dexcom.com (Production), https://sandbox-api.dexcom.com (Sandbox)
**Documentation**: https://developer.dexcom.com/

**Key Features:**
- Continuous Glucose Monitoring (CGM) data
- Real-time glucose readings and trends
- Event logging (meals, exercise, medication)
- HIPAA compliant with user authorization

**OAuth Configuration:**
```javascript
const dexcomConfig = {
  authorizationURL: 'https://api.dexcom.com/v2/oauth2/login',
  tokenURL: 'https://api.dexcom.com/v2/oauth2/token',
  scopes: ['offline_access'],
  redirectURI: 'https://your-app.com/dexcom-callback',
  // Sandbox for development
  sandboxURL: 'https://sandbox-api.dexcom.com'
};
```

**Data Endpoints:**
- Devices: `/v3/users/self/devices`
- Glucose Values: `/v3/users/self/egvs`
- Events: `/v3/users/self/events`
- Calibrations: `/v3/users/self/calibrations`

### 4. Apple HealthKit
**Authentication Type**: iOS SDK Integration (No web API)
**Platform**: iOS only
**Documentation**: https://developer.apple.com/documentation/healthkit

**Key Limitations:**
- No direct web API available
- Requires iOS app with HealthKit framework
- Data stays on device (privacy-focused approach)
- Cannot be accessed from web applications or Chrome extensions directly

**Integration Approaches:**
1. **iOS App Bridge**: Create iOS app that syncs with your backend
2. **Shortcuts Integration**: Use iOS Shortcuts to export data
3. **Third-party Services**: Use services like Terra API or Thryve
4. **Google Fit Bridge**: Install Google Fit on iPhone to sync HealthKit data

### 5. Third-Party Health Data Aggregators

#### Terra API
**Website**: https://tryterra.co/
**Features**: Unified API for multiple wearables and health platforms
- Supports Fitbit, Apple Health, Google Fit, Garmin, Oura, and more
- Real-time webhooks for data updates
- Normalized data format across all providers
- HIPAA compliant infrastructure

#### Thryve Health API
**Website**: https://www.thryve.health/
**Features**: Comprehensive health data integration
- 300+ wearable devices and health apps
- Real-time data streaming
- GDPR and HIPAA compliant
- Developer-friendly SDKs

## Chrome Extension Integration Patterns

### OAuth 2.0 Implementation Strategies

#### 1. chrome.identity.launchWebAuthFlow
```javascript
async function authenticateWithProvider(provider) {
  const config = getProviderConfig(provider);
  
  try {
    const redirectUrl = await chrome.identity.launchWebAuthFlow({
      url: buildAuthURL(config),
      interactive: true
    });
    
    const params = new URLSearchParams(redirectUrl.split('?')[1]);
    const authCode = params.get('code');
    
    if (authCode) {
      const tokens = await exchangeCodeForTokens(provider, authCode);
      await storeTokensSecurely(provider, tokens);
      return tokens;
    }
  } catch (error) {
    console.error(`${provider} authentication failed:`, error);
    throw error;
  }
}
```

#### 2. PKCE Implementation for Enhanced Security
```javascript
function generatePKCE() {
  const codeVerifier = generateRandomString(128);
  const codeChallenge = base64URLEncode(sha256(codeVerifier));
  
  return {
    codeVerifier,
    codeChallenge,
    codeChallengeMethod: 'S256'
  };
}

function buildAuthURL(config, pkce) {
  const params = new URLSearchParams({
    client_id: config.clientId,
    redirect_uri: chrome.identity.getRedirectURL(),
    scope: config.scopes.join(' '),
    response_type: 'code',
    code_challenge: pkce.codeChallenge,
    code_challenge_method: pkce.codeChallengeMethod,
    state: generateRandomString(32)
  });
  
  return `${config.authorizationURL}?${params}`;
}
```

### Token Management Best Practices

#### Secure Storage
```javascript
class TokenManager {
  async storeTokens(provider, tokens) {
    const encryptedTokens = await this.encryptTokens(tokens);
    
    await chrome.storage.local.set({
      [`${provider}_tokens`]: {
        access_token: encryptedTokens.access_token,
        refresh_token: encryptedTokens.refresh_token,
        expires_at: Date.now() + (tokens.expires_in * 1000),
        scope: tokens.scope,
        provider: provider
      }
    });
  }

  async getValidToken(provider) {
    const stored = await chrome.storage.local.get(`${provider}_tokens`);
    const tokens = stored[`${provider}_tokens`];
    
    if (!tokens) {
      throw new Error(`No tokens found for ${provider}`);
    }
    
    // Check expiration and refresh if needed
    if (tokens.expires_at < Date.now() + 300000) { // 5 min buffer
      return await this.refreshToken(provider, tokens.refresh_token);
    }
    
    return await this.decryptToken(tokens.access_token);
  }

  async refreshToken(provider, refreshToken) {
    const config = getProviderConfig(provider);
    
    const response = await fetch(config.tokenURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${btoa(`${config.clientId}:${config.clientSecret}`)}`
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken
      })
    });
    
    if (!response.ok) {
      throw new Error('Token refresh failed');
    }
    
    const newTokens = await response.json();
    await this.storeTokens(provider, newTokens);
    return newTokens.access_token;
  }
}
```

### Content Security Policy Considerations

#### CSP-Compliant Implementation
```javascript
// manifest.json CSP configuration
{
  "content_security_policy": {
    "extension_pages": "script-src 'self'; object-src 'self'; connect-src https://api.fitbit.com https://www.googleapis.com https://api.dexcom.com"
  }
}

// No inline scripts or eval() usage
// All event listeners via addEventListener
document.addEventListener('DOMContentLoaded', initializeExtension);

function initializeExtension() {
  const connectButton = document.getElementById('connect-fitbit');
  connectButton.addEventListener('click', handleFitbitConnection);
}
```

## Data Synchronization Patterns

### Background Sync with Service Worker
```javascript
// background.js
class HealthDataSyncManager {
  constructor() {
    this.syncInterval = 30 * 60 * 1000; // 30 minutes
    this.setupAlarms();
  }

  setupAlarms() {
    chrome.alarms.create('healthDataSync', {
      periodInMinutes: 30
    });
    
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'healthDataSync') {
        this.syncAllProviders();
      }
    });
  }

  async syncAllProviders() {
    const connections = await this.getConnectedProviders();
    
    for (const provider of connections) {
      try {
        await this.syncProviderData(provider);
      } catch (error) {
        console.error(`Sync failed for ${provider}:`, error);
        await this.handleSyncError(provider, error);
      }
    }
  }

  async syncProviderData(provider) {
    const client = this.getAPIClient(provider);
    const lastSync = await this.getLastSyncTime(provider);
    
    const newData = await client.getDataSince(lastSync);
    
    if (newData && newData.length > 0) {
      await this.storeHealthData(provider, newData);
      await this.updateLastSyncTime(provider);
      
      // Notify popup if open
      chrome.runtime.sendMessage({
        type: 'dataUpdated',
        provider: provider,
        dataCount: newData.length
      });
    }
  }
}
```

### Rate Limiting and Error Handling
```javascript
class RateLimitedAPIClient {
  constructor(provider, baseURL) {
    this.provider = provider;
    this.baseURL = baseURL;
    this.requestQueue = [];
    this.isProcessing = false;
    this.rateLimits = this.getRateLimits(provider);
  }

  getRateLimits(provider) {
    const limits = {
      fitbit: { requests: 150, window: 3600000 }, // 150/hour
      dexcom: { requests: 1000, window: 3600000 }, // 1000/hour
      googlefit: { requests: 100, window: 100000 } // 100/100s
    };
    return limits[provider] || { requests: 60, window: 3600000 };
  }

  async makeRequest(endpoint, options = {}) {
    return new Promise((resolve, reject) => {
      this.requestQueue.push({
        endpoint,
        options,
        resolve,
        reject,
        timestamp: Date.now()
      });
      
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.isProcessing || this.requestQueue.length === 0) {
      return;
    }
    
    this.isProcessing = true;
    
    while (this.requestQueue.length > 0) {
      const request = this.requestQueue.shift();
      
      try {
        await this.waitForRateLimit();
        const response = await this.executeRequest(request);
        request.resolve(response);
      } catch (error) {
        request.reject(error);
      }
    }
    
    this.isProcessing = false;
  }

  async executeRequest({ endpoint, options }) {
    const token = await this.getValidToken();
    
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      if (response.status === 429) {
        // Rate limited, implement exponential backoff
        await this.handleRateLimit(response);
        return this.executeRequest({ endpoint, options });
      } else if (response.status === 401) {
        // Token expired, refresh and retry
        await this.refreshToken();
        return this.executeRequest({ endpoint, options });
      } else {
        throw new Error(`API request failed: ${response.statusText}`);
      }
    }

    return await response.json();
  }
}
```

## Privacy and Compliance Considerations

### HIPAA Compliance
- Encrypt all stored health data
- Implement proper access controls
- Maintain audit logs of data access
- Provide user data deletion capabilities
- Use HIPAA-compliant cloud services

### GDPR Compliance
- Obtain explicit user consent
- Provide data portability options
- Implement right to erasure
- Maintain data processing records
- Conduct privacy impact assessments

### Security Best Practices
```javascript
class HealthDataSecurity {
  async encryptHealthData(data) {
    const key = await this.getOrGenerateEncryptionKey();
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv: crypto.getRandomValues(new Uint8Array(12)) },
      key,
      new TextEncoder().encode(JSON.stringify(data))
    );
    return encrypted;
  }

  async decryptHealthData(encryptedData) {
    const key = await this.getEncryptionKey();
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: encryptedData.iv },
      key,
      encryptedData.data
    );
    return JSON.parse(new TextDecoder().decode(decrypted));
  }

  async validateDataIntegrity(data, signature) {
    const key = await this.getSigningKey();
    const isValid = await crypto.subtle.verify(
      'HMAC',
      key,
      signature,
      new TextEncoder().encode(JSON.stringify(data))
    );
    return isValid;
  }
}
```

This comprehensive analysis provides the foundation for implementing secure, compliant health API integrations in Chrome extensions while following industry best practices for authentication, data management, and user privacy.
"""

# Save the analysis to a file
with open("health_api_authentication_analysis.md", "w") as f:
    f.write(health_api_analysis)

print("Health API Authentication Analysis created successfully!")
print("\nKey areas covered:")
print("- Fitbit API integration patterns")
print("- Google Fit API (with deprecation notice)")  
print("- Dexcom CGM API implementation")
print("- Apple HealthKit integration challenges")
print("- Third-party aggregator options")
print("- Chrome Extension OAuth patterns")
print("- Token management and security")
print("- Rate limiting and error handling")
print("- Privacy and compliance considerations")