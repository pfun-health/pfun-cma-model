#!/usr/bin/env python
"""app.engine.cma_sleepwake: define the Cortisol-Melatonin-Adiponectin model.
"""
import importlib
import copy
import json
import logging
import sys
from pathlib import Path
from typing import (
    Callable, Container, Dict, Iterable, Tuple
)
import numpy as np

#: pfun imports (relative)
root_path = str(Path(__file__).parents[1])
mod_path = str(Path(__file__).parent)
if root_path not in sys.path:
    sys.path.insert(0, root_path)
if mod_path not in sys.path:
    sys.path.insert(0, mod_path)
try:
    from chalicelib.decorators import check_is_numpy
    from chalicelib.engine.calc import normalize, normalize_glucose
    from chalicelib.engine.data_utils import dt_to_decimal_hours
    from chalicelib.engine.bounds import Bounds
    import pandas as pd
except ModuleNotFoundError:
    try:
        pd = importlib.import_module("pandas")
    except ModuleNotFoundError as err:
        err.msg += '\nContext: chalicelib/engine/cma_sleepwake.py'
        raise err
    check_is_numpy = importlib.import_module(
        ".decorators", package="chalicelib").check_is_numpy
    normalize = importlib.import_module(
        ".calc", package="chalicelib.engine").normalize
    normalize_glucose = importlib.import_module(
        ".calc", package="chalicelib.engine").normalize_glucose
    dt_to_decimal_hours = importlib.import_module(
        ".data_utils", package="chalicelib.engine").dt_to_decimal_hours
    Bounds = importlib.import_module(
        ".bounds", package="chalicelib.engine").Bounds

logger = logging.getLogger()


def l(x):
    return 2.0 / (1.0 + np.exp(2.0 * np.power(x, 2)))


def E(x):
    return 1.0 / (1.0 + np.exp(-2.0 * x))


def meal_distr(Cm, t, toff):
    """Meal distribution function.

    Parameters
    ----------
    Cm : float
        Cortisol temporal sensitivity coefficient (u/h).
    t : array_like
        Time (hours).
    toff : float
        Meal-relative time offset (hours).

    Returns
    -------
    array_like
        Meal distribution function.
    """
    return np.power(np.cos(2 * np.pi * Cm * (t + toff) / 24), 2)


@check_is_numpy
def K(x: np.ndarray):
    """
    Defines the glucose response function.
    Apply a piecewise function to the input array `x`.

    Parameters:
        x (numpy.ndarray): The input array.

    Returns:
        numpy.ndarray: The result of applying the piecewise function to `x`.
    """
    return np.piecewise(x, [x > 0.0, x <= 0.0], [
        lambda x_: np.exp(-np.power(np.log(2.0 * x_), 2)), 0.0])


def vectorized_G(t: np.ndarray | float, I_E: np.ndarray | float,
                 tm: np.ndarray | float, taug: np.ndarray | float,
                 B: float, Cm: float, toff: float):
    """Vectorized version of G(t, I_E, tm, taug, B, Cm, toff).

    Parameters
    ----------
    t : array_like | float
        Time vector (hours).
    I_E : float
        Extracellular insulin (u*mg/mL).
    tm : array_like
        Meal times (hours).
    taug : array_like
        Meal duration (hours).
    B : float
        Bias constant.
    Cm : float
        Cortisol temporal sensitivity coefficient (u/h).
    toff : float
        Meal-relative time offset (hours).

    Returns
    -------
    array_like
        G(t, I_E, tm, taug, B, Cm, toff).
    """
    tm = np.atleast_1d(tm)
    t = np.atleast_1d(t)
    taug = np.atleast_1d(taug)

    def Gtmp(tm_: float | np.ndarray, taug_: float | np.ndarray):
        k_G = K((t - np.atleast_1d(tm_)) / np.power(np.atleast_1d(taug_), 2))
        return 1.3 * k_G / (1.0 + I_E)

    m = len(tm)
    n = len(t)
    j = 0
    out = np.zeros((m, n), dtype=float)
    while j < m:
        gtmp = Gtmp(tm[j], taug[j])
        out[j, :] = gtmp
        j = j + 1
    out = out + B * (1.0 + meal_distr(Cm, t, toff))  # ! apply bias constant.
    return out


class CMAParamTypeError(TypeError):
    """CMA parameter type error."""

    def __init__(self, pkey, *args: object) -> None:
        super().__init__(*args)
        self._pkey = pkey

    def __repr__(self) -> str:
        return super().__repr__() + \
            f"...Parameter '{self._pkey}' must be numeric."


class CMASleepWakeModel:

    """Defines the Cortisol-Melatonin-Adiponectin Sleep-Wake pfun model.

    Methods:
    -------
    1) Input SG -> Project SG to 24-hour phase plane.
    2) Estimate photoperiod (t_m0 - 1, t_m2 + 3) -> Model params (d, taup).
    3) (Fit to projected SG) Compute approximate chronometabolic dynamics:
        F(m, c, a)(t, d, taup) -> ...
         ...  (+/- postprandial insulin, glucose){Late, Early}.
    """

    param_keys = ('d', 'taup', 'taug', 'B', 'Cm', 'toff')
    param_defaults = (0.0, 1.0, 1.0, 0.05, 0.0, 0.0)
    bounds = Bounds(
        lb=[-12.0, 0.5, 0.1, 0.0, 0.0, -3.0, ],
        ub=[14.0, 3.0, 3.0, 1.0, 2.0, 3.0, ],
        keep_feasible=Bounds.True_
    )

    def param_key_index(self, keys: str | Iterable[str]) -> int | Iterable[int]:
        """Return the index of the parameter key."""
        if isinstance(keys, str):
            return self.param_keys.index(keys)
        else:
            return [self.param_keys.index(k) for k in keys]

    def update_bounds(self, keys, lb, ub,
                      keep_feasible: np.bool_ | Iterable[np.bool_] = Bounds.True_,
                      return_bounds=False):
        """Update the bounds of the model."""
        keys = [keys] if isinstance(keys, str) else keys
        lb = [float(lb)] if isinstance(lb, (float, int)) else lb
        ub = [float(ub)] if isinstance(ub, (float, int)) else ub
        keep_feasible = [keep_feasible, ] if isinstance(keep_feasible, Bounds.bool_) \
            else keep_feasible
        for k in keys:
            ix = self.param_keys.index(k)
            self.bounds[ix] = (
                lb[ix], ub[ix], keep_feasible[ix])  # type: ignore
        if return_bounds:
            return self.bounds

    def __json__(self):
        """JSON serialization."""
        out = {k: v for k, v in self.__dict__.items()}
        for key, value in out.items():
            if isinstance(value, np.ndarray):
                out[key] = value.tolist()
            elif isinstance(value, pd.DataFrame):
                out[key] = pd.json_normalize(
                    value.to_dict()).to_dict()  # type: ignore
            elif isinstance(value, pd.Series):
                out[key] = value.tolist()
            elif isinstance(value, Bounds):
                out[key] = value.json()
            elif hasattr(value, '__json__'):
                out[key] = value.__json__()
            try:
                out[key] = json.dumps(out[key])
            except json.JSONDecodeError:
                logging.warning("Could not convert %s to JSON.", str(value))
                out.pop(key)  # ! remove any non-JSONable value
        return out

    def json(self):
        """JSON serialization."""
        return self.__json__()

    def __init__(self, **kwds):
        """PFun CMA model constructor.

        Arguments:
        ----------
            t (array or float, optional): Time vector (corresponds to ). If not provided, t will be a linearly spaced vector of length N.
            N (int, optional): Number of time points. Defaults to 288.
            d (float, optional): Offset from UTC solar noon for the estimated latitude (hours). Defaults to 0.0.
            taup (float, optional): Photoperiod length (hours). Defaults to 1.0.
            taug (float, optional): Meal duration (hours). Defaults to 1.0.
            B (float, optional): Bias constant. Defaults to 0.05.
            Cm (float, optional): Cortisol temporal sensitivity coefficient (u/h). Defaults to 0.0.
            toff (float, optional): Solar noon offset for the estimated latitude (hours). Defaults to 0.0.
            tM (tuple, optional): Meal times (hours). Defaults to (7.0, 11.0, 17.5).
            seed (None | int, optional): Random seed value. If provided, random noise will be included in the model solution, scaled by parameter eps. Defaults to None.
            eps (float, optional): Random noise scale ("epsilon"). Defaults to 1e-18.
        """
        defaults = dict(
            t=None,
            N=288, d=0.0, taup=1.0, taug=1.0, B=0.05,
            Cm=0.0, toff=0.0, tM=(7.0, 11.0, 17.5),
            seed=None, eps=1e-18
        )
        params = defaults.copy()
        params.update(kwds)
        t, N, tM, seed, eps = params.pop('t'), params.pop('N'), params.pop(
            'tM'), params.pop('seed'), params.pop('eps')
        assert (t is not None or N is not None) and (t is None or N is None), \
            "Must provide either the 't' or 'N' argument (not both)"
        if t is None:
            t = np.linspace(0, 24, num=int(N))
        self.t: Container[float] | np.ndarray = t  # time vector
        self.tM = np.asarray(tM, dtype=float)  # mealtimes vector
        self.params: Dict[str, float] = {k: v for k, v in params.items() if k
                                         in self.param_keys}
        for pkey in self.param_keys:
            pval = params.get(pkey)
            if pval is not None:
                self.params[pkey] = pval
        self.bounds = copy.copy(self.__class__.bounds)
        self.eps = eps
        self.rng = None
        if seed is not None:
            self.rng = np.random.default_rng(seed=seed)

    @property
    def N(self):
        """Number of time steps."""
        return len(self.t)

    def update(self, *args, inplace=True, **kwds):
        """
        Update the current instance with new values.

        Parameters:
            *args: Variable length argument list.
            inplace (bool): If True, update the current instance in place. If False, create a new instance with the updated values.
            **kwds: Keyword arguments to update the instance.

        Returns:
            The updated instance if `inplace` is False, otherwise None.

        Raises:
            ValueError: If a parameter is not found.
            TypeError: If a parameter is not numeric.

        Note:
            - If `inplace` is False, a new instance is created with the updated values and returned.
            - Parameters in `kwds` that are not present in the instance's `param_keys` are ignored.
            - The instance's `params` dictionary is updated with the values from `kwds`.
            - The order of the parameters in the `params` dictionary is preserved.
            - The instance's `params` dictionary is updated to keep values within the specified bounds.
            - The `tM` attribute is updated with the values from `kwds` if 'tM' is present.
            - The `t` attribute is updated with a linspace from 0 to 24 if 'N' is present.
            - The `rng` attribute is updated with a new random number generator if 'seed' is present.
            - The `eps` attribute is updated with the value from `kwds` if 'eps' is present.
        """
        if len(args) > 0:
            opts = args[0]
            opts.update(kwds)
            kwds = dict(opts)
        if inplace is False:
            new_inst = copy.copy(self)
            new_inst.update(inplace=True, **kwds)
            return new_inst
        #: ! handle case in which taug was given as a vector initially
        if 'taug' in kwds and isinstance(self.params['taug'], Container):
            taug_new = kwds.pop('taug')
            match isinstance(taug_new, Container):
                case True:
                    #: ! replace current values elementwise if given a vector
                    self.params['taug'] = np.broadcast_to(  # type: ignore
                        taug_new, (self.n_meals, ))
                case False:  # ! else, taug is a scale: <old_taug> *= new_taug
                    self.params['taug'] = np.array(  # type: ignore
                        self.params['taug'], dtype=float) * float(taug_new)
        #: update all given params
        self.params.update({k: kwds[k] for k in kwds if k in self.param_keys})
        self.params = {k: self.params[k]
                       for k in self.param_keys}  # ! ensure order
        #: keep within specified bounds (keep_feasible is handled by Bounds)
        self.params = self.bounds.update_values(self.params)  # type: ignore
        if 'tM' in kwds:
            self.tM = np.array(kwds['tM'], dtype=float).flatten()
        if 'N' in kwds:
            self.t = np.linspace(0, 24, num=kwds['N'])
        if 'seed' in kwds:
            self.rng = np.random.default_rng(seed=kwds['seed'])
        if 'eps' in kwds:
            self.eps = kwds['eps']
        #: check all parameters are present and valid types
        for pkey in self.param_keys:
            if pkey not in self.params:
                raise ValueError(f"Parameter '{pkey}' not found.")
            if not isinstance(self.params[pkey], (float, int)):
                raise TypeError(f"Parameter '{pkey}' must be numeric.")

    @property
    def d(self) -> float:
        """d : float
             Offset from UTC solar noon for the estimated latitude (hours).
        """
        return self.params["d"]

    @property
    def taup(self) -> float:
        """taup : float
                Approximate photoperiod (hours).
        """
        return self.params["taup"]

    @property
    def n_meals(self):
        """Number of meals."""
        return len(self.tM)

    @property
    def taug(self) -> np.ndarray:
        """taug: get an array broadcasted to: (, number_of_meals)."""
        taug_ = self.params["taug"]
        taug_vector = np.broadcast_to(taug_, (self.n_meals, ))
        return taug_vector

    @property
    def B(self) -> float:
        """Return the current bias parameter value (B)."""
        return self.params["B"]

    @property
    def Cm(self) -> float:
        """return the current Cm param value."""
        return self.params["Cm"]

    @property
    def toff(self) -> float:
        return self.params["toff"]

    def E_L(self, t=None):
        if t is None:
            t = self.t
        return l(0.025 * np.power((t - 12.0 - self.d), 2) /
                 (self.eps + self.taup))

    @property
    def L(self):
        return self.E_L(t=self.t)

    def M(self, t=None):
        """compute the estimated relative Melatonin signal."""
        if t is None:
            t = self.t
        m_out = np.power((1.0 - self.L), 3) * \
            np.power(np.cos(-(t - 3.0 - self.d) * np.pi / 24.0), 2)
        if self.rng is not None:
            # ! tiny amount of random noise
            m_out = m_out + \
                self.rng.uniform(low=-self.eps, high=self.eps, size=self.N)
        return m_out

    @property
    def m(self):
        return self.M(t=self.t)

    @property
    def c(self):
        return (4.9 / (1.0 + self.taup)) * np.pi * E(np.power((self.L - 0.88), 3)) * \
            E(0.05 * (8.0 - self.t + self.d)) * E(2.0 * np.power(-self.m, 3))

    @property
    def a(self):
        return (E(np.power((-self.c * self.m), 3)) +
                np.exp(-0.025 * np.power((self.t - 13 - self.d), 2)) *
                self.E_L(t=0.7*(27-self.t+self.d))) / 2.0

    @property
    def I_S(self):
        return 1.0 - 0.23 * self.c - 0.97 * self.m

    @property
    def I_E(self):
        return self.a * self.I_S

    def calc_Gt(self, t=None, dt=None, n=1, return_t=False):
        """
        Calculate the value of Gt at a given time or times.

        Parameters:
            t (float or array-like, optional): The time or times at which to
                calculate Gt. If not provided, the next time step(s) will be
                calculated based on the previous time step and the specified
                time step size.
            dt (float, optional): The time step size. If not provided, it will
                be calculated as the absolute difference between the last two
                time steps.
            n (int, optional): The number of time steps to calculate if `t` is
                not provided. Defaults to 1.
            return_t (bool, optional): Whether to return the calculated time
                step(s) along with the calculated Gt value(s). Defaults to
                False.

        Returns:
            Gt (float or array-like): The calculated Gt value(s) at the
                specified time(s).
            t (float or array-like, optional): The calculated time step(s) if
                `return_t` is True.
        """
        if t is None:
            if dt is None:
                dt = np.abs(self.t[-1] - self.t[-2])
            t = np.mod(np.linspace(
                self.t[-1] + dt, self.t[-1] + (n-1)*dt, num=n), 24)
        Gt = vectorized_G(t, self.I_E[-1], self.tM, self.taug,
                          self.B, self.Cm, self.toff)
        if return_t is False:
            return Gt
        else:
            return Gt, t

    def update_Gt(self, t=None, dt=None, n=1, keep_tvec_size=True):
        """
        Update the value of Gt and t.

        Parameters:
            t (float): The starting time for calculating Gt. If None, the current time will be used. Default is None.
            dt (float): The time step for calculating Gt. If None, the default time step will be used. Default is None.
            n (int): The number of time steps to calculate Gt. Default is 1.
            keep_tvec_size (bool): Whether to keep the size of the time vector equal to the original size. Default is True.

        Returns:
            tuple: A tuple containing the updated Gt and t arrays.
        """
        Gt, t = self.calc_Gt(t=t, dt=dt, n=n, return_t=True)
        self.t = np.append(self.t, t)
        if keep_tvec_size is True:
            self.t = self.t[n:]
        return Gt, self.t

    @property
    def G(self):
        return vectorized_G(self.t, self.I_E, self.tM, self.taug, self.B,
                            self.Cm, self.toff)

    @property
    def g(self):
        """g: get the per-meal post-prandial glucose dynamics.

        Examples:
        ---------
            >>> cma = CMASleepWakeModel(N=10, taug=[1.0, 2.0, 3.0])
            >>> cma.g
            array([[0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 5.73725968e-01,
                    1.57882217e-02, 1.27544618e-03, 2.05703931e-04, 5.09901523e-05,
                    1.50385708e-05, 4.96125002e-06],
                   [0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
                    0.00000000e+00, 7.85187035e-01, 3.77414036e-01, 1.70718635e-01,
                    7.87996469e-02, 3.75426497e-02],
                   [0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
                    0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 1.67894822e-01,
                    1.13923320e+00, 1.08996350e+00]])
        """
        return self.G

    def integrate_signal(self, signal: np.ndarray | None = None,
                         signal_name: str | None = None,
                         t0: int | float = 0, t1: int | float = 24,
                         M: int = 3,
                         t_extra: Tuple | None = None,
                         tvec: np.ndarray | None = None) -> float:
        """Integrate the signal between the hours given, assuming M discrete events.

            t_extra specifies any additional range of 'accepted hours' as an inclusive tuple [te0, te1],
            to be included in the target time period.
        """
        # trunk-ignore(bandit/B101)
        assert any([(signal is None), (signal_name is None)]
                   ), "Must provide exactly one of signal or signal_name"
        # trunk-ignore(bandit/B101)
        assert any([(signal is not None), (signal_name is not None)]
                   ), "Must provide exactly one of signal or signal_name"
        if tvec is None:
            tvec = self.t
        if signal_name is not None:
            signal = getattr(self, signal_name)
        if signal.shape[0] != tvec.size:
            signal = signal.T
        period = np.logical_and((tvec >= t0), (tvec <= t1))
        if t_extra is not None:
            period = np.logical_or(
                period, (tvec >= t_extra[0]) & (tvec <= t_extra[1]))
        total = np.nansum(signal[period]) / (M * (t1 - t0))
        return total

    def morning(self, signal: np.ndarray = None, signal_name=None):
        """compute the total morning integrated signal."""
        return self.integrate_signal(signal=signal, signal_name=signal_name, t0=4, t1=13)

    def evening(self, signal: np.ndarray = None, signal_name=None):
        """Compute the total evening integrated signal."""
        return self.integrate_signal(signal=signal, signal_name=signal_name,
                                     t0=16, t1=24, t_extra=(0, 3))

    @property
    def columns(self):
        return ["t", "c", "m", "a", "I_S", "I_E", "L", "G"]

    @property
    def g_morning(self):
        return self.morning(self.g)

    @property
    def g_evening(self):
        return self.evening(self.g)

    @property
    def g_instant(self):
        """vector of instantaneous (overall) glucose."""
        return np.nansum(self.g, axis=0)

    @property
    def df(self) -> pd.DataFrame:
        return self.run()

    @property
    def dt(self):
        #: TimedeltaIndex (in hours)
        return pd.to_timedelta(self.t, unit='H')

    @classmethod
    def get_model_args(cls):
        """for maintaining compatibility with the pfun.model_funcs API"""
        return dict(zip(cls.param_keys, cls.param_defaults))

    @property
    def pvec(self):
        """easy access to parameter vector (copy)"""
        return np.array([self.params[k] for k in self.param_keys])

    def run(self) -> pd.DataFrame:
        """run the model, return the solution as a labeled pd.DataFrame.

        Examples:
        ---------
            >>> cma = CMASleepWakeModel(N=4)
            >>> df = cma.run()
            >>> print(tabulate.tabulate(df, floatfmt='.3f', headers=df.columns))
                     t      c      m      a    I_S    I_E    g_0    g_1    g_2      G
            --  ------  -----  -----  -----  -----  -----  -----  -----  -----  -----
             0   0.000  0.083  0.854  0.251  0.153  0.038  0.000  0.000  0.000  0.000
             1   8.000  0.962  0.003  0.517  0.776  0.401  0.574  0.000  0.000  0.574
             2  16.000  0.597  0.000  0.565  0.863  0.488  0.000  0.004  0.000  0.005
             3  24.000  0.020  0.854  0.250  0.167  0.042  0.000  0.000  0.002  0.002
        """
        #: init list of "standard" columns
        columns = list(self.columns)
        # ! exclude instantaneous G until after computing components...
        columns.remove("G")
        #: get the corresponding values
        values = [getattr(self, k) for k in columns]
        #: compute "G" (separate components)
        g = self.g
        #: labels & values of the separate components of "G"
        gi_cols = [f"g_{j}" for j in range(g.shape[0])]
        columns = columns + gi_cols
        values = values + [g[i, :] for i in range(g.shape[0])]
        data = {k: v for k, v in zip(columns, values)}
        df = pd.DataFrame(data, columns=columns, index=self.dt)
        #: record instantaneous glucose
        df["G"] = self.g_instant
        #: record estimated meal times
        ismeal = [(df['t'] - tm).abs().idxmin() for tm in self.tM]
        df['is_meal'] = False
        df.loc[ismeal, 'is_meal'] = True
        return df


def round_to_nearest_integer(number):
    rounded_number = round(number, 2)
    return int(rounded_number)


class CMAUtils:

    @staticmethod
    def get_hour_of_day(
            hour: Tuple[float | int] | float | int) -> int | str | Tuple[str | int]:
        """
        Get the hour of the day based on the given hour value.

        Parameters:
            hour (float or int): The hour value to convert.

        Returns:

            int: The hour of the day as an integer.

            OR

            str: The hour of the day in the format '12AM', '12PM', '1AM', '1PM', etc.

            ...OR as a tuple.

        Raises:
            ValueError: If the hour is not a float or integer value, or if it is not between 0 and 24.
        """
        if isinstance(hour, tuple):
            # ! handle tuple
            return tuple(map(CMAUtils.get_hour_of_day, hour))
        if not isinstance(hour, (float, int)):
            raise ValueError("The hour must be a float or integer value.")
        if hour < 0 or hour > 24:
            raise ValueError("The hour must be between 0 and 24.")
        if hour == 0 or hour == 24:
            return '12AM'
        elif hour == 12:
            return '12PM'
        elif hour < 12:
            return f'{int(hour)}AM'
        else:
            return f'{int(hour) - 12}PM'

    @staticmethod
    def label_meals(df: pd.DataFrame,
                    rounded: [None | Callable] = round_to_nearest_integer,
                    as_str: bool = False) -> Tuple[str | int | float]:
        """Label the meal times in a CMA model results dataframe.
        Parameters:
            df (pd.DataFrame): The CMA model results dataframe.
            rounded (None or Callable): Function to round the meal times.
            as_str (bool): If True, return the meal times as strings.
        Returns:
            tuple: The meal times as strings or integers.
        Examples:
            >>> df = pd.DataFrame({'t': [0, 8, 16, 24], 'is_meal': [True, True, True, False]})
            >>> CMAUtils.label_meals(df)
            ('12AM', '8AM', '4PM')
            >>> CMAUtils.label_meals(df, as_str=True)
            ('12AM', '8AM', '4PM')
            >>> CMAUtils.label_meals(df, rounded=round_to_nearest_integer)
            (0, 8, 16)
        """
        #: get the meal times
        mealtimes = df.loc[df['is_meal'], 't']
        if rounded is not None:
            mealtimes = mealtimes.apply(rounded)
        tM = tuple(mealtimes)
        if as_str:
            tM = CMAUtils.get_hour_of_day(tM)
        if not isinstance(tM, tuple):
            if hasattr(tM, '__iter__'):
                tM = tuple(tM)  # type: ignore
            else:
                tM = (tM,)
        return tM
