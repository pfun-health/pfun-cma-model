from enum import Enum


class GetCalibrationsResponse200RecordsItemUnit(str, Enum):
    MGDL = "mg/dL"
    MMOLL = "mmol/L"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
