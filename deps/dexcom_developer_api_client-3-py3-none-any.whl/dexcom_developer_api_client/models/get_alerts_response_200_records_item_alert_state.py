from enum import Enum


class GetAlertsResponse200RecordsItemAlertState(str, Enum):
    ACTIVEALARMING = "activeAlarming"
    ACTIVESNOOZED = "activeSnoozed"
    INACTIVE = "inactive"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
