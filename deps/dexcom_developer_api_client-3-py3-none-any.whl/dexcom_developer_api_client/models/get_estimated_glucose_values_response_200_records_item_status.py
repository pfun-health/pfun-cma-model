from enum import Enum


class GetEstimatedGlucoseValuesResponse200RecordsItemStatus(str, Enum):
    HIGH = "high"
    LOW = "low"
    OK = "ok"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
