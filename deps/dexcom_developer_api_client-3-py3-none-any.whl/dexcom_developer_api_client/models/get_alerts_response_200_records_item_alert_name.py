from enum import Enum


class GetAlertsResponse200RecordsItemAlertName(str, Enum):
    FALL = "fall"
    FIXEDLOW = "fixedLow"
    HIGH = "high"
    LOW = "low"
    NOREADINGS = "noReadings"
    OUTOFRANGE = "outOfRange"
    RISE = "rise"
    UNKNOWN = "unknown"
    URGENTLOW = "urgentLow"
    URGENTLOWSOON = "urgentLowSoon"

    def __str__(self) -> str:
        return str(self.value)
