import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.get_alerts_response_200_records_item_alert_name import GetAlertsResponse200RecordsItemAlertName
from ..models.get_alerts_response_200_records_item_alert_state import GetAlertsResponse200RecordsItemAlertState
from ..models.get_alerts_response_200_records_item_transmitter_generation import (
    GetAlertsResponse200RecordsItemTransmitterGeneration,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="GetAlertsResponse200RecordsItem")


@_attrs_define
class GetAlertsResponse200RecordsItem:
    """
    Attributes:
        record_id (Union[Unset, str]):
        system_time (Union[Unset, datetime.datetime]):
        display_time (Union[Unset, datetime.datetime]):
        alert_name (Union[Unset, GetAlertsResponse200RecordsItemAlertName]):
        alert_state (Union[Unset, GetAlertsResponse200RecordsItemAlertState]):
        display_device (Union[Unset, str]):
        transmitter_generation (Union[Unset, GetAlertsResponse200RecordsItemTransmitterGeneration]):
        transmitter_id (Union[Unset, str]):
    """

    record_id: Union[Unset, str] = UNSET
    system_time: Union[Unset, datetime.datetime] = UNSET
    display_time: Union[Unset, datetime.datetime] = UNSET
    alert_name: Union[Unset, GetAlertsResponse200RecordsItemAlertName] = UNSET
    alert_state: Union[Unset, GetAlertsResponse200RecordsItemAlertState] = UNSET
    display_device: Union[Unset, str] = UNSET
    transmitter_generation: Union[Unset, GetAlertsResponse200RecordsItemTransmitterGeneration] = UNSET
    transmitter_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        record_id = self.record_id
        system_time: Union[Unset, str] = UNSET
        if not isinstance(self.system_time, Unset):
            system_time = self.system_time.isoformat()

        display_time: Union[Unset, str] = UNSET
        if not isinstance(self.display_time, Unset):
            display_time = self.display_time.isoformat()

        alert_name: Union[Unset, str] = UNSET
        if not isinstance(self.alert_name, Unset):
            alert_name = self.alert_name.value

        alert_state: Union[Unset, str] = UNSET
        if not isinstance(self.alert_state, Unset):
            alert_state = self.alert_state.value

        display_device = self.display_device
        transmitter_generation: Union[Unset, str] = UNSET
        if not isinstance(self.transmitter_generation, Unset):
            transmitter_generation = self.transmitter_generation.value

        transmitter_id = self.transmitter_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if record_id is not UNSET:
            field_dict["recordId"] = record_id
        if system_time is not UNSET:
            field_dict["systemTime"] = system_time
        if display_time is not UNSET:
            field_dict["displayTime"] = display_time
        if alert_name is not UNSET:
            field_dict["alertName"] = alert_name
        if alert_state is not UNSET:
            field_dict["alertState"] = alert_state
        if display_device is not UNSET:
            field_dict["displayDevice"] = display_device
        if transmitter_generation is not UNSET:
            field_dict["transmitterGeneration"] = transmitter_generation
        if transmitter_id is not UNSET:
            field_dict["transmitterId"] = transmitter_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        record_id = d.pop("recordId", UNSET)

        _system_time = d.pop("systemTime", UNSET)
        system_time: Union[Unset, datetime.datetime]
        if isinstance(_system_time, Unset):
            system_time = UNSET
        else:
            system_time = isoparse(_system_time)

        _display_time = d.pop("displayTime", UNSET)
        display_time: Union[Unset, datetime.datetime]
        if isinstance(_display_time, Unset):
            display_time = UNSET
        else:
            display_time = isoparse(_display_time)

        _alert_name = d.pop("alertName", UNSET)
        alert_name: Union[Unset, GetAlertsResponse200RecordsItemAlertName]
        if isinstance(_alert_name, Unset):
            alert_name = UNSET
        else:
            alert_name = GetAlertsResponse200RecordsItemAlertName(_alert_name)

        _alert_state = d.pop("alertState", UNSET)
        alert_state: Union[Unset, GetAlertsResponse200RecordsItemAlertState]
        if isinstance(_alert_state, Unset):
            alert_state = UNSET
        else:
            alert_state = GetAlertsResponse200RecordsItemAlertState(_alert_state)

        display_device = d.pop("displayDevice", UNSET)

        _transmitter_generation = d.pop("transmitterGeneration", UNSET)
        transmitter_generation: Union[Unset, GetAlertsResponse200RecordsItemTransmitterGeneration]
        if isinstance(_transmitter_generation, Unset):
            transmitter_generation = UNSET
        else:
            transmitter_generation = GetAlertsResponse200RecordsItemTransmitterGeneration(_transmitter_generation)

        transmitter_id = d.pop("transmitterId", UNSET)

        get_alerts_response_200_records_item = cls(
            record_id=record_id,
            system_time=system_time,
            display_time=display_time,
            alert_name=alert_name,
            alert_state=alert_state,
            display_device=display_device,
            transmitter_generation=transmitter_generation,
            transmitter_id=transmitter_id,
        )

        get_alerts_response_200_records_item.additional_properties = d
        return get_alerts_response_200_records_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
