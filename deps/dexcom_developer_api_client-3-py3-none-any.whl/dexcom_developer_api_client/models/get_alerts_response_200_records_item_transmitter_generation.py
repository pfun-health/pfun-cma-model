from enum import Enum


class GetAlertsResponse200RecordsItemTransmitterGeneration(str, Enum):
    DEXCOMPRO = "dexcomPro"
    G4 = "g4"
    G5 = "g5"
    G6 = "g6+"
    G7 = "g7"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
