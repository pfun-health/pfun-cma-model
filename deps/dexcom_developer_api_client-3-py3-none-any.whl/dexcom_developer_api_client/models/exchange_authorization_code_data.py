from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.exchange_authorization_code_data_grant_type import ExchangeAuthorizationCodeDataGrantType

T = TypeVar("T", bound="ExchangeAuthorizationCodeData")


@_attrs_define
class ExchangeAuthorizationCodeData:
    """
    Attributes:
        client_id (str):
        client_secret (str):
        code (str):
        grant_type (ExchangeAuthorizationCodeDataGrantType):
        redirect_uri (str):
    """

    client_id: str
    client_secret: str
    code: str
    grant_type: ExchangeAuthorizationCodeDataGrantType
    redirect_uri: str
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        client_id = self.client_id
        client_secret = self.client_secret
        code = self.code
        grant_type = self.grant_type.value

        redirect_uri = self.redirect_uri

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "client_id": client_id,
                "client_secret": client_secret,
                "code": code,
                "grant_type": grant_type,
                "redirect_uri": redirect_uri,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        client_id = d.pop("client_id")

        client_secret = d.pop("client_secret")

        code = d.pop("code")

        grant_type = ExchangeAuthorizationCodeDataGrantType(d.pop("grant_type"))

        redirect_uri = d.pop("redirect_uri")

        exchange_authorization_code_data = cls(
            client_id=client_id,
            client_secret=client_secret,
            code=code,
            grant_type=grant_type,
            redirect_uri=redirect_uri,
        )

        exchange_authorization_code_data.additional_properties = d
        return exchange_authorization_code_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
