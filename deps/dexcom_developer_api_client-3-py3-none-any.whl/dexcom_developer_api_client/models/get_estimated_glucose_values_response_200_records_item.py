import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.get_estimated_glucose_values_response_200_records_item_rate_unit import (
    GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit,
)
from ..models.get_estimated_glucose_values_response_200_records_item_status import (
    GetEstimatedGlucoseValuesResponse200RecordsItemStatus,
)
from ..models.get_estimated_glucose_values_response_200_records_item_transmitter_generation import (
    GetEstimatedGlucoseValuesResponse200RecordsItemTransmitterGeneration,
)
from ..models.get_estimated_glucose_values_response_200_records_item_trend import (
    GetEstimatedGlucoseValuesResponse200RecordsItemTrend,
)
from ..models.get_estimated_glucose_values_response_200_records_item_unit import (
    GetEstimatedGlucoseValuesResponse200RecordsItemUnit,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="GetEstimatedGlucoseValuesResponse200RecordsItem")


@_attrs_define
class GetEstimatedGlucoseValuesResponse200RecordsItem:
    """
    Attributes:
        record_id (Union[Unset, str]):
        system_time (Union[Unset, datetime.datetime]):
        display_time (Union[Unset, datetime.datetime]):
        transmitter_id (Union[Unset, str]):
        transmitter_ticks (Union[Unset, int]):
        value (Union[Unset, int]):
        status (Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemStatus]):
        trend (Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTrend]):
        trend_rate (Union[Unset, float]):
        unit (Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemUnit]):
        rate_unit (Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit]):
        display_device (Union[Unset, str]):
        transmitter_generation (Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTransmitterGeneration]):
    """

    record_id: Union[Unset, str] = UNSET
    system_time: Union[Unset, datetime.datetime] = UNSET
    display_time: Union[Unset, datetime.datetime] = UNSET
    transmitter_id: Union[Unset, str] = UNSET
    transmitter_ticks: Union[Unset, int] = UNSET
    value: Union[Unset, int] = UNSET
    status: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemStatus] = UNSET
    trend: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTrend] = UNSET
    trend_rate: Union[Unset, float] = UNSET
    unit: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemUnit] = UNSET
    rate_unit: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit] = UNSET
    display_device: Union[Unset, str] = UNSET
    transmitter_generation: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTransmitterGeneration] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        record_id = self.record_id
        system_time: Union[Unset, str] = UNSET
        if not isinstance(self.system_time, Unset):
            system_time = self.system_time.isoformat()

        display_time: Union[Unset, str] = UNSET
        if not isinstance(self.display_time, Unset):
            display_time = self.display_time.isoformat()

        transmitter_id = self.transmitter_id
        transmitter_ticks = self.transmitter_ticks
        value = self.value
        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        trend: Union[Unset, str] = UNSET
        if not isinstance(self.trend, Unset):
            trend = self.trend.value

        trend_rate = self.trend_rate
        unit: Union[Unset, str] = UNSET
        if not isinstance(self.unit, Unset):
            unit = self.unit.value

        rate_unit: Union[Unset, str] = UNSET
        if not isinstance(self.rate_unit, Unset):
            rate_unit = self.rate_unit.value

        display_device = self.display_device
        transmitter_generation: Union[Unset, str] = UNSET
        if not isinstance(self.transmitter_generation, Unset):
            transmitter_generation = self.transmitter_generation.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if record_id is not UNSET:
            field_dict["recordId"] = record_id
        if system_time is not UNSET:
            field_dict["systemTime"] = system_time
        if display_time is not UNSET:
            field_dict["displayTime"] = display_time
        if transmitter_id is not UNSET:
            field_dict["transmitterId"] = transmitter_id
        if transmitter_ticks is not UNSET:
            field_dict["transmitterTicks"] = transmitter_ticks
        if value is not UNSET:
            field_dict["value"] = value
        if status is not UNSET:
            field_dict["status"] = status
        if trend is not UNSET:
            field_dict["trend"] = trend
        if trend_rate is not UNSET:
            field_dict["trendRate"] = trend_rate
        if unit is not UNSET:
            field_dict["unit"] = unit
        if rate_unit is not UNSET:
            field_dict["rateUnit"] = rate_unit
        if display_device is not UNSET:
            field_dict["displayDevice"] = display_device
        if transmitter_generation is not UNSET:
            field_dict["transmitterGeneration"] = transmitter_generation

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        record_id = d.pop("recordId", UNSET)

        _system_time = d.pop("systemTime", UNSET)
        system_time: Union[Unset, datetime.datetime]
        if isinstance(_system_time, Unset):
            system_time = UNSET
        else:
            system_time = isoparse(_system_time)

        _display_time = d.pop("displayTime", UNSET)
        display_time: Union[Unset, datetime.datetime]
        if isinstance(_display_time, Unset):
            display_time = UNSET
        else:
            display_time = isoparse(_display_time)

        transmitter_id = d.pop("transmitterId", UNSET)

        transmitter_ticks = d.pop("transmitterTicks", UNSET)

        value = d.pop("value", UNSET)

        _status = d.pop("status", UNSET)
        status: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = GetEstimatedGlucoseValuesResponse200RecordsItemStatus(_status)

        _trend = d.pop("trend", UNSET)
        trend: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTrend]
        if isinstance(_trend, Unset):
            trend = UNSET
        else:
            trend = GetEstimatedGlucoseValuesResponse200RecordsItemTrend(_trend)

        trend_rate = d.pop("trendRate", UNSET)

        _unit = d.pop("unit", UNSET)
        unit: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemUnit]
        if isinstance(_unit, Unset):
            unit = UNSET
        else:
            unit = GetEstimatedGlucoseValuesResponse200RecordsItemUnit(_unit)

        _rate_unit = d.pop("rateUnit", UNSET)
        rate_unit: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit]
        if isinstance(_rate_unit, Unset):
            rate_unit = UNSET
        else:
            rate_unit = GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit(_rate_unit)

        display_device = d.pop("displayDevice", UNSET)

        _transmitter_generation = d.pop("transmitterGeneration", UNSET)
        transmitter_generation: Union[Unset, GetEstimatedGlucoseValuesResponse200RecordsItemTransmitterGeneration]
        if isinstance(_transmitter_generation, Unset):
            transmitter_generation = UNSET
        else:
            transmitter_generation = GetEstimatedGlucoseValuesResponse200RecordsItemTransmitterGeneration(
                _transmitter_generation
            )

        get_estimated_glucose_values_response_200_records_item = cls(
            record_id=record_id,
            system_time=system_time,
            display_time=display_time,
            transmitter_id=transmitter_id,
            transmitter_ticks=transmitter_ticks,
            value=value,
            status=status,
            trend=trend,
            trend_rate=trend_rate,
            unit=unit,
            rate_unit=rate_unit,
            display_device=display_device,
            transmitter_generation=transmitter_generation,
        )

        get_estimated_glucose_values_response_200_records_item.additional_properties = d
        return get_estimated_glucose_values_response_200_records_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
