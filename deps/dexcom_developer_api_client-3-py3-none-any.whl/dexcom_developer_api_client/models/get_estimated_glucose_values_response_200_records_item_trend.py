from enum import Enum


class GetEstimatedGlucoseValuesResponse200RecordsItemTrend(str, Enum):
    DOUBLEDOWN = "doubleDown"
    DOUBLEUP = "doubleUp"
    FLAT = "flat"
    FORTYFIVEDOWN = "fortyFiveDown"
    FORTYFIVEUP = "fortyFiveUp"
    NONE = "none"
    NOTCOMPUTABLE = "notComputable"
    RATEOUTOFRANGE = "rateOutOfRange"
    SINGLEDOWN = "singleDown"
    SINGLEUP = "singleUp"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
