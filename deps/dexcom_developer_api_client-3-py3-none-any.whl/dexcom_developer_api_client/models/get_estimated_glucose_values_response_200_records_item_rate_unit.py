from enum import Enum


class GetEstimatedGlucoseValuesResponse200RecordsItemRateUnit(str, Enum):
    MGDLMIN = "mg/dL/min"
    MMOLLMIN = "mmol/L/min"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
