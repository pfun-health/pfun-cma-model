from enum import Enum


class UserAuthorizationScope(str, Enum):
    OFFLINE_ACCESS = "offline_access"

    def __str__(self) -> str:
        return str(self.value)
