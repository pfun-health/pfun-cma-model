var apigClient = apigClientFactory.newClient({
    apiKey: ''
});