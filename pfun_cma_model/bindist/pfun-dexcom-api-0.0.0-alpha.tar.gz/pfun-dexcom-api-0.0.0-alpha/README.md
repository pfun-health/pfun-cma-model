# pfun-dexcom-api

[PFun Digital Health's](https://pfun.one/) Python wrapper for the [Dexcom Developer API](https://developer.dexcom.com/docs/).
