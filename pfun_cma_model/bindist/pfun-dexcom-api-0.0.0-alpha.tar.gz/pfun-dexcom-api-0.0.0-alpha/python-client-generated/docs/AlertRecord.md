# AlertRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**record_id** | **str** |  | [optional] 
**system_time** | **datetime** |  | [optional] 
**display_time** | **datetime** |  | [optional] 
**alert_name** | **str** |  | [optional] 
**alert_state** | **str** |  | [optional] 
**display_device** | **str** |  | [optional] 
**transmitter_generation** | **str** |  | [optional] 
**transmitter_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

