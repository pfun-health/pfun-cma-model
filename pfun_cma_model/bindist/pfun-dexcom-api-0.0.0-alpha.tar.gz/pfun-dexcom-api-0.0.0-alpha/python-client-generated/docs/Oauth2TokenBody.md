# Oauth2TokenBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **str** |  | 
**client_secret** | **str** |  | 
**code** | **str** |  | 
**refresh_token** | **str** |  | [optional] 
**grant_type** | **str** |  | 
**redirect_uri** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

