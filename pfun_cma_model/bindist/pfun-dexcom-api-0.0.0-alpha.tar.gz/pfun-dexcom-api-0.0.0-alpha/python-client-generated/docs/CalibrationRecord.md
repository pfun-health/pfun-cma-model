# CalibrationRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**record_id** | **str** |  | [optional] 
**unit** | **str** |  | [optional] 
**system_time** | **datetime** |  | [optional] 
**display_time** | **datetime** |  | [optional] 
**value** | **int** |  | [optional] 
**display_device** | **str** |  | [optional] 
**transmitter_id** | **str** |  | [optional] 
**transmitter_ticks** | **int** |  | [optional] 
**transmitter_generation** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

