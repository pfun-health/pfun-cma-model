# DataRangeMoment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**system_time** | **datetime** |  | 
**display_time** | **datetime** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

