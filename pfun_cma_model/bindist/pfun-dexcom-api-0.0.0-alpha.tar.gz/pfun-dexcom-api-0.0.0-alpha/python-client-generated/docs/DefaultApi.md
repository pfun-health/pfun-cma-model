# swagger_client.DefaultApi

All URIs are relative to *https://api.dexcom.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**exchange_authorization_code**](DefaultApi.md#exchange_authorization_code) | **POST** /v2/oauth2/token | 
[**get_alerts**](DefaultApi.md#get_alerts) | **GET** /v3/users/self/alerts | 
[**get_calibrations**](DefaultApi.md#get_calibrations) | **GET** /v3/users/self/calibrations | 
[**get_data_range**](DefaultApi.md#get_data_range) | **GET** /v3/users/self/dataRange | 
[**get_estimated_glucose_values**](DefaultApi.md#get_estimated_glucose_values) | **GET** /v3/users/self/egvs | 
[**user_authorization**](DefaultApi.md#user_authorization) | **GET** /v2/oauth2/login | 

# **exchange_authorization_code**
> InlineResponse2002 exchange_authorization_code(client_id, client_secret, code, refresh_token, grant_type, redirect_uri)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
client_id = 'client_id_example' # str | 
client_secret = 'client_secret_example' # str | 
code = 'code_example' # str | 
refresh_token = 'refresh_token_example' # str | 
grant_type = 'grant_type_example' # str | 
redirect_uri = 'redirect_uri_example' # str | 

try:
    api_response = api_instance.exchange_authorization_code(client_id, client_secret, code, refresh_token, grant_type, redirect_uri)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->exchange_authorization_code: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **client_id** | **str**|  | 
 **client_secret** | **str**|  | 
 **code** | **str**|  | 
 **refresh_token** | **str**|  | 
 **grant_type** | **str**|  | 
 **redirect_uri** | **str**|  | 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_alerts**
> AlertRecord get_alerts(start_date, end_date)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
start_date = '2013-10-20T19:20:30+01:00' # datetime | 
end_date = '2013-10-20T19:20:30+01:00' # datetime | 

try:
    api_response = api_instance.get_alerts(start_date, end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_alerts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start_date** | [**datetime**](.md)|  | 
 **end_date** | [**datetime**](.md)|  | 

### Return type

[**AlertRecord**](AlertRecord.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_calibrations**
> CalibrationRecord get_calibrations(start_date, end_date)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
start_date = '2013-10-20T19:20:30+01:00' # datetime | 
end_date = '2013-10-20T19:20:30+01:00' # datetime | 

try:
    api_response = api_instance.get_calibrations(start_date, end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_calibrations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start_date** | [**datetime**](.md)|  | 
 **end_date** | [**datetime**](.md)|  | 

### Return type

[**CalibrationRecord**](CalibrationRecord.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_data_range**
> InlineResponse200 get_data_range(last_sync_time=last_sync_time)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
last_sync_time = '2013-10-20T19:20:30+01:00' # datetime |  (optional)

try:
    api_response = api_instance.get_data_range(last_sync_time=last_sync_time)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_data_range: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **last_sync_time** | **datetime**|  | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_estimated_glucose_values**
> EGVRecord get_estimated_glucose_values(start_date, end_date)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
start_date = '2013-10-20T19:20:30+01:00' # datetime | 
end_date = '2013-10-20T19:20:30+01:00' # datetime | 

try:
    api_response = api_instance.get_estimated_glucose_values(start_date, end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_estimated_glucose_values: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start_date** | [**datetime**](.md)|  | 
 **end_date** | [**datetime**](.md)|  | 

### Return type

[**EGVRecord**](EGVRecord.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **user_authorization**
> InlineResponse2001 user_authorization(client_id, redirect_uri, response_type, scope, state=state)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: BearerAuth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
client_id = 'client_id_example' # str | 
redirect_uri = 'redirect_uri_example' # str | 
response_type = 'response_type_example' # str | 
scope = 'scope_example' # str | 
state = 'state_example' # str |  (optional)

try:
    api_response = api_instance.user_authorization(client_id, redirect_uri, response_type, scope, state=state)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->user_authorization: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **client_id** | **str**|  | 
 **redirect_uri** | **str**|  | 
 **response_type** | **str**|  | 
 **scope** | **str**|  | 
 **state** | **str**|  | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

