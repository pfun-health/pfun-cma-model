async function redirect2login() {
    window.location.href = "/login";
}