"""app.py: defines the PFun wrapper for the Dexcom API."""
import os
import logging
logging.basicConfig(level=logging.INFO)
logging.getLogger(__name__)
from typing import Optional
from fastapi import (
    FastAPI, 
    HTTPException,
    status,
    Depends, 
    Request,
    BackgroundTasks
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2AuthorizationCodeBearer as OAuth2Bearer
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from authlib.integrations.starlette_client import OAuth
import httpx
from contextlib import asynccontextmanager
from redis import asyncio as aioredis
import uuid

import pfun_path_helper as pph  # pylint: disable=unused-import
from pfun_common.config import settings
from pfun_dexcom_api.api.creds import DexcomCreds

oauth = OAuth()
app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key='secret')
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")

templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

origins = [
    "http://localhost:8000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# Redis setup
async def create_redis():
    redis = aioredis.from_url("redis://localhost")
    yield redis
    redis.close()
    await redis.wait_closed()


# Dependency to get the current user based on OAuth2 token
oauth2_scheme = OAuth2Bearer(authorizationUrl="/login", tokenUrl="/token")


async def load_creds():
    redis = aioredis.from_url("redis://localhost")
    dexcom_creds = await redis.get("dexcom_creds")
    creds = DexcomCreds(_creds = dexcom_creds)
    return creds


def setup_auth(creds: DexcomCreds = Depends(load_creds)):
    """
    As an asynchronous context manager, initializes credentials for
    Dexcom integration within a FastAPI app lifespan. It yields control
    before setting up the Dexcom OAuth2 provider with the necessary
    authorization parameters.
    """
    logging.info("...loaded dexcom creds.")
    # Define your Dexcom OAuth2 provider
    dexcom = oauth.register(
        name='dexcom',
        client_id=f'{creds.client_id}',  # Replace with your Dexcom client ID
        client_secret=f'{creds.client_secret}',  # Replace with your Dexcom client secret
        authorize_url='https://api.dexcom.com/v2/oauth2/login',
        authorize_params=None,
        authorize_params_callback=None,
        authorize_params_extra={
            'response_type': 'code',
            'scope': 'offline_access',
            'state': 'state_value' # uuid.uuid4().hex
        }
    )
    logging.info("...registered dexcom oauth.")
    return dexcom


async def get_current_user(token: str = Depends(oauth2_scheme), redis: aioredis.Redis = Depends(create_redis)):
    # Retrieve and validate the token from Redis
    user_id = await redis.get(token)
    if user_id is None:
        return None  # Token is invalid

    # Fetch user information based on user_id (replace with your user lookup logic)
    user = {"user_id": user_id.decode(), "profile": {}}
    return user


@app.get("/")
async def root(request: Request, dexcom: OAuth = Depends(setup_auth)):
    """Root route: returns the index.html template."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/profile", response_model=dict)
async def get_profile(current_user: dict = Depends(get_current_user)):
    if current_user is None:
        return {"message": "Invalid token"}
    return current_user


@app.get("/login")
async def dexcom_login(request: Request, dexcom: OAuth = Depends(setup_auth)):
    """Redirects the user to Dexcom's login page."""
    redirect_uri = request.url_for("dexcom_callback")
    return await dexcom.authorize_redirect(request, redirect_uri)


@app.get("/callback")
async def dexcom_callback(request: Request, dexcom: OAuth = Depends(setup_auth)):
    """Gets the access token from Dexcom."""
    token = await dexcom.authorize_access_token(request)
    return {"access_token": token}



@app.get("/token")
async def access_token(request: Request, current_user: dict = Depends(get_current_user), creds: DexcomCreds = Depends(load_creds)):
    """Gets a new access token from Dexcom.
    """

    if current_user is None:
        return {"message": "Invalid token"}

    # Use the authorization code to request a new access token
    code = current_user.get("code")
    if not code:
        return {"message": "No authorization code available"}

    client_id = f'{creds.client_id}'
    client_secret = f'{creds.client_secret}'

    async with httpx.AsyncClient() as client:
        response = await client.post(
            'https://api.dexcom.com/v2/oauth2/token',
            data={
                'client_id': client_id,
                'client_secret': client_secret,
                'code': code,
                'grant_type': 'authorization_code',
                'redirect_uri': request.url_for('dexcom_callback'),
            },
        )

        if response.status_code == 200:
            new_token_data = response.json()
            # Store or update the new access token in your data store
            # Update the current user's token information if needed
            return new_token_data
        else:
            raise HTTPException(status_code=response.status_code, detail="Token request failed")


@app.get("/refresh-token")
async def refresh_token(request: Request, current_user: dict = Depends(get_current_user), creds: DexcomCreds = Depends(load_creds)):
    """Gets a new access token using the refresh token.
    """

    if current_user is None:
        return {"message": "Invalid token"}

    # Use the refresh token to request a new access token
    token = current_user.get("refresh_token")
    if not token:
        return {"message": "No refresh token available"}

    client_id = f'{creds.client_id}'
    client_secret = f'{creds.client_secret}'

    async with httpx.AsyncClient() as client:
        response = await client.post(
            'https://api.dexcom.com/v2/oauth2/token',
            data={
                'grant_type': 'refresh_token',
                'refresh_token': token,
                'client_id': client_id,
                'client_secret': client_secret,
            },
        )

        if response.status_code == 200:
            new_token_data = response.json()
            # Store or update the new access token in your data store
            # Update the current user's token information if needed
            return new_token_data
        else:
            raise HTTPException(status_code=response.status_code, detail="Token refresh failed")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
