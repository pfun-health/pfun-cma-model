"""api.creds"""
import json
import os
from dataclasses import dataclass
from redis import asyncio as aioredis
import pfun_path_helper as pph  # pylint: disable=unused-import  # noqa: F401
from pfun_common.config import settings
from pfun_common.mysteries import get_secret


@dataclass
class DexcomCreds:
    client_id: str = None
    client_secret: str = None
    _creds: dict = None
    _redis: aioredis.Redis = None

    def __post_init__(self):        
        if self._creds is None:
            self._creds = DexcomCreds.get_creds()
            if self._redis is not None:
                # store in redis
                self._redis.set("dexcom_creds", self._creds)
        if self.client_id is None:
            self.client_id = self._creds.get("client_id")
        if self.client_secret is None:
            self.client_secret = self._creds.get("client_secret")

    @staticmethod
    def get_creds(from_aws=True, app_name="pfun-fiona"):
        """
        Retrieves the Dexcom API credentials from a JSON file and sets the client ID and secret as environment variables.

        Returns:
            Tuple[str, str]: A tuple containing the client ID and client secret.
        """
        if from_aws is True:
            value = get_secret("pfun-dexcom-creds")
            creds = json.loads(value)
        else:
            creds = json.loads(
                open(settings.DEXCOM_CREDS_PATH, 'r', encoding='utf-8').read()
            )
        creds = creds.get(app_name)
        if creds is None:
            raise ValueError(f"Could not find credentials for app '{app_name}'")
        return creds
