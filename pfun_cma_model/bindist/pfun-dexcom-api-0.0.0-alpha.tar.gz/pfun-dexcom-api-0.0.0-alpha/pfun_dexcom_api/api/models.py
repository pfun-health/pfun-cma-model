"""dexcom.py"""

from dataclasses import dataclass, field
from typing import Literal, Dict, List, Optional, Any
import dataclasses_json
from dataclasses_json import dataclass_json
from marshmallow import fields, validate


class DexcomCredentials:
    client_id: str
    client_secret: str


DexcomEndpoint = Literal["dataRange", "egvs",
                         "alerts", "calibrations", "devices", "events"]
EgvUnits = Literal["mg/dL", "mmol/L"]


@dataclass
class DexcomAPIRecordModel:
    recordId: str
    systemTime: str
    displayTime: str
    alertName: Optional[str] = field(default=None)
    alertState: Optional[str] = field(default=None)
    displayDevice: Optional[str] = field(default=None)
    transmitterGeneration: Optional[str] = field(default=None)
    transmitterId: Optional[str] = field(default=None)
    unit: Optional[EgvUnits] = field(default="mg/dL")
    value: Optional[int] = field(default=None)


@dataclass
class DexcomAPIResponseModel:
    recordType: DexcomEndpoint
    recordVersion: Literal["3.0", "2.0"] = field(default="3.0")
    userId: Optional[str] = field(default=None)
    tz_offset: Optional[str | float | int | None] = field(default=None)
    records: List[DexcomAPIRecordModel] = field(default_factory=list)


@dataclass_json.dataclass_json
@dataclass
class EgvsRecordModel(DexcomAPIRecordModel):
    unit: EgvUnits = "mg/dL"
    value: int = field(metadata=dataclasses_json.config(
        encoder=int,
        decoder=int,
        mm_field=fields.Integer(validate=validate.Range(min=30, max=400))
    ))
    status: Literal["unknown", "high", "low", "ok"]

    def __post_init__(self):
        self.status = self.computeStatus()

    def computeStatus(self):
        status_value = self.status
        if status_value is None or status_value == "unknown":
            egv = self.value
            if not any([isinstance(egv, int), isinstance(egv, float)]):
                return "unknown"
            if egv < 70:
                return "low"
            elif egv > 180:
                return "high"
            else:
                return "ok"
        return status_value


class EgvsResponseModel(DexcomAPIResponseModel):
    recordType: Literal["egvs"] = "egvs"
    records: List[EgvsRecordModel] | Dict[Any, EgvsRecordModel] | Any


class AlertsRecordModel(DexcomAPIRecordModel):
    alertName: str


class DatarangeRecordModel(DexcomAPIRecordModel):
    data: Dict[str, Any]
    records: Optional[None | Any]


class DatarangeResponseModel(DexcomAPIResponseModel):
    recordType: Literal["dataRange"] = "dataRange"
    records: Optional[List[DatarangeRecordModel]]


class AlertsResponseModel(DexcomAPIResponseModel):
    recordType: Literal["alerts"] = "alerts"
    records: List[EgvsRecordModel]


class CalibrationsResponseModel(DexcomAPIResponseModel):
    recordType: Literal["calibrations"] = "calibrations"
    records: List[EgvsRecordModel]


class DevicesResponseModel(DexcomAPIResponseModel):
    recordType: Literal["devices"] = "devices"
    records: List[EgvsRecordModel]


class EventsResponseModel:
    recordType: Literal["events"] = "events"
    records: List[EgvsRecordModel]
