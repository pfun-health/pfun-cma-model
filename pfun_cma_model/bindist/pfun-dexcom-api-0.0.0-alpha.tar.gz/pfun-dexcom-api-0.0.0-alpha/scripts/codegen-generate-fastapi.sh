#!/bin/bash

# generate fastapi code from openapi schema

poetry run fastapi-codegen \
    --input ./pfun_dexcom_api/schemas/openapi.json \
    --output ./pfun_dexcom_api/app
    --generate-routers