#!/bin/bash

# generate server from openapi.json

set -e

SERVER_TYPE=${1:-python-flask}
SERVERS_ROOT=./pfun_dexcom_api/servers
SERVER_DIR=${SERVERS_ROOT}/${SERVER_TYPE}_server
SERVER_RESOURCES_DIR=./pfun_dexcom_api/_resources/${SERVER_TYPE}_server

# make directory, remove old server
mkdir -p "${SERVERS_ROOT}"
rm -rf "${SERVER_DIR}"

# generate server
openapi-generator-cli generate \
    -i ./pfun_dexcom_api/schemas/openapi.json \
    -g $SERVER_TYPE \
    -o "${SERVER_DIR}"

# turn off exit on error (optional step for some server types)
set +e
# pre-install step
cp -r "${SERVER_RESOURCES_DIR}/*" "${SERVER_DIR}/"
set -e

# install server
install_server () {
    cd "${SERVER_DIR}" || exit 1
    pip install . || exit 1
    cd - || exit 1
    echo "...Successfully installed server from ${SERVER_DIR}"
}

install_server

echo "OpenAPI server generated at: ${SERVER_DIR}"
echo "...done."
