#!/usr/bin/env bash
aws s3 cp ./pfun_dexcom_api/schemas/openapi.json s3://robbie-personal-data/dexcom-openapi.json
aws s3 presign s3://robbie-personal-data/dexcom-openapi.json
