#!/bin/bash

# generate client from openapi.json
set -e

CLIENT_TYPE=${1:-typescript-axios}
FRONTEND_ROOT=./codegen/frontend
CLIENTS_ROOT=$(pwd)/${FRONTEND_ROOT}/clients
CLIENT_DIR=${CLIENTS_ROOT}/${CLIENT_TYPE}_client

# make directory, remove old client
mkdir -p "${CLIENTS_ROOT}"
rm -rf "${CLIENT_DIR}"

# generate client
openapi-generator-cli generate \
    -i ./pfun_dexcom_api/schemas/openapi.json \
    -g $CLIENT_TYPE \
    -o "${CLIENT_DIR}"


javascript () {
    ## local development (npm)
    BUNDLE_OUTPUT_DIR=$(pwd)/${FRONTEND_ROOT}/static/js
    cd ${CLIENT_DIR} || exit 1
    npm install --save || exit 1
    npm link || exit 1
    npm run build || exit 1
    ## convert for browser
    # install browserify
    npm install -g browserify
    # create bundle
    browserify ./src/index.js \
        --standalone Bundle \
        -o "${BUNDLE_OUTPUT_DIR}/clientproxy.js" || exit 1
    cd - || exit 1
}

typescript-node () {
    echo ''
}

typescript-axios () {
    echo ''
}


case $CLIENT_TYPE in
    javascript)
        javascript
        ;;
    typescript-node)
        typescript-node
        ;;
    typescript-axios)
        typescript-axios
        ;;
    *)
        echo "unknown client type: $CLIENT_TYPE"
        exit 1
        ;;
esac


echo '...done.'